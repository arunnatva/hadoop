package com.bac.ecr.hdf.components.aggregation.utils;

public class DataAggregationConstants {

	 //public final static String ;
	
	
	public DataAggregationConstants() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * AggregationErrorCodes Enum lists all the possible exception messages for DataAggregation. Takes parameter and returns 
	 * appropriate error message to be logged in to hadoop logging framework . 
	 * 
	 */
	public enum AggregationErrorCodes {
		
		AGGREGATION_100("AGGREGATION-100 : Provided aggregated column is not available in source table"),
		AGGREGATION_101("AGGREGATION-101 : Provided aggregated column has non-numeric data type"),
		AGGREGATION_102("AGGREGATION-102 : Column count mismatch among provided aggregated columns and target table");
		
		
		private final String aggregationErrorCode;
		
		private AggregationErrorCodes(String aggregationErrorCode) {
	        this.aggregationErrorCode = aggregationErrorCode;
	    }
	    
	    public String value() {
	    	return aggregationErrorCode;
	    }
	}
}
