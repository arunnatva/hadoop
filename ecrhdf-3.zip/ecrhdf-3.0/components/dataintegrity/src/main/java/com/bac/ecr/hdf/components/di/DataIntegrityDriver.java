package com.bac.ecr.hdf.components.di;

import static com.bac.ecr.hdf.components.utils.commonutils.CommonUtils.getVariableArgsToString;

import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckService;
import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckServiceFactory;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityException;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.components.utils.commonutils.HdfsUtils;
import com.bac.ecr.hdf.components.utils.commonutils.HeaderTrailerOperationsUtil;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
import com.bac.ecr.hdf.components.utils.commonutils.ValidationUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogFactory;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;

/**
 * @author ZKFYMQ6 (Ankita Jain)
 *
 */
public class DataIntegrityDriver {

	final static Logger logger = Logger.getLogger(DataIntegrityDriver.class);


	public static void main(String[] args) throws Exception {

		Map<String,String> inputArgsMap = CommonUtils.getInputArgsMap(args);

		if (!CommonUtils.validateInputConfigParams(inputArgsMap)) {
			logger.error(Constants.PRINT_FORMATTER);
			logger.error(" Both configJSON and mappingJSON files are required " );
			//System.out.println(" Both configJSON and mappingJSON files are required " );
			logger.error(Constants.PRINT_FORMATTER);
			System.exit(1);
		};


		SparkConf sparkConf = new SparkConf().setAppName("Data Integrity App");
		JavaSparkContext jsc = new JavaSparkContext(sparkConf);
		SQLContext sqlContext = new org.apache.spark.sql.SQLContext(jsc.sc());
		HiveContext hiveCtx = new HiveContext(jsc.sc());
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		String configJson = null;
		String mappingJson =null;
		DataIntegrityCheckService diService = null;
		DataFrame sourceDF = null;
		HadoopLogger hadoopLogger = HadoopLogFactory.getInstance(DataIntegrityDriver.class.getSimpleName(), DDI_LAYER.DATA_INEGRITY,conf);
		try {
			//reading Config and Mapping Json
			configJson = HdfsUtils.readHdfsFile(fs, new Path(inputArgsMap.get(Constants.CONFIG_JSON).trim()));
			mappingJson = HdfsUtils.readHdfsFile(fs, new Path(inputArgsMap.get(Constants.MAPPING_JSON).trim()));
			
			//parsing mapping JSON to schemaMappingList
			SchemaMappingList schemaMapLst = (SchemaMappingList)JsonParseUtil.parseJSON(mappingJson,new SchemaMappingList());

			// configuration object	
			RawConfiguration config = (RawConfiguration) JsonParseUtil.parseJSON(configJson, new RawConfiguration()); 
			//validation for required fields
			ValidationUtil.validateRawConfig(config);

			/*//create list of columns not in source file 
			List<String> dynamicValuesLst = CommonUtils.getSrcInAndOutColumnMap(schemaMapLst).get(Constants.COLUMNS_NOT_IN_SRC_FILE);

			//checking if dynamic columns'value is passed as argument
			dynamicValuesLst.forEach(arg -> {                                                           
				if (null == inputArgsMap.get(arg) ) {
					logger.error(" Pass the required argument : " + arg );                                                                      
					System.exit(1);
				}
			});
*/
			//DI for Database
			if (config.getSrcFeedType().toUpperCase().equals(Constants.DATABASE)) {

				//generate schema from mapping				
				StructType rawTableSchema = SchemaOperationsUtil.getSchemaFromJsonMapping(schemaMapLst.getColumnMapping());
				//extract source table schema
				StructType srcSchemaMapping = SchemaOperationsUtil.getSrcFileSchemaMapping(rawTableSchema,schemaMapLst.getColumnMapping());
				StructField[] temp = srcSchemaMapping.fields();
				String[] schemaFields = new String[temp.length];
				for (int i = 0; i < temp.length; i++){
					schemaFields[i] = temp[i].dataType().toString();
				}
				Broadcast<String[]> structFields = jsc.broadcast(schemaFields);
				Accumulator[] accumulatorArr = new Accumulator[temp.length];
				for (int i = 0; i < accumulatorArr.length; i++) {
					accumulatorArr[i] = jsc.accumulator(0, temp[i].name());
				}
				//extract diService for Database
				diService = DataIntegrityCheckServiceFactory.diService(Constants.DATABASE);
				// to read file into an RDD 
				JavaRDD<String> inputData = jsc.textFile(config.getSrcFeedLocation());				
				inputData.toDebugString();
				//converting RDD to Dataframe
				sourceDF = SchemaOperationsUtil.convertSourceToDataFrame(inputData,srcSchemaMapping,structFields, config, hiveCtx, accumulatorArr);
				sourceDF.explain(true);
				logger.info(getVariableArgsToString(
										Constants.PRINT_FORMATTER,
										"Data Itegrity Checks processing started....",
										Constants.PRINT_FORMATTER));
				
				
				if(null != inputArgsMap.get(Constants.FILTER_CONDITION)){
					
					if (!diService.performDIValidations(config, sourceDF,null,hiveCtx,null,null,inputArgsMap,null)) {
						String message = getVariableArgsToString(DataIntegrityConstants.DIErrorCodes.DI_104.getErrorcode());			
						hadoopLogger.exception("DIValidations", message);
						throw new DataIntegrityException(DataIntegrityConstants.DIErrorMessage.DB_SUM_CHECK.values().toString());
					}
					
							                                                             
				} else {
					String message = "Please pass either condition or NONE as " + Constants.FILTER_CONDITION; 
					hadoopLogger.exception("DIValidations",message);
					logger.error(message);
				
				}

			} else {
				//DI for Files
								
				// to read file into an RDD 
				JavaRDD<String> inputData = jsc.textFile(config.getSrcFeedLocation());				
				inputData.toDebugString();
				//generate schema from mapping				
				StructType rawTableSchema = SchemaOperationsUtil.getSchemaFromJsonMapping(schemaMapLst.getColumnMapping());
               
				//extract source file schema
				StructType srcFileSchemaMapping = SchemaOperationsUtil.getSrcFileSchemaMapping(rawTableSchema,schemaMapLst.getColumnMapping());                       
				StructField[] temp = srcFileSchemaMapping.fields();
				String[] schemaFields = new String[temp.length];
				for (int i = 0; i < temp.length; i++){
					schemaFields[i] = temp[i].dataType().toString();
				}
				Broadcast<String[]> structFields = jsc.broadcast(schemaFields);
				Accumulator[] accumulatorArr = new Accumulator[temp.length];
				for (int i = 0; i < accumulatorArr.length; i++) {
					accumulatorArr[i] = jsc.accumulator(0, temp[i].name());
				}
				//extract diService based on file type
				diService = DataIntegrityCheckServiceFactory.diService(config.getSrcFileFormat());

				DataFrame rawTableDf = null;
				JavaRDD<String> preparedData;
				String headerRecord ="",trailerRecord ="";

				headerRecord = (config.isHasHeader()) ? HeaderTrailerOperationsUtil.extractHeader(inputData,config) : "";
				trailerRecord = (config.isHasTrailer()) ? HeaderTrailerOperationsUtil.extractTrailerRecord(fs,new Path(config.getSrcFeedLocation())) : "";
				
				if (config.isHasHeader() || config.isHasTrailer()) {
					preparedData = inputData.filter(HeaderTrailerOperationsUtil.removeHDRTRL(config,headerRecord.trim(),trailerRecord.trim()));	
				} else {
					preparedData = inputData;
				}
				
				
				//conver rdd to dataframe
				rawTableDf = SchemaOperationsUtil.convertSourceToDataFrame(preparedData, srcFileSchemaMapping,structFields, config, hiveCtx, accumulatorArr);
				rawTableDf.explain(true);
				
				//perform validations on dataframe
				boolean diChecksResult = diService.performDIValidations(config,rawTableDf,rawTableSchema,hiveCtx,trailerRecord,headerRecord,inputArgsMap,srcFileSchemaMapping);
				
				String message = getVariableArgsToString(String.valueOf(diChecksResult));
						
				hadoopLogger.exception("DIValidations", message);
				
				

			} 

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			hadoopLogger.exception("DIValidations", e.getMessage(), e);
			throw e;
		} finally {
			jsc.close();
			hadoopLogger.close();
		}

	}






}
