package com.bac.ecr.hdf.components.di.beans;

/**
 * 
 * @author ZKZB9LR
 *
 */
public class DataSourcingEnums {

/**
 * This ENUM enumerates the different db driver classes. We can get rid of it if we find a better way to populate db driver
 * classes.
 * @author ZKZB9LR
 *
 */
public enum DatabaseDriver {
		
		ORACLE("oracle.jdbc.OracleDriver"), NETEZZA("org.netezza.Driver"),TERADATA("com.teradata.jdbc.TeraDriver"),
		DB2("com.ibm.db2.jcc.DB2Driver"),MSSQL("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		private final String dbDriver;

	    private DatabaseDriver(String dbDriver) {
	        this.dbDriver = dbDriver;
	    }
	    
	    public String value() {
	    	return dbDriver;
	    }
	    
	}
	
}
