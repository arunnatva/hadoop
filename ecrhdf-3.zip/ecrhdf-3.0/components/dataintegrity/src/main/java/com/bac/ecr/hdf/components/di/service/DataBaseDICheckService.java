package com.bac.ecr.hdf.components.di.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.di.utils.DaoUtil;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DIErrorMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DISuccessMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityException;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;

/**
 * DataBaseDICheckService class is used to perform DB source data integrity checks.
 *
 * 
 * @date 10/14/2016
 * @author zkpsz5o(Ravi Kambalapally)
 * @application name : ECR System Engineering
 * 
 *
 */

public class DataBaseDICheckService extends DataIntegrityCheckService {

	final static Logger logger = Logger.getLogger(DataBaseDICheckService.class);

	
	/**
	 * performRecordCountCheck gets the record count from DB by executing a query with the provided filter condition 
	 * and compare the count with the sqoop imported data file.
	 *  
	 * @param config
	 * @param sourceDf
	 * @param filterCond
	 * @param valResultMap
	 * @return	boolean
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private boolean performRecordCountCheck(RawConfiguration config,DataFrame sourceDf, String filterCond,
			Map<String, List<String>> valResultMap,Connection con)throws ClassNotFoundException, SQLException {
		boolean recordCountCheckPassed = false;
     
		long dbRecCount = DaoUtil.getCountFromTable(config,con, filterCond);
		long rddRecCount = sourceDf.count();

		if (Math.abs(rddRecCount - dbRecCount) == 0 && (dbRecCount != 0 && rddRecCount != 0)) {
	          valResultMap.get(Constants.SUCCESS_VALIDATIONS).add(DISuccessMessage.DB_COUNT_CHECK.successMessage(String.valueOf(rddRecCount),String.valueOf(dbRecCount)));
			  recordCountCheckPassed = true;
		} else {
    		valResultMap.get(Constants.FAILED_VALIDATIONS).add(DIErrorMessage.DB_COUNT_CHECK.errorMessage(String.valueOf(rddRecCount),String.valueOf(dbRecCount)));
		}
		return recordCountCheckPassed;
	}


	/**
	 * performSumCheckOnDF method gets the sum aggregation value on given columns from the source dataFrame.
	 * @param diConfig
	 * @param sourceDF
	 * @param hiveCtx
	 * @param sumColNames
	 * @return Map<String, BigDecimal>
	 */
	private Map<String, BigDecimal> performSumCheckOnDF(RawConfiguration diConfig, DataFrame sourceDF, HiveContext hiveCtx,List<String> sumColNames)	{
		Map<String, String> colChecksMap = new LinkedHashMap<String, String>();
		Map<String, BigDecimal> sumMap = new HashMap<String, BigDecimal>();
				
		for (String colNames : sumColNames)
			colChecksMap.put(colNames.trim(), Constants.SUMCHECK);

		Row colSum = sourceDF.agg(colChecksMap).head();

		String[] eachSumVal = colSum.mkString(Constants.COMMA).split(Constants.COMMA);

		for (int i = 0; i < sumColNames.size(); i++) {
			sumMap.put(sumColNames.get(i), BigDecimal.valueOf(Double.valueOf(eachSumVal[i])));
		}

		return sumMap;
	}

	/**
	 * performSumCheck method validates the Sum aggregation for the given columns from the given RDMS database table and
	 * compares with the same column sum value on the data frame.
	 * 
	 * @param diConfig
	 * @param sourceDF
	 * @param filterCond
	 * @param hiveCtx
	 * @param valResultMap
	 * @param colSumChecks
	 * @return boolean
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private boolean performSumCheck(RawConfiguration diConfig,DataFrame sourceDF, String filterCond, HiveContext hiveCtx,
			Map<String, List<String>> valResultMap,List<String> colSumChecks,Connection con) throws ClassNotFoundException, SQLException   {
		    boolean sumCheckPassed = false;

			Map<String, BigDecimal> sumCheckResDF = performSumCheckOnDF(diConfig, sourceDF, hiveCtx,colSumChecks);
			Map<String, BigDecimal> sumCheckResDB = DaoUtil.getSumFromTable(diConfig,filterCond,colSumChecks, con);

			for (String col : sumCheckResDB.keySet()) {
				if (sumCheckResDF.get(col).compareTo(sumCheckResDB.get(col))==0) {
					valResultMap.get(Constants.SUCCESS_VALIDATIONS).add(DISuccessMessage.DB_SUM_CHECK.successMessage(col,String.valueOf(sumCheckResDF.get(col)),String.valueOf(sumCheckResDB.get(col))));
					sumCheckPassed = true;
				} else {
					valResultMap.get(Constants.FAILED_VALIDATIONS).add(DIErrorMessage.DB_SUM_CHECK.errorMessage(col, String.valueOf(sumCheckResDF.get(col)), String.valueOf(sumCheckResDB.get(col))));

				}
			}

			if (valResultMap.get(Constants.FAILED_VALIDATIONS).size() > 0) {
				sumCheckPassed = false;
			}

		return sumCheckPassed;
	}

	
	


	/**
	 * performDIValidations method call compares overall  Data Integrity validations
	 * 
	 * @param diConfig
	 * @param sourceDF
	 * @param rawTableSchema
	 * @param hiveCtx
	 * @param trailerRecord
	 * @param headerRecord
	 * @param inputArgsMap
	 * @param srcFileSchemaMapping
	 * @return boolean
	 * @throws DataIntegrityException
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public boolean performDIValidations(RawConfiguration diConfig,
										DataFrame sourceDF, 
										StructType rawTableSchema, 
										HiveContext hiveCtx,
										String trailerRecord, 
										String headerRecord,
										Map<String, String> inputArgsMap, 
										StructType srcFileSchemaMapping) throws DataIntegrityException,ClassNotFoundException, SQLException {

		boolean recordCountResult = true;
		boolean sumValidation = true;
		Map<String, List<String>> valResultMap = DataIntegrityUtil.getDIValidationsMap();
		HadoopLogger hadoopLogger = getHadoopLogger();
		String filterCond = inputArgsMap.get(Constants.FILTER_CONDITION);
		
			
		 if (diConfig.getTrailerCheckConfig().length > 0) {
			  boolean countCheck = false;
			  List<String> sumCheckCols = new ArrayList<String>();
			  Connection con = DaoUtil.getDbConnection(diConfig);
			
			  for (String str : diConfig.getTrailerCheckConfig()) {
				 String[] val = str.split(Constants.COMMA);
				 if (Constants.COUNTCHECK.equals(val[0])) {
					 countCheck = true;
				 } else if (Constants.SUMCHECK.equals(val[0])) {
					   sumCheckCols.add(val[1]);
				 }
				 else {
					 logger.warn("Does not support the provided validation : " +val[0]);
					 logger.info("Supports only SUM and COUNT Validation");
				 }
			 }
		 
	
			try {
			 
			 if(countCheck){
				 recordCountResult = performRecordCountCheck(diConfig, sourceDF,filterCond, valResultMap,con);			
			}
			 if(sumCheckCols.size() > 0){
				 sumValidation = performSumCheck(diConfig, sourceDF, filterCond,hiveCtx, valResultMap,sumCheckCols, con);
			 }
		
	
		 hadoopLogger.info("DIVAlidations", this.getClass().getSimpleName(), 
		 							CommonUtils.getListValuesAsString(valResultMap.get(Constants.SUCCESS_VALIDATIONS)));
			}
		 
		 finally{
			 DaoUtil.close(con); 
		 }
		if (valResultMap.get(Constants.FAILED_VALIDATIONS).size() > 0) {
			String errorMsgs = CommonUtils.getListValuesAsString(valResultMap.get(Constants.FAILED_VALIDATIONS));
			hadoopLogger.exception("DIVAlidations", this.getClass().getSimpleName(),errorMsgs);	
			throw new DataIntegrityException(errorMsgs);
		}
		
	
		 }
		return recordCountResult && sumValidation;

	
	}
}