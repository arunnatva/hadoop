package com.bac.ecr.hdf.components.di.service;

import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.di.DataIntegrityDriver;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogFactory;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;

public abstract class DataIntegrityCheckService {


	/**
	 * performDIValidations method performs DataIntegrity validations 
	 * ex: header validations, trailer validations (COUNT, SUM).
	 * @param config
	 * @param inputDF
	 * @param rawTableSchema
	 * @param hiveContext
	 * @param trailerRecord
	 * @param headerRecord
	 * @param inputArgsMap
	 * @param srcFileSchemaMapping
	 * @return
	 * @throws Exception
	 */
	public abstract boolean performDIValidations(RawConfiguration config, 
			DataFrame inputDF, 
			StructType rawTableSchema,
			HiveContext hiveContext,
			String trailerRecord, 
			String headerRecord,
			Map<String,String> inputArgsMap,
			StructType srcFileSchemaMapping) throws Exception;
	
	/**
	 * getHadoopLogger return logging object class using  factory instantiation.
	 * @return HadoopLogger
	 */
	protected HadoopLogger getHadoopLogger(){
		return HadoopLogFactory.getInstance(this.getClass().getSimpleName(), DDI_LAYER.DATA_INEGRITY, new Configuration());
	}
	
}