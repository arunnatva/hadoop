package com.bac.ecr.hdf.components.di.service;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;

public class DataIntegrityCheckServiceFactory {

	
	/**
	 * diService method returns corresponding DataIntegrityCheckService object using 
	 * factory design pattern.
	 * @param fileType
	 * @return DataIntegrityCheckService
	 */
	public static DataIntegrityCheckService diService(String fileType) {
		DataIntegrityCheckService ds = null;		
		
		if (Constants.DELIMITED.equals(fileType.toUpperCase())) {			
			ds = new DelimiterFileDICheckService();
		} else if (Constants.FIXEDLENGTH.equals(fileType.toUpperCase())) {
			ds = new FixedLengthFileDICheckService();
		} else if (Constants.VARIABLELENGTH.equals(fileType.toUpperCase())) {
			ds = new VariableLengthFileDICheckService();
		} else if (Constants.DATABASE.equals(fileType.toUpperCase())) {
			ds = new DataBaseDICheckService();
		}
		return ds;
	}
	
}
