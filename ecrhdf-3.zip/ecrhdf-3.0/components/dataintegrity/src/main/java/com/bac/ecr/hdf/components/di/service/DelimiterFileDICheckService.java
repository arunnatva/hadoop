package com.bac.ecr.hdf.components.di.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DIErrorMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DISuccessMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityException;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;

/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */
public class DelimiterFileDICheckService extends DataIntegrityCheckService {

	final static Logger logger =  Logger.getLogger(DelimiterFileDICheckService.class);
	


	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.di.service.DataIntegrityCheckService#performDIValidations(com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration, 
	 * org.apache.spark.sql.DataFrame, 
	 * org.apache.spark.sql.types.StructType, 
	 * org.apache.spark.sql.hive.HiveContext, 
	 * java.lang.String, java.lang.String, 
	 * java.util.Map, 
	 * org.apache.spark.sql.types.StructType)
	 */
	public boolean performDIValidations(RawConfiguration config, 
										DataFrame inputDF, 
										StructType rawTableSchema,
										HiveContext hiveContext,
										String trailerRecord, 
										String headerRecord,
										Map<String,String> inputArgsMap,
										StructType srcFileSchemaMapping) throws DataIntegrityException {
		
		boolean headerCheckResult = true,trailerCheckResult = true;
		Map<String,List<String>> validationsMap = DataIntegrityUtil.getDIValidationsMap();
		HadoopLogger hadoopLogger = getHadoopLogger();
		if (config.isValidateHeader()) {
			headerCheckResult = performHeaderCheckValidation(headerRecord, config, inputArgsMap, validationsMap);
			
		}
		if (config.isValidateTrailer() && config.getTrailerCheckConfig().length > 0) {				    	
			trailerCheckResult = performTrailerCheckValidation(trailerRecord, config, inputDF, srcFileSchemaMapping, hiveContext, validationsMap);			
		}
		
		hadoopLogger.exception("DIVAlidations", this.getClass().getSimpleName(), 
				CommonUtils.getListValuesAsString(validationsMap.get(Constants.FAILED_VALIDATIONS)));
		
		hadoopLogger.info("DIVAlidations", this.getClass().getSimpleName(), 
				CommonUtils.getListValuesAsString(validationsMap.get(Constants.SUCCESS_VALIDATIONS)));

		if (validationsMap.get(Constants.FAILED_VALIDATIONS).size() > 0) {
			String errorMsgs = CommonUtils.getListValuesAsString(validationsMap.get(Constants.FAILED_VALIDATIONS));
			throw new DataIntegrityException(errorMsgs);
		}
		
		/*if (config.getColumnCheckConfig().length > 0) {
			columnCheckResult  = performColumnCheckValidation(config, inputDF, srcFileSchemaMapping, hiveContext);
		}*/
		
		return headerCheckResult && trailerCheckResult; 
	}

	
	

	/**
	 * performColumnCheckValidation method perform column validations like NULL check , DUP check and 
	 * log the messages, both success and failed messages. This method will throw DI exception if any
	 * column validations are failed.
	 * 
	 * @param config
	 * @param inputDf
	 * @param rawTableSchema
	 * @param hiveCtx
	 * @return boolean
	 */
	public  boolean performColumnCheckValidation(RawConfiguration config, DataFrame inputDf, StructType rawTableSchema, HiveContext hiveCtx){		
		boolean columnCheckPassed  = true;
		inputDf.registerTempTable(Constants.DICHECK_TEMPTABLE);
		Map<String,List<String>> validationsMap = DataIntegrityUtil.getDIValidationsMap();		
		StructField[] structField =  rawTableSchema.fields();
		String[] columnCheckConfig = config.getColumnCheckConfig();
		Map<String,List<String>> columnCheckMap = DataIntegrityUtil.getDIValidationCheckMap(columnCheckConfig);
		Set<String> columnCheckKeys = columnCheckMap.keySet();
		columnCheckKeys.forEach(key -> {
			performValidations(key, columnCheckMap.get(key), structField, inputDf, hiveCtx, validationsMap, config);
		});
		
		DataIntegrityUtil.logFailedValidations(validationsMap);
		DataIntegrityUtil.logSuccessValidations(validationsMap);
		if (validationsMap.get(Constants.FAILED_VALIDATIONS).size() > 0) {
			columnCheckPassed  = false;
		}
		return columnCheckPassed;
	}

	

	/**
	 * trailerCheckValidation method perform trailer validations like COUNT, SUM. This method splits the trailer record with specified delimiter
	 * and compares the provided values at specified indexes with the corresponding validations defined in the configuration.
	 * 
	 * @param trailerRecord
	 * @param config
	 * @param inputDf
	 * @param rawTableSchema
	 * @param hiveCtx
	 * @param validationsMap
	 * @return boolean
	 */
	public  boolean performTrailerCheckValidation(String trailerRecord, 
													RawConfiguration config, 
													DataFrame inputDf, 
													StructType rawTableSchema, 
													HiveContext hiveCtx, 
													Map<String,List<String>> validationsMap){		
		boolean trailerCheckPassed = true;		
		StructField[] structField =  rawTableSchema.fields();
		String[] trailerCheckConfig = config.getTrailerCheckConfig();
		Map<String,List<String>> trailerCheckMap = DataIntegrityUtil.getDIValidationCheckMap(trailerCheckConfig);
		String[] trailerInfo = trailerRecord.split( (config.getTrailerDelimiter() != null) && !config.getTrailerDelimiter().isEmpty() ? config.getTrailerDelimiter() : 
			config.getSrcFeedDelimiter() );
		Set<String> trailerCheckKeys = trailerCheckMap.keySet();
		for (String key: trailerCheckKeys) {
			boolean result = true;
			result = performValidations(key, trailerCheckMap.get(key), structField, inputDf, hiveCtx, validationsMap,trailerInfo, config);
			if (!result) {
				trailerCheckPassed = false;
			}
		}
		return trailerCheckPassed;
	}
	

	/**
	 * performHeaderCheckValidation method performs header validation. This method splits the header record with specified delimiter 
	 * and compares the header date in the file with the user provided headerDate.
	 * @param headerRecord
	 * @param config
	 * @param inputArgsMap
	 * @param validationsMap
	 * @return boolean
	 */
	public boolean performHeaderCheckValidation(String headerRecord, 
												RawConfiguration config, 
												Map<String,String> inputArgsMap, 
												Map<String,List<String>> validationsMap) {
		boolean headerCheckPassed  = true;
		String[] splitHeader = headerRecord.split( (config.getHeaderDelimiter() != null) && !config.getHeaderDelimiter().isEmpty() ? config.getHeaderDelimiter() : 
			config.getSrcFeedDelimiter() );
		//Arrays.stream(splitHeader).forEach(arg -> System.out.println("arg is " + arg));
		if (null != inputArgsMap.get(Constants.HEADER_DATE)) {
			String headerDate = inputArgsMap.get(Constants.HEADER_DATE).trim();
			if (!headerDate.equals(splitHeader[config.getHeaderDateIndex() - 1])) {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.HEADER_DATE.errorMessage(splitHeader[config.getHeaderDateIndex() - 1], inputArgsMap.get(Constants.HEADER_DATE)));
				headerCheckPassed  = false;
			} else {
				validationsMap.get(Constants.SUCCESS_VALIDATIONS)
					.add(DISuccessMessage.HEADER_DATE.successMessage(splitHeader[config.getHeaderDateIndex() - 1], inputArgsMap.get(Constants.HEADER_DATE)));
			}
		} else {
			validationsMap.get(Constants.FAILED_VALIDATIONS)
				.add(DIErrorMessage.HEADER_DATE.errorMessage(splitHeader[config.getHeaderDateIndex() - 1], inputArgsMap.get(Constants.HEADER_DATE)));									
			headerCheckPassed  = false;
		}
		return headerCheckPassed;
	}
	

	/**
	 * performValidations method invokes performValidations overloaded method passing correct number of arguments to perform DI validations. 
	 * @param columnValidation
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @param config
	 * @return boolean
	 */
	public boolean performValidations(String columnValidation, 
									List<String> columnsList, 
									StructField[] sf, 
									DataFrame inputDf, 
									HiveContext hiveCtx, 
									Map<String,List<String>> validationsMap, 
									RawConfiguration config ) {
		return performValidations(columnValidation, columnsList, sf, inputDf, hiveCtx, validationsMap,null, config);
	}
	

	/**
	 * performValidations  method invokes corresponding validation method depending on validation type like NULL,DUP,COUNT,SUM.
	 * @param columnValidation
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @param trailerInfo
	 * @param config
	 * @return boolean
	 */
	public boolean performValidations(String columnValidation, 
									List<String> columnsList, 
									StructField[] sf, 
									DataFrame inputDf, 
									HiveContext hiveCtx, 
									Map<String,List<String>> validationsMap,
									String[] trailerInfo, 
									RawConfiguration config ) {
		
		boolean validationResult = true;
        switch (columnValidation.trim().toUpperCase()) {
	        case Constants.NULLCHECK:
	        	validationResult = DataIntegrityUtil.performNullCheck(columnsList, sf, inputDf, hiveCtx, validationsMap);
	            break;
	        case Constants.DUPCHECK:
	        	validationResult = DataIntegrityUtil.performDupCheck(columnsList, sf, inputDf, hiveCtx, validationsMap);           
	            break;
	        case Constants.COUNTCHECK:
	        	validationResult = DataIntegrityUtil.performCountCheck(columnsList, sf, inputDf, hiveCtx, validationsMap, trailerInfo, config);
	        	if (validationResult) logger.info("*** count check is passed !! ***");
	            break;
	        case Constants.SUMCHECK:
	        	validationResult = DataIntegrityUtil.performSumCheck(columnsList, sf, inputDf, hiveCtx, validationsMap, trailerInfo);
	        	if(validationResult) logger.info("*** sum check is passed !! ***");
	            break;
	        default:	            		
        }
        return validationResult;
        
	}
	

	
}
