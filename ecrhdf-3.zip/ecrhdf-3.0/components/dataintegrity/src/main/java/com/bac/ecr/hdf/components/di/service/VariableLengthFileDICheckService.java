package com.bac.ecr.hdf.components.di.service;

import java.util.Map;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;

public class VariableLengthFileDICheckService extends DataIntegrityCheckService {

	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.di.service.DataIntegrityCheckService#performDIValidations(com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration, 
	 * org.apache.spark.sql.DataFrame, 
	 * org.apache.spark.sql.types.StructType, 
	 * org.apache.spark.sql.hive.HiveContext, 
	 * java.lang.String, 
	 * java.lang.String, 
	 * java.util.Map, 
	 * org.apache.spark.sql.types.StructType)
	 */
	@Override
	public boolean performDIValidations(RawConfiguration config,
			DataFrame inputDF, StructType rawTableSchema,
			HiveContext hiveContext, String trailerRecord, String headerRecord,
			Map<String, String> inputArgsMap, StructType srcFileSchemaMapping)
			throws Exception {
		throw new IllegalStateException("Currently Data Integrity is not supported for Variable Length Files.");
	}

	
}
