package com.bac.ecr.hdf.components.di.utils;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.alias.CredentialProvider;
import org.apache.hadoop.security.alias.CredentialProviderFactory;
import org.apache.log4j.Logger;

import com.bac.ecr.hdf.components.di.beans.DataSourcingEnums.DatabaseDriver;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;

/**
 * DaoUtil class is a utility class with methods pertaining to DB
 * 
 * @date 10/14/2016
 * @application name : ECR System Engineering
 * @author zkpsz5o(Ravi Kambalapally)
 * 
  */

public class DaoUtil {
	final static Logger logger = Logger.getLogger(DaoUtil.class);
	
	

	/**
	 * getDbConnection method returns RDBMS database connection. This method accepts credentials and driver class.
	 * 
	 * @param config
	 * @return Connection
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static Connection getDbConnection(RawConfiguration config) throws ClassNotFoundException, SQLException  {

		Connection dbConn;

		String credentialFile=config.getCredPath();
		String aliasName = config.getPasswordAliasName();
		String passWord = getPasswordFromAlias(credentialFile, aliasName);
		DatabaseDriver DBDRIVER = DatabaseDriver.valueOf(config.getSrcFeedPlatform().toUpperCase());

		logger.info("Provided Database : " + DBDRIVER);
		Class.forName(DBDRIVER.value());

		dbConn = DriverManager.getConnection(config.getDbConnectString(),config.getDbUser(),passWord);

		return dbConn;
	}

	/**
	 * close method closes a given database connection
	 * 
	 * @param dbConn
	 * @throws SQLException
	 */
	public static void close(Connection dbConn) throws SQLException {
		dbConn.close();
	}

	/**
	 * getPasswordFromAlias method is used to read the encrypted password
	 * @param credentialPath
	 * @param aliasName
	 * @return String
	 */
	public static String getPasswordFromAlias(String credentialPath,String aliasName) {
		char[] pwdChars = null;
		String clearPassword = null;
		try {
			Configuration conf = new Configuration();
			conf.set("hadoop.security.credential.provider.path", credentialPath);
			CredentialProvider credProvider = (CredentialProvider) CredentialProviderFactory.getProviders(conf).get(0);

			if (!(credProvider.getAliases()).contains(aliasName)) {
				throw new Exception("Error Reading Password Alias : \""+ aliasName+ "\" Provided alias doesn't exist in jceks provider directory path \""
								                                       + credentialPath.toString() + "\"");
			}

			pwdChars = conf.getPassword(aliasName);
			clearPassword = new String(pwdChars);

		} catch (Exception e) {
			
			e.printStackTrace();
			System.exit(1);
		}

		return clearPassword;

	}

	

	/**
	 * getSumFromTable method performs sum operation on the given RDBMS table column with the provided filter condition.
	 * 
	 * @param diConfig
	 * @param filterCond
	 * @param sumColNames
	 * @param conn
	 * @return Map<String,BigDecimal>
	 * @throws SQLException
	 */
	public static Map<String,BigDecimal> getSumFromTable(RawConfiguration diConfig,String filterCond,List<String> sumColNames,Connection conn) throws SQLException  {
		StringBuilder querySb = new StringBuilder();
        Map<String,BigDecimal> sumMap = new HashMap<String,BigDecimal>();
		for (String colName : sumColNames)
			querySb.append("sum(").append(colName).append("),");
		Statement stmt = conn.createStatement();
		ResultSet rs = null;
		rs = stmt.executeQuery(getQuery(diConfig,filterCond,querySb.toString().substring(0,querySb.toString().lastIndexOf(Constants.COMMA))));
		
		BigDecimal[] eachSumVal = new BigDecimal[sumColNames.size()];

		if (rs != null && rs.next()) {
			for (int i = 0; i < sumColNames.size(); i++) {
				eachSumVal[i] = BigDecimal.valueOf(Double.valueOf(rs.getString(i + 1)));
			}
		}
        for (int i = 0 ; i < sumColNames.size(); i++){
		sumMap.put(sumColNames.get(i),eachSumVal[i]);
		}
		return sumMap;
	}

	

	/**
	 * getCountFromTable method runs sql query to get the record count on the given 
	 * RDBMS table  with the provided filter condition.
	 * 
	 * @param diConfig
	 * @param conn
	 * @param filterCond
	 * @return long
	 * @throws SQLException
	 */
	public static long getCountFromTable(RawConfiguration diConfig,Connection conn,String filterCond) throws SQLException {
		Statement stmt = conn.createStatement();
		ResultSet rs = null;
		long result = 0;
		rs = stmt.executeQuery(getQuery(diConfig,filterCond, "COUNT(*)"));
		if (rs != null && rs.next())
			result = rs.getLong(1);

		return result;

	}

	

	/**
	 * getQuery method returns sql query as string to run on RDBMS.
	 * @param config
	 * @param filterCond
	 * @param queryType
	 * @return String
	 */
	public static String getQuery(RawConfiguration config,String filterCond, String queryType)  {

		String queryExec = null;
		
		if (null != config.getSrcFeedName() && !("NONE".equals(filterCond.toUpperCase()))){

			queryExec = "SELECT "+queryType+"  FROM "+config.getsrcDataBaseName()+"." +config.getSrcFeedName()+" where "+ filterCond;
			logger.info(Constants.PRINT_FORMATTER);
			logger.info("Query Executed is : " + "SELECT " + queryType + "  FROM " +config.getsrcDataBaseName()+"."+config.getSrcFeedName() + " where "+ filterCond);
			logger.info(Constants.PRINT_FORMATTER);

			} else {
			queryExec = "SELECT " + queryType + " FROM "+config.getsrcDataBaseName() +"."+config.getSrcFeedName();
			logger.info(Constants.PRINT_FORMATTER);;
			logger.info("Query Executed is : " + "SELECT "+queryType+ " FROM "+config.getsrcDataBaseName() + "."+ config.getSrcFeedName());
			logger.info(Constants.PRINT_FORMATTER);
		}

		return queryExec;

	}
	


}