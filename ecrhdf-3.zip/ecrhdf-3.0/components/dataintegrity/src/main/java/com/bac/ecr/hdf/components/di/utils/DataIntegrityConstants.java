package com.bac.ecr.hdf.components.di.utils;


/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */

public class DataIntegrityConstants {


	
	/**
	 * DISuccessMessage Enum lists all the success messages for DataIntegrity. Takes parameters and returns 
	 * appropriate success message to be logged in to logging framework . 
	 * 
	 */
	public enum DISuccessMessage {
	    HEADER_DATE("Header validation succeeded. Header date on input file is %s. Current Monthend date is %s."),
	    COUNT_CHECK("%s Trailer count check succeeded. HDFS file count is %s. Trailer count is %s."),
	    SUM_CHECK("%s Trailer sum check succeeded. Column %s sum is  %s. Trailer SUM is %s."),
	    NULL_CHECK("%s validation succeeded. Column %s has no null values."),
	    DUP_CHECK("%s validation succeeded. Column  %s has no duplicate values."),
	    DB_COUNT_CHECK( "Database count check succeeded. Imported file count is %s. Database record count is %s."),
	    DB_SUM_CHECK("Database sum check succeeded for column %s Imported file sum value is %s.  Database sum value is %s.");
	    	    
	    private String format;	    
	    private DISuccessMessage(String aFormat){	    	
	    	this.format = aFormat;
	    }	
	    
	    public  String successMessage(Object...args){
	    	return String.format(format, args);
	    }
	    
	}


	/**
	 * DIErrorCode Enum lists all the error codes for DataIntegrity.
	 * 
	 */
	public enum DIErrorCodes {
		DI_100("DI-100"),
		DI_101("DI-101"),
		DI_102("DI-102"),
		DI_103("DI-103"),
		DI_104("DI-104"),
		DI_105("DI-105");
				
		private final String errorcode;

		private DIErrorCodes(String errorcode) {
			this.errorcode = errorcode;
		}
		public String getErrorcode() {
			return errorcode;
		}		
	}
	
	/**
	 * DIErrorMessage Enum lists all the error messages for DataIntegrity. Takes parameters and returns 
	 * appropriate error message to be logged in to logging framework as well as to throw DIException. 
	 * 
	 */
	public enum DIErrorMessage {

	    INVALID_ARG(DIErrorCodes.DI_100.getErrorcode() , " - " + "Incorrect Validation Argument %s"),
	    HEADER_DATE(DIErrorCodes.DI_101.getErrorcode() , " - Header validation failed. Header date on input file is %s . Current Monthend date is %s."),
	    COUNT_CHECK(DIErrorCodes.DI_102.getErrorcode() , " - %s Trailer count check failed! HDFS file count is %s. Trailer count is %s."),
	    SUM_CHECK(DIErrorCodes.DI_103.getErrorcode() , " - %s Trailer sum check failed! Column %s sum is  %s. Trailer SUM is  %s."),
	    NULL_CHECK(DIErrorCodes.DI_104.getErrorcode() , " - %s validation failed. Column %s has null values."),
	    DUP_CHECK(DIErrorCodes.DI_105.getErrorcode() ," - %s validation failed. Column  %s has duplicate values."),
	    DB_COUNT_CHECK(DIErrorCodes.DI_102.getErrorcode() , " -  Database count check failed! Imported file count is %s. Database record count is %s."),
	    DB_SUM_CHECK(DIErrorCodes.DI_103.getErrorcode() , "-  Database sum check failed for column %s Imported file sum value is  %s. Database sum value is %s.");
	   

	    private String code;
	    private String format;	    
	    private DIErrorMessage(String aCode, String aFormat){
	    	this.code = aCode;
	    	this.format = aFormat;
	    }
	    
	    public  String errorMessage(Object...args){
	    	return code + String.format(format, args);
	    }
	}

}
