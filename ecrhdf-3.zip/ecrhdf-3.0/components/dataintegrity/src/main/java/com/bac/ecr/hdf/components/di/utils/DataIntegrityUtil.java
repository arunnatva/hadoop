package com.bac.ecr.hdf.components.di.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DIErrorMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DISuccessMessage;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;

/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */

public class DataIntegrityUtil {
	
	private final static Logger logger = Logger.getLogger(DataIntegrityUtil.class);
	
	/**
	 * getDIValidationCheckMap method groups same DI validations into seperate ArrayLists and 
	 * creates a HashMap as validation type as key and list of validations as value.
	 * @param columnsCheck
	 * @return Map<String,List<String>>
	 */
	public static Map<String,List<String>> getDIValidationCheckMap(String[] columnsCheck) {
		Map<String,List<String>> mp = new HashMap<String,List<String>>();
		List<String> nullCheck = new ArrayList<String>();
		List<String> dupCheck = new ArrayList<String>();
		List<String> countCheck = new ArrayList<String>();
		List<String> sumCheck = new ArrayList<String>();
		for (String col : columnsCheck) {
			String[] chkColumn = col.split(Constants.COMMA);
	        switch (chkColumn[0].trim().toUpperCase()) {
	        case Constants.NULLCHECK:
	        	nullCheck.add(col);
	        	mp.put(Constants.NULLCHECK, nullCheck);
	            break;
	        case Constants.DUPCHECK:
	        	dupCheck.add(col);
	        	mp.put(Constants.DUPCHECK, dupCheck);           
	            break;
	        case Constants.COUNTCHECK:
	        	countCheck.add(col);
	        	mp.put(Constants.COUNTCHECK, countCheck);           
	            break;
	        case Constants.SUMCHECK:
	        	sumCheck.add(col);
	        	mp.put(Constants.SUMCHECK, sumCheck);           
	            break;
	        default:	            		
	        }			
		}		
		return mp;
	}
	
	/**
	 * performNullCheck method validates NULL checks in the specified columns.
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @return boolean
	 */
	public static boolean performNullCheck(List<String> columnsList, StructField[] sf, DataFrame inputDf, HiveContext hiveCtx, Map<String,List<String>> validationsMap) {
		
		boolean validationResult = true;
		int i = 0;
		StringBuilder sb = new StringBuilder();		
		Map<String,StructField> structFieldMap = getStructFieldMap(sf);
		sb.append("select ");
		for(String column: columnsList) {
			if (null != column && column.split(Constants.COMMA).length == 2) {
				String[] col = column.split(Constants.COMMA);
				StructField structField = (StructField)structFieldMap.get(col[1].trim());  				
				sb.append("count(*) - count(" + structField.name().trim() + ") as " + structField.name().trim());
				if (i < columnsList.size() - 1) {
					sb.append(Constants.COMMA);
				}
				i++;
			} else {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.INVALID_ARG.errorMessage(column));
				validationResult = false;
				continue;
			}
		}
		sb.append(" from " + Constants.DICHECK_TEMPTABLE);
		Row nullCount = hiveCtx.sql(sb.toString()).head();
		StructType st = nullCount.schema();
		String[] counts = nullCount.mkString(Constants.COMMA).split(Constants.COMMA);
		for (int j = 0; j < counts.length; j++) {
			if (Long.parseLong(counts[j]) > 0) {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.NULL_CHECK.errorMessage(Constants.NULLCHECK + Constants.COMMA + st.apply(j).name(), st.apply(j).name()));
				validationResult = false;
			} else {
				validationsMap.get(Constants.SUCCESS_VALIDATIONS)
					.add(DISuccessMessage.NULL_CHECK.successMessage(Constants.NULLCHECK + Constants.COMMA + st.apply(j).name(), st.apply(j).name())) ;
			}
		}				
		return validationResult;
	}
		
	/**
	 * performDupCheck method validates duplicate records in the specified columns.
	 * 
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @return boolean
	 */
	public static boolean performDupCheck(List<String> columnsList, StructField[] sf, DataFrame inputDf, HiveContext hiveCtx, Map<String,List<String>> validationsMap) {
		
		boolean validationResult = true;
		Map<String,StructField> structFieldMap = getStructFieldMap(sf);
		for(String column: columnsList) {
			if (null != column && column.split(Constants.COMMA).length == 2) {
				String[] col = column.split(Constants.COMMA);
				StructField structField = (StructField)structFieldMap.get(col[1].trim());
				long dupCount = inputDf.groupBy(structField.name()).count().filter("`count` > 1").count();
				if (dupCount > 1) {
					validationsMap.get(Constants.FAILED_VALIDATIONS).add(DIErrorMessage.DUP_CHECK.errorMessage(column, structField.name()));
					validationResult = false;
				} else {
					validationsMap.get(Constants.SUCCESS_VALIDATIONS).add(DISuccessMessage.DUP_CHECK.successMessage(column, structField.name()));
				}
			} else {				
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.INVALID_ARG.errorMessage(column));
				validationResult = false;
				continue;
			}			
		}
		return validationResult;
	}
	
	

	/**
	 * performCountCheck method will validate the record count of the source data with the specified configuration count.
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @param trailerInfo
	 * @param config
	 * @return boolean
	 */
	public static boolean performCountCheck(List<String> columnsList,StructField[] sf,DataFrame  inputDf,HiveContext  hiveCtx,Map<String,List<String>> validationsMap, String[] trailerInfo, RawConfiguration config) {
	
		boolean validationResult = true;
		for(String column: columnsList) {			
			if (null != column && column.split(Constants.COMMA).length == 2) {				
				String[] col = column.split(Constants.COMMA);				
				long count = inputDf.count();

				long trailerCount = Long.parseLong(trailerInfo[Integer
						.parseInt(col[1]) - 1]);
				if (config.isTrailerCountHasHdrTrlr()) {
					if (config.isHasHeader()) {
						trailerCount -= 1;
					}

					if (config.isHasTrailer()) {
						trailerCount -= 1;
					}
				} 
				
				if (count != trailerCount) {
					validationsMap.get(Constants.FAILED_VALIDATIONS)
						.add(DIErrorMessage.COUNT_CHECK.errorMessage(column, String.valueOf(count), trailerInfo[Integer.parseInt(col[1]) - 1 ]));
					validationResult = false;
				} else {
					validationsMap.get(Constants.SUCCESS_VALIDATIONS)
						.add(DISuccessMessage.COUNT_CHECK.successMessage(column, String.valueOf(count), trailerInfo[Integer.parseInt(col[1]) - 1 ]));					
				}
			} else {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.INVALID_ARG.errorMessage(column));
				validationResult = false;
				continue;
			}
		}
		return validationResult;
	}

	/**
	 * performSumCheck method will get the sum of each  column specified in the configuration 
	 * and compares it with sum value provided in the file. 
	 * @param columnsList
	 * @param sf
	 * @param inputDf
	 * @param hiveCtx
	 * @param validationsMap
	 * @param trailerInfo
	 * @return boolean
	 */
	public static boolean performSumCheck(List<String> columnsList,StructField[] sf,DataFrame  inputDf,HiveContext  hiveCtx,Map<String,List<String>> validationsMap, String[] trailerInfo) {
		
		Map<String,String> indexMap = new HashMap<String,String>();
		Map<String,String> columnMap = new HashMap<String,String>();
		boolean validationResult = true;
		for(String column: columnsList) {
			if (null != column && column.split(Constants.COMMA).length == 3) {
				String[] col = column.split(Constants.COMMA);
				StructField structField = sf[Integer.parseInt(col[2]) - 1];
				indexMap.put(structField.name().trim(), column);
				columnMap.put(structField.name().trim(), "sum");
			} else {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.INVALID_ARG.errorMessage(column));
				validationResult = false;
				continue;
			}			
		}				
		Row fieldSum = inputDf.agg(columnMap).head();
		StructType st = fieldSum.schema();
		String[] counts = fieldSum.mkString(Constants.COMMA).split(Constants.COMMA);
		for (int i = 0; i < counts.length; i++ ) {
			String fieldName = getSumStriped(st.apply(i).name().trim()).trim();			
			String column = indexMap.get(fieldName.trim());			
			String columnSumIndex = getValue(column);									
			if (BigDecimal.valueOf(Double.valueOf(counts[i])).compareTo(BigDecimal.valueOf(Double.parseDouble(trailerInfo[Integer.parseInt(columnSumIndex) - 1]))) != 0) {
				validationsMap.get(Constants.FAILED_VALIDATIONS)
					.add(DIErrorMessage.SUM_CHECK.errorMessage(column,fieldName, BigDecimal.valueOf(Double.valueOf(counts[i])).toString(), trailerInfo[Integer.parseInt(columnSumIndex) - 1]));
				validationResult = false;
			} else {
				validationsMap.get(Constants.SUCCESS_VALIDATIONS)
					.add(DISuccessMessage.SUM_CHECK.successMessage(column,fieldName, BigDecimal.valueOf(Double.valueOf(counts[i])).toString(), trailerInfo[Integer.parseInt(columnSumIndex) - 1]));					
			}
		}
		return validationResult;
		
	}

	
	/**
	 * getValue method returns the required value after splitting the string with comma.
	 * @param column
	 * @return String
	 */
	public static String getValue(String column)  {		
		String[] index = column.split(Constants.COMMA);
		return index[1];
	}
	
	/**
	 * getSumStriped returns the sub string after stripping \"sum(\" \")\" from the original string. 
	 * @param fieldName
	 * @return String
	 */
	public static String getSumStriped(String fieldName) {
		return fieldName.substring(4).substring(0, fieldName.substring(4).length() - 1 );
	}
	
	/**
	 * getDIValidationsMap method returns map of arrayList for capturing success and failed validations.
	 * @return Map<String,List<String>>
	 */
	public static Map<String,List<String>> getDIValidationsMap() {
		Map<String,List<String>> validationsMap = new HashMap<String,List<String>>();
		List<String> successValidationLst = new ArrayList<String>();
		List<String> failedValidationLst = new ArrayList<String>();
		validationsMap.put(Constants.SUCCESS_VALIDATIONS, successValidationLst);
		validationsMap.put(Constants.FAILED_VALIDATIONS, failedValidationLst);
		return validationsMap;
	}


	/**
	 * logSuccessValidations method logs the success validations messages to hadoop using logging framework.
	 * @param validationsMap
	 */
	public static void logSuccessValidations(Map<String,List<String>> validationsMap) {		
		String succesLogs = CommonUtils.getListValuesAsString(validationsMap.get(Constants.SUCCESS_VALIDATIONS));			
		logger.info(succesLogs);
	}

	
	/**
	 * logFailedValidations  method logs the failed validations messages to hadoop using logging framework.
	 * @param validationsMap
	 */
	public static void logFailedValidations(Map<String,List<String>> validationsMap) {		
		String failedLogs = CommonUtils.getListValuesAsString(validationsMap.get(Constants.FAILED_VALIDATIONS));
		logger.info(failedLogs);			
		
	}

	
	/**
	 * getStructFieldMap returns the map of StructFields with field name as key.
	 * @param sf
	 * @return Map<String,StructField>
	 */
	public static Map<String,StructField> getStructFieldMap(StructField[] sf) {
		Map<String,StructField> structFieldMap = new HashMap<String,StructField>();
		Arrays.stream(sf).forEach(structFied -> { 
			structFieldMap.put(structFied.name().trim(), structFied);
		});
		return structFieldMap;
	}

	
}
