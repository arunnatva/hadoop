package com.bac.ecr.hdf.components.di.utils;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DIErrorMessage;
import com.bac.ecr.hdf.components.di.utils.DataIntegrityConstants.DISuccessMessage;

public class TestDataIntegrityConstants {

	@Test(enabled=true)
	public void testgetSucessMessage(){
		
		Assert.assertEquals(
				DIErrorMessage.INVALID_ARG.errorMessage("ABC"),
				"DI-100 - Incorrect Validation Argument ABC");
		
		Assert.assertEquals(
				DIErrorMessage.HEADER_DATE.errorMessage("ABC","XYZ"),
				"DI-101 - Header validation failed. Header date on input file is ABC . Current Monthend date is XYZ.");
		
		Assert.assertEquals(
				DIErrorMessage.SUM_CHECK.errorMessage("ABC","XYZ","IJK","LMN"),
				"DI-103 - ABC Trailer sum check failed! Column XYZ sum is  IJK. Trailer SUM is  LMN.");
		
	}
	@Test(enabled=true)
	public void testgetErrorMessage(){
		
		/*
		 * 	    HEADER_DATE("Header validation succeeded. Header date on input file is %s. Current Monthend date is %s."),
	    COUNT_CHECK("%s Trailer count check succeeded. HDFS file count is %s. Trailer count is %s."),
	    SUM_CHECK("%s Trailer sum check succeeded. Column %s sum is  %s. Trailer SUM is %s."),
		 */
		
		Assert.assertEquals(
				DISuccessMessage.HEADER_DATE.successMessage("ABC","XYZ"),
				"Header validation succeeded. Header date on input file is ABC. Current Monthend date is XYZ.");
		
		Assert.assertEquals(
				DISuccessMessage.COUNT_CHECK.successMessage("ABC","XYZ","IJK"),
				"ABC Trailer count check succeeded. HDFS file count is XYZ. Trailer count is IJK.");
		
		Assert.assertEquals(
				DISuccessMessage.SUM_CHECK.successMessage("ABC","XYZ","IJK","LMN"),
				"ABC Trailer sum check succeeded. Column XYZ sum is  IJK. Trailer SUM is LMN.");

	}
	
	
}
