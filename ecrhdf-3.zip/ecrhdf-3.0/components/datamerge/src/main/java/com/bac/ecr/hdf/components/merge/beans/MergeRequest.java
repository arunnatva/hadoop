package com.bac.ecr.hdf.components.merge.beans;

import java.util.ArrayList;
import java.util.List;

public class MergeRequest {

	private String mergeType;
	private boolean removeDups;
	private List<InFeed> inFeed = new ArrayList<InFeed>();
	private OutFeed outFeed;
	private String joinColumns;
	private String overlay;
	private String overlayFields;

	public String getMergeType() {
		return mergeType;
	}

	public void setMergeType(String mergeType) {
		this.mergeType = mergeType;
	}

	public boolean isRemoveDups() {
		return removeDups;
	}

	public void setRemoveDups(boolean removeDups) {
		this.removeDups = removeDups;
	}

	public List<InFeed> getInFeed() {
		return inFeed;
	}
	public void setInFeed(List<InFeed> inFeed) {
		this.inFeed = inFeed;
	}

	public OutFeed getOutFeed() {
		return outFeed;
	}

	public void setOutFeed(OutFeed outFeed) {
		this.outFeed = outFeed;
	}

	public String getJoinColumns() {
		return joinColumns;
	}

	public void setJoinColumns(String joinColumns) {
		this.joinColumns = joinColumns;
	}

	public String getOverlay() {
		return overlay;
	}

	public void setOverlay(String overlay) {
		this.overlay = overlay;
	}

	public String getOverlayFields() {
		return overlayFields;
	}

	public void setOverlayFields(String overlayFields) {
		this.overlayFields = overlayFields;
	}

	

	@Override
	public String toString() {
		return "MergeRequest [mergeType=" + mergeType + ", removeDups=" + removeDups + ", inFeed=" + inFeed
				+ ", outFeed=" + outFeed + ", joinColumns=" + joinColumns + ", overlay=" + overlay + "]";
	}
	
	
	public static class InFeed {

		private String feedName;
		private String filterCond;

		public InFeed() {};
		
		public InFeed(String feedName, String filterCond) {
			this.feedName = feedName;
			this.filterCond = filterCond;
		}
		
		public String getFeedName() {
			return feedName;
		}

		public void setFeedName(String feedName) {
			this.feedName = feedName;
		}

		public String getFilterCond() {
			return filterCond;
		}


		public void setFilterCond(String filterCond) {
			this.filterCond = filterCond;
		}

		@Override
		public String toString() {
			return "InFeed [feedName=" + feedName + ", filterCond=" + filterCond + "]";
		}
		
	}

	
	public static class OutFeed {

		private String feedName;
		private List<String> partitions = new ArrayList<String>();

		public OutFeed() {};
		
		public OutFeed(String feedName, List<String> partitions) {
			this.feedName = feedName;
			this.partitions = partitions;
		}
		
		public String getFeedName() {
			return feedName;
		}

		public void setFeedName(String feedName) {
			this.feedName = feedName;
		}

		public List<String> getPartitions() {
			return partitions;
		}

		public void setPartitions(List<String> partitions) {
			this.partitions = partitions;
		}
		
		public List<String> getStaticPartitions() {
			List<String> staticPartitions = new ArrayList<String>();
			for (String partition : partitions) {
				if (partition.contains("=")) {
					staticPartitions.add(partition);
				}
			}
			return staticPartitions;
		}
		
		public List<String> getDynamicPartitions() {
			List<String> dynamicPartitions = new ArrayList<String>();
			for (String partition : partitions) {
				if (! partition.contains("=")) {
					dynamicPartitions.add(partition);
				}
			}
			return dynamicPartitions;
		}

		@Override
		public String toString() {
			return "OutFeed [feedName=" + feedName + ", partitions=" + partitions + "]";
		}
		
		/**To get the static partition column name
		 * @return
		 */
		public List<String> getStaticPartitionsColumns(){
			List<String> staticPartitionsColumn = new ArrayList<String>();
			for (String partition : partitions) {
				if (partition.contains("=")) {
					String[] staticPartCol = partition.split("=");
					staticPartitionsColumn.add(staticPartCol[0]);
				}
			}
			return staticPartitionsColumn;
		}

	}
	
	
}




