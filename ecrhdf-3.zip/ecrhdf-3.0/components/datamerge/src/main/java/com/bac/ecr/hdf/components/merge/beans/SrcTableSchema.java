package com.bac.ecr.hdf.components.merge.beans;


import java.util.Collections;
import java.util.List;

public class SrcTableSchema {

	private String srcTableName;
	private List<String> colNames;
	private List<String> colDataTypes;
	private List<String> colNamesDataTypes;

	public List<String> getColNamesDataTypes() {
		return colNamesDataTypes;
	}

	public void setColNamesDataTypes(List<String> colNamesDataTypes) {
		this.colNamesDataTypes = colNamesDataTypes;
	}

	public String getSrcTableName() {
		return srcTableName;
	}

	public void setSrcTableName(String srcTableName) {
		this.srcTableName = srcTableName;
	}

	public List<String> getColNames() {
		return colNames;
	}

	public void setColNames(List<String> colNames) {
		this.colNames = colNames;
	}

	public List<String> getColDataTypes() {
		return colDataTypes;
	}

	public void setColDataTypes(List<String> colDataTypes) {
		this.colDataTypes = colDataTypes;
	}

	
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("Table Name : ").append(
				srcTableName).append("\n");
		sb.append("colName : DataType ").append(String.join(",", colNamesDataTypes)).append("\n");			
		return sb.toString();
	}
	
	public String print(){
		
		StringBuilder sb = new StringBuilder("Table Name : ").append(
				srcTableName).append("\n");
		sb.append("colName : ").append(String.join(",", colNames)).append("\n").append("colDataTypes : ").append(String.join(",", colDataTypes)).append("\n");			
		return sb.toString();
		
	}

}
