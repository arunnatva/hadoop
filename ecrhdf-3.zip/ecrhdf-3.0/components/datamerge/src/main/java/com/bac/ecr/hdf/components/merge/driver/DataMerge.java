package com.bac.ecr.hdf.components.merge.driver;

import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.service.AbstractMergeService;
import com.bac.ecr.hdf.components.merge.service.ColumnLevelMergeService;
import com.bac.ecr.hdf.components.merge.service.RowLevelMergeService;
import com.bac.ecr.hdf.components.merge.utils.DataMergeConstants;
import com.bac.ecr.hdf.components.merge.utils.DataMergeConstants.MergeErrorCodes;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.components.merge.utils.DataMergeUtil;
import com.bac.ecr.hdf.components.merge.utils.ValidateInputJson;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.components.utils.commonutils.HdfsUtils;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogFactory;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;



/**
 * @author zkzb9lr
 * @Description This is the main class for Data Merge process where multiple source datasets are merged into one target dataset.
 */
public class DataMerge {

	final static Logger logger = Logger.getLogger(DataMerge.class);
	static HadoopLogger hadoopLogger = null;

	/**
	 * @Description: Main method to read the command line arguments and invoke DataMerge Service
	 * @parameters : List of arguments (1) Merge Type (Row level or column level) (2) Remove Dups / Ignore Dups (3) Multiple input feeds (4) Output Feed. These arguments dont have to be in the specified order
	 *               Example: mergeType=row removeDups=Y infeed=srcdb1.tbl1,filter=filtercondition1 infeed=srcdb2.tbl2,filter=filtercondition2 outfeed=srcdb3.tbl3,partitions{partkey1='555',partkey2}
	 * @return : None
	 * @throws : Exception, DataMergeException
	 */

	public static void main(String[] args) throws Exception,DataMergeException {

		SparkConf sparkConf = new SparkConf().setAppName("Data Merge");
		sparkConf.set("spark.sql.parquet.compression.codec", "snappy");
		Configuration conf = new Configuration();			
		FileSystem fs = FileSystem.get(conf);
		JavaSparkContext jsc = new JavaSparkContext(sparkConf);
		SQLContext sqlCtx = new SQLContext(jsc.sc());
		HiveContext hiveCtx = new HiveContext(jsc.sc());
		hiveCtx.setConf("hive.exec.dynamic.partition", "true");
		hiveCtx.setConf("hive.exec.dynamic.partition.mode", "nonstrict");
		hadoopLogger = HadoopLogFactory.getInstance(DataMerge.class.getSimpleName(), DDI_LAYER.MERGE, jsc.hadoopConfiguration());
		String mergeConfigJsonString = null;
		Map<String,String> inputArgsMap = CommonUtils.getInputArgsMap(args);
		
		try {
			
			if (!DataMergeUtil.validateMergeCommandLineArgs(inputArgsMap)) {
				logger.error(MergeErrorCodes.MERGE_100.value());
				throw new DataMergeException(MergeErrorCodes.MERGE_100.value());
			}
			
			try {
				mergeConfigJsonString = HdfsUtils.readHdfsFile(fs, new Path(inputArgsMap.get(DataMergeConstants.MERGE_JSON)));
				logger.info("merge json file path : "+inputArgsMap.get(DataMergeConstants.MERGE_JSON));
				logger.info("merge json string before substitution : "+mergeConfigJsonString);
			    mergeConfigJsonString = CommonUtils.substituteDynamicValues(mergeConfigJsonString, inputArgsMap);
			    logger.info("merge json string with replaced values : "+mergeConfigJsonString);
			} catch(Exception e) {
				logger.error(MergeErrorCodes.MERGE_108.value());
				throw new DataMergeException(MergeErrorCodes.MERGE_108.value());
			}
			
			MergeRequest mergeRequest = new MergeRequest();
			
			try {
				mergeRequest = (MergeRequest) JsonParseUtil.parseJSON(mergeConfigJsonString, mergeRequest);
				ValidateInputJson.validateJson(mergeRequest);
			} catch (Exception e) {
				logger.error(MergeErrorCodes.MERGE_109.value());
				throw new DataMergeException(MergeErrorCodes.MERGE_109.value(),e);
			}
			
			
			if (mergeRequest.getMergeType().equalsIgnoreCase(
					DataMergeConstants.COLUMN)) {
				logger.info("Starting Column level merge process.");
				if(DataMergeUtil.compareSchemas(mergeRequest, hiveCtx)) {
					AbstractMergeService dmService = new ColumnLevelMergeService(mergeRequest,hiveCtx,jsc,hadoopLogger);
					dmService.processMergeRequest(mergeRequest);
				}
				
			} else {	
				if(DataMergeUtil.compareSchemas(mergeRequest, hiveCtx)){ //Source source schema compare
					if(DataMergeUtil.extractCompareTrgSrcSchemas(mergeRequest, hiveCtx)){ //source target schema compare
						logger.info("Starting Row level merge process.");
						AbstractMergeService dmService = new RowLevelMergeService(
								jsc, sqlCtx, hiveCtx,hadoopLogger);
						dmService.processMergeRequest(mergeRequest);
					}
				}
			}
			hadoopLogger.info("DataMerge", mergeRequest.getInFeed().toString() + "." + mergeRequest.getOutFeed().getFeedName(),"Data Merge completed.");

		}  catch (DataMergeException dme) {
			logger.error(dme.getMessage());
			hadoopLogger.exception("DataMerge", dme.getMessage());
			dme.printStackTrace();
			throw dme;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			hadoopLogger.close();
			jsc.close();
		}

	}


	/**
	 * mergeData method merges multiple input DataFrames and returns the output DataFrame 
	 * @param mergeRequest : An Object that holds all command line arguments passed
	 * @param jsc  		Spark Context 
	 * @param inputDF   Dataframe
	 * @param hadoopLogger HadoopLogger
	 * @return DataFrame
	 */	

	public static DataFrame mergeData(boolean removeDups, String mergeType, JavaSparkContext jsc, SQLContext sqlCtx, HiveContext hiveCtx,DataFrame[] inputDFArray,HadoopLogger hadoopLogger) throws Exception{

		AbstractMergeService dmService = null;

		if (mergeType.equalsIgnoreCase(DataMergeConstants.COLUMN)) {
			//dmService = new ColumnLevelMergeService(hiveCtx,jsc,hadoopLogger);
		} else {
			dmService = new RowLevelMergeService(jsc, sqlCtx, hiveCtx,hadoopLogger);
		}

		return dmService.doMerge(removeDups,mergeType,inputDFArray);

	}


	/**
	 * mergeData method merges data from list of hive tables passesd as command line arguments and writes the merged data to the target table
	 * @param mergeRequest : An Object that holds all command line arguments passed 
	 * @param jsc  		Spark Context
	 * @param hadoopLogger HadoopLogger
	 * @return None
	 */	

	public static void mergeData(MergeRequest mergeRequest, JavaSparkContext jsc, SQLContext sqlCtx, HiveContext hiveCtx,HadoopLogger hadoopLogger) throws Exception{
		AbstractMergeService dmService = new RowLevelMergeService(jsc, sqlCtx, hiveCtx,hadoopLogger);
		dmService.processMergeRequest(mergeRequest);			
	}
}
