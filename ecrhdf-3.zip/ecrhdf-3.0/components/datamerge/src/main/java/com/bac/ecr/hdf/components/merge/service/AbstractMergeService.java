package com.bac.ecr.hdf.components.merge.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.components.merge.utils.DataMergeConstants.MergeErrorCodes;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;

public abstract class AbstractMergeService {

	final static Logger logger = Logger.getLogger(AbstractMergeService.class);

	private JavaSparkContext jsc;
	private HiveContext hiveCtx;
	private HadoopLogger hadoopLogger;
	private SQLContext sqlCtx;
	
	/**
	 *  Constructor for Abstract class. To assume abstracted method variables.
	 * @param jsc
	 * @param sqlCtx
	 * @param hiveCtx
	 * @param hadoopLogger
	 */

	public AbstractMergeService(JavaSparkContext jsc, SQLContext sqlCtx, HiveContext hiveCtx, HadoopLogger hadoopLogger) {
		this.jsc = jsc;
		this.hiveCtx = hiveCtx;
		this.sqlCtx = sqlCtx;
		this.hadoopLogger = hadoopLogger;
	}

	/**
	 * processMergeRequest method takes mergeInput arguments as MergeRequest object and process merging of tables.
	 * @param mergeArgs
	 * @throws DataMergeException
	 */
	public abstract void processMergeRequest(MergeRequest mergeArgs) throws DataMergeException;
		
	
	/**
	 * doMerge method takes array of DataFrames and return a DataFrame after merging all the DataFrames.
	 * @param dfArray
	 * @return DataFrame
	 * @throws DataMergeException
	 */
	public abstract DataFrame doMerge(DataFrame... dfArray) throws DataMergeException;
	
	/**
	 * doMerge method takes boolean value to  either remove duplicate records , type of merge either Row merge or Column merge and
	 * array of DataFrames and return a DataFrame after merging all the DataFrames.
	 * @param removeDups
	 * @param mergeType
	 * @param dfArray
	 * @return DataFrame
	 * @throws DataMergeException
	 */
	public abstract DataFrame doMerge(boolean removeDups, String mergeType, DataFrame[] dfArray) throws DataMergeException;	
	
	/**
	 * writeToTarget method writes the DataFrame to target table.
	 * @param df
	 * @param mergeArgs
	 * @throws DataMergeException
	 */
	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.merge.service.AbstractMergeService#writeToTarget(org.apache.spark.sql.DataFrame, com.bac.ecr.hdf.components.merge.beans.MergeRequest)
	 */
	public void writeToTarget(DataFrame inputDF, MergeRequest mergeArgs) throws DataMergeException {		
		String targetTable = mergeArgs.getOutFeed().getFeedName();		
		try {
			StructType targetTblSchema = SchemaOperationsUtil.getSchemaFromHive(targetTable, this.getHiveCtx());			
			List<String> partitions = mergeArgs.getOutFeed().getPartitions();			
			if (null != partitions && partitions.size() > 0) {
				logger.info("******* Inserting data into partitioned table.");
				 Map<String,String> partitionsMap = getPartitionColValuesAsMap(partitions);
				 StructType srcSchema = inputDF.schema();
				 List<String> staticPartitions = SchemaOperationsUtil.getColsNotInSrcLst(targetTblSchema, srcSchema);
				 for (int i = 0; i < staticPartitions.size(); i++) {
					 if (StringUtils.isNotBlank(partitionsMap.get(staticPartitions.get(i).trim()))) {
						 inputDF = SchemaOperationsUtil.addColumnToDF(inputDF, 
								 staticPartitions.get(i).trim(), 
								 partitionsMap.get(staticPartitions.get(i).trim()), 
								 targetTblSchema);
					 } else {
						 throw new DataMergeException(MergeErrorCodes.MERGE_110.value() + " " + staticPartitions.get(i).trim());
					 }
				 }
				 String[] partitionColsArry = getPartitionColsArry(partitions);
				List<String> nonPartitionColsArry = SchemaOperationsUtil.getNonPartitionColsLst(targetTblSchema, Arrays.asList(partitionColsArry));				
				SchemaOperationsUtil.writeDFToPartitionedTable(partitionColsArry, 
																nonPartitionColsArry.toArray(new String[nonPartitionColsArry.size()]),
																inputDF, this.getHiveCtx() , targetTable);
			} else {
				logger.info("******* Inserting data into non partitioned table.");
				SchemaOperationsUtil.writeDFToNoPartitionTable(inputDF, this.getHiveCtx() , targetTable, targetTblSchema);
			}
		} catch(Exception e) {
			//e.printStackTrace();
			throw new DataMergeException(e);
		}

		
		
	}

	
	/**
	 * getPartitionColValuesAsMap method takes partitions columns list and convert that to HashMap 
	 * to set key value pairs for static partition columns.
	 * @param partitions
	 * @return Map<String,String>
	 */
	public Map<String,String> getPartitionColValuesAsMap(List<String> partitions) {
		Map<String,String> partitionsMap = new HashMap<String,String>();
		for (int i = 0; i < partitions.size(); i++) {
			String[] column = partitions.get(i).split("=");
			if (null != column && column.length > 0) {
				if (column.length >= 2) {
					partitionsMap.put(column[0].trim(), column[1].trim());
				} else {
					partitionsMap.put(column[0], "");
				}
			}
		}
		return partitionsMap;		
	}
	
	/**
	 * Provides the partitions columns as array
	 * @param partitions
	 * @return
	 */
	public String[] getPartitionColsArry(List<String> partitions) {
		String[] partitionColsArry = new String[partitions.size()];
		for (int i = 0; i < partitions.size(); i++) {
			String[] column = partitions.get(i).split("=");
			partitionColsArry[i] = column[0].trim();
		}
		return partitionColsArry;
	}
	

	protected JavaSparkContext getJsc() {
		return jsc;
	}

	
	protected HiveContext getHiveCtx() {
		return hiveCtx;
	}

	protected HadoopLogger getHadoopLogger() {
		return hadoopLogger;
	}	
	
	protected SQLContext getSqlCtx() {
		return sqlCtx;
	}
}
