package com.bac.ecr.hdf.components.merge.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.InFeed;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.OutFeed;
import com.bac.ecr.hdf.components.merge.utils.DataMergeConstants;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.google.common.base.Preconditions;

/**
 * 	 * <br>
	 * 	DataFrame sourceDataFrame - This DataFrame represents the actual data.
	 *  DataFrame overLayDataFrame - This DataFrame represents the data using which the source data will be overlayed
	 *  Column Merge can be defined in such a way that Column value from Overlay DataFrame will be overlayed onto the 
	 *  column with the same name in the source table.
	 *  For Example:
	 *  Table - Source (id, name, age)
	 *  id - name - age
	 *  1  - John - 33
	 *  2  - Amy  - 34
	 *  3  - Steve - 36
	 *  
	 *  Table - Overlay (id,name,age)
	 *  id - name - age
	 *  1  - John - 33
	 *  2  - Amy  - 43
	 *  4  - Andy - 45
	 *  Output Merged Data Frame:
  	 *  id - name - age
	 *  1  - John - 33
	 *  2  - Amy  - 34
	 *  3  - Steve - 36
	 *   
	 *   Points to note in the Above merge are:
	 *   1) age of Amy has been adjusted in the overlay table and the same has been overlaid into the merged output
	 *   2) Merged output's count and Source output count will be the same provided the join is correctly provided.
	 *   3) If there are any rows in Overlay table that doesn't appear in the Source table, those rows will be ignored
	 *   4) If the overlay column's value is null then the source column value will be carried to the Merged output
	 *   5) If both overlay column value and its respective source column values are null then null will be retained in the merged output
	 *  
 * @author zk8m1ao
 * @version $Revision: 1.0 $
 */
public class ColumnLevelMergeService extends AbstractMergeService {

	final static Logger logger = Logger.getLogger(ColumnLevelMergeService.class);
	
	private MergeRequest mergeRequest;
	
	/**
	 * Constructor for ColumnLevelMergeService.
	 * @param aMergeRequest MergeRequest
	 * @param aHiveCtx HiveContext
	 * @param aJsc JavaSparkContext
	 * @param aHadoopLogger HadoopLogger
	 */
	public ColumnLevelMergeService(MergeRequest aMergeRequest, HiveContext aHiveCtx, JavaSparkContext aJsc, HadoopLogger aHadoopLogger) {
		super(aJsc,  new SQLContext(aJsc.sc()), aHiveCtx, aHadoopLogger);
		Preconditions.checkNotNull(aMergeRequest, "MergeRequest Object can not be null");
		Preconditions.checkNotNull(aJsc, "SparkContext Object can not be null");
		Preconditions.checkNotNull(aHadoopLogger, "HadoopLogger Object can not be null");
		Preconditions.checkNotNull(aHiveCtx, "HiveContext Object can not be null");
	
		this.mergeRequest = aMergeRequest;
	}
	
	/**
	 * This method will read the input feeds , overlay feed and will merge the feeds columnwise
	 * The data will be persisted into the outFeed 
	 * @param mergeRequest MergeRequest
	 * @throws DataMergeException  */
	@Override
	public void processMergeRequest(MergeRequest mergeRequest) throws DataMergeException {
		this.mergeRequest = mergeRequest;
		doMerge();
	}
	
	/**
	 * This method will read the input feeds , overlay feed and will merge the feeds columnwise
	 * The data will be persisted into the outFeed 
	 * @return DataFrame * @throws DataMergeException  */
	public void  doMerge() throws DataMergeException{
		
		List<InFeed> inputFeeds = mergeRequest.getInFeed();
		InFeed inputFeed = null;
		InFeed overLayFeed = null;
		
		for (InFeed feed: inputFeeds){
			if (mergeRequest.getOverlay().equalsIgnoreCase(feed.getFeedName())){
				overLayFeed = feed;
			}else{
				inputFeed = feed;
			}
		}
		DataFrame inputFeedDataFrame = buildDataFrameFromFeed(inputFeed);
		DataFrame overLayFeedDataFrame = buildDataFrameFromFeed(overLayFeed);
		
		DataFrame mergedDataFrame = doMerge(inputFeedDataFrame, overLayFeedDataFrame);
		
		String outputDataFrameTempTable = "outputDataFrameTempTable";
		mergedDataFrame.registerTempTable(outputDataFrameTempTable);
		
		try{
			
			writeToTarget(mergedDataFrame, mergeRequest);
			
		}catch(Exception e){
			throw new DataMergeException(DataMergeConstants.MergeErrorCodes.MERGE_106.value(), e);
		}
		
	}

	/**
	 * Method buildMergedDataPersistenceQuery.
	 * @param schema StructType
	 * @param outputDataFrameTempTable String
	 * @return String
	 */
	public String buildMergedDataPersistenceQuery(StructType schema, String outputDataFrameTempTable){
		StringBuilder hiveQuery  = new StringBuilder();
		OutFeed outFeed = mergeRequest.getOutFeed();
		
		List<String> fields = new ArrayList<String>();
		
		for (StructField field : schema.fields()){
			if (! outFeed.getDynamicPartitions().contains(field.name()))
				fields.add(field.name());
		}
		
		if (outFeed.getPartitions() == null || outFeed.getPartitions().isEmpty()){
			hiveQuery.append(("INSERT OVERWRITE TABLE " + outFeed.getFeedName() + " SELECT * FROM " + outputDataFrameTempTable));
		}else{
			hiveQuery.append("INSERT OVERWRITE TABLE " + 
								outFeed.getFeedName() +
								" PARTITION(").
								append(String.join(",", outFeed.getPartitions())).
								append(") SELECT ").
								append(String.join(",", fields )).								
								append(outFeed.getDynamicPartitions().isEmpty() ? "" : ",").
								append(String.join(",", outFeed.getDynamicPartitions() )).								
								append(" FROM " + outputDataFrameTempTable);	
		}
		
		return hiveQuery.toString();
	}
	
	/**
	 * Method doMerge takes an Array of Data Frames. It can have only 2 Data Frames
	 * The first one represents the Source DataFrame while 2nd represents the Overlay DataFrame
	 * @param dfArray DataFrame[]
	 * @return DataFrame
	 * @throws DataMergeException
	 */
	@Override
	public DataFrame doMerge(DataFrame... dfArray) throws DataMergeException {
		Preconditions.checkNotNull(dfArray, "Input Array Object can not be null");
		System.out.println(dfArray.length );
		Preconditions.checkArgument ((dfArray.length == 2), "Column Level Merge can accept only 2 Data Frames");
		Preconditions.checkNotNull(dfArray[0], "Source Data Frame can not be null");
		Preconditions.checkNotNull(dfArray[1], "Overlay Data Frame can not be null");
		return doMerge(dfArray[0], dfArray[1]);
	}
	
	/**
	 * Method doMerge. This method will take 2 DataFrames and will merge based on the MergeRequest Object
	 * 
	 *  
	 * <br> 
	 * @param sourceDataFrame DataFrame
	 * @param overLayDataFrame DataFrame
	
	 * @return DataFrame */
	public DataFrame  doMerge(DataFrame sourceDataFrame, DataFrame overLayDataFrame){		
		Preconditions.checkNotNull(sourceDataFrame, "sourceDataFrame Object can not be null");
		Preconditions.checkNotNull(overLayDataFrame, "overLayDataFrame Object can not be null");
		Preconditions.checkNotNull(getHiveCtx(), "HiveContext Object can not be null");
		
		
		sourceDataFrame.registerTempTable("sourceDataFrame");
		StructType sourceSchema = sourceDataFrame.schema();
		
		overLayDataFrame.registerTempTable("overLayDataFrame");		
		String mergeQuery = createColumnMergeQuery(sourceSchema,"sourceDataFrame", "overLayDataFrame");
		logger.info("#HDPF:Constructed Merge Query:" + mergeQuery);		
		DataFrame mergedDataFrame = getHiveCtx().sql(mergeQuery);
		Long mergedCount = mergedDataFrame.count();
		if (mergeRequest.isRemoveDups()) {
			logger.info("#HDPF: Removing Duplicated");
			DataFrame distinctRecDf = mergedDataFrame.distinct();
			Long distinctCount = distinctRecDf.count();
			logger.info("#HDPF: Total number of records after removing duplicates " + distinctCount);
			getHadoopLogger().info("DataMerge", getMergeRequest().getOutFeed().getFeedName(), 
					String.format("Total of %d duplicate records deleted after merging the tables.", (mergedCount - distinctCount)));
		}
		
		return mergedDataFrame;
	}
	
	/**
	 * Method to construct the Query using which merge will be accomplished
	 * Method createColumnMergeQuery.
	 * @param sourceSchema StructType
	 * @param sourceDFName String
	 * @param overLayDFName String
	
	 * @return String */
	public String createColumnMergeQuery(StructType sourceSchema, String sourceDFName, String overLayDFName){
		Preconditions.checkNotNull(mergeRequest, "MergeRequest Object can not be null");
		Preconditions.checkNotNull(mergeRequest.getJoinColumns(), "Join Columns can not be null");		
		Preconditions.checkNotNull(sourceDFName, "sourceDFName Object can not be null");
		Preconditions.checkNotNull(overLayDFName, "overLayDFName Object can not be null");
		
		StringBuffer mergeQuery = new StringBuffer();
		
		mergeQuery.
				append("SELECT ").
				append(buildSelectClause(sourceSchema, sourceDFName, overLayDFName, mergeRequest.getOverlayFields())).
				append(" FROM ").
				append(sourceDFName).
				append(" LEFT OUTER JOIN ").
				append(overLayDFName).
				append(" ON ").
				append(buildJoinClause(mergeRequest.getJoinColumns(), sourceDFName, overLayDFName));
		
		return mergeQuery.toString();
	}
	
	/** Special method to build the Join clause that need to be used for merge. 
	 * Method buildJoinClause.
	 * @param joinColumns String
	 * @param sourceDFTableName String
	 * @param overLayDFTableName String
	
	 * @return String */
	public String buildJoinClause(String joinColumns, String sourceDFTableName, String overLayDFTableName){
		Preconditions.checkNotNull(joinColumns, ":joinColumns Object can not be null");
		Preconditions.checkArgument(!StringUtils.isBlank(joinColumns.trim()), "Atleast one Join column should be provided");
		Preconditions.checkNotNull(sourceDFTableName, ":sourceDFName can not be null");
		Preconditions.checkNotNull(overLayDFTableName, ":overLayDFName Object can not be null");
		
		StringBuffer joinClause = new StringBuffer(" ( ");
		
		String[] joinColumnArray = joinColumns.split(",");
		for (String joinColumn : joinColumnArray){
			if (! joinClause.toString().equals(" ( ")) 
					joinClause.append( " AND " );
			
			joinClause.append(sourceDFTableName).
						append(".").
						append(joinColumn).
						append(" = ").
						append(overLayDFTableName).
						append(".").append(joinColumn);
		}
		joinClause.append(" ) ");
		logger.info("#HDPF: Join Clause:" + joinClause.toString());
		return joinClause.toString();
	}
	
	/**
	 * This method should build the select clause based on the 
	 * source DataFrame columns considering any overlay columns
	
	 * @param sourceSchema StructType
	 * @param sourceDFTableName String
	 * @param overLayDFTableName String
	 * @param overLayFields String
	
	 * @return String */
	public String buildSelectClause(StructType sourceSchema,
									String sourceDFTableName,
									String overLayDFTableName,
									String overLayFields){
		
		Preconditions.checkNotNull(sourceSchema, "Source Data Type can not be null");
		Preconditions.checkNotNull(sourceDFTableName, "Source Data Frame Name can not be null");
		Preconditions.checkNotNull(overLayDFTableName, "overlay Data Frame Name can not be null");		
		List<String> overLayFieldsList = new ArrayList<String>();
		//get all the existing columns from the Source Data Frame
		StringBuffer selectClause = new StringBuffer(" ");
		if (StringUtils.isNotBlank(overLayFields)){
			overLayFieldsList = Arrays.asList(overLayFields.split(","));	
		}
						
		for(StructField field : sourceSchema.fields()){
			StringBuffer coalesce = new StringBuffer("COALESCE(");
			if (overLayFieldsList.isEmpty()){
				coalesce.
					append(overLayDFTableName).append(".").append(field.name()).append(" , ").
					append(sourceDFTableName).append(".").append(field.name()).append(")");
			}else{
				if (overLayFieldsList.contains(field.name())){
					coalesce.
						append(overLayDFTableName).append(".").append(field.name()).append(" , ").
						append(sourceDFTableName).append(".").append(field.name()).append(")");
				}else{
					coalesce.
						append(sourceDFTableName).append(".").append(field.name()).append(")");
				}
				
			}
			selectClause.append(coalesce.append(" AS ").append(field.name()).append(" , ").toString());
		}
		
		logger.info("#HDPF: Select Clause:" + selectClause.toString());
		return selectClause.toString().substring(0, selectClause.length()-2);
	}
	
	/**
	 * Method buildDataFrameFromFeed. Provided a Feed this method will return a DataFrame by applying filters if there are any
	 * @param inputFeed MergeRequest.InFeed
	
	 * @return DataFrame */
	public DataFrame buildDataFrameFromFeed(MergeRequest.InFeed inputFeed){
		Preconditions.checkNotNull(inputFeed, "Input Feed can not be null");
		
		StringBuffer dataFrameQuery = new StringBuffer();
		dataFrameQuery.append(" SELECT * FROM ").
						append(inputFeed.getFeedName());
		
		if (StringUtils.isNotEmpty(inputFeed.getFilterCond())){
			dataFrameQuery.append(" WHERE ").
							append(inputFeed.getFilterCond());
		}
		
		logger.info("#HDPF: InFeed Load Clause:" + dataFrameQuery.toString());		
		return getHiveCtx().sql(dataFrameQuery.toString());
	}

	/**
	 * Method getMergeRequest.
	
	 * @return MergeRequest */
	public MergeRequest getMergeRequest() {
		return mergeRequest;
	}

	/**
	 * Method setMergeRequest.
	 * @param mergeRequest MergeRequest
	 */
	public void setMergeRequest(MergeRequest mergeRequest) {
		this.mergeRequest = mergeRequest;
	}

	/**
	 * Method doMerge.
	 * @param removeDups boolean
	 * @param mergeType String
	 * @param dfArray DataFrame[]
	 * @return DataFrame
	 * @throws DataMergeException
	 */
	@Override
	public DataFrame doMerge(boolean removeDups, String mergeType,
			DataFrame[] dfArray) throws DataMergeException {
		// TODO Auto-generated method stub
		return null;
	}


	
}
