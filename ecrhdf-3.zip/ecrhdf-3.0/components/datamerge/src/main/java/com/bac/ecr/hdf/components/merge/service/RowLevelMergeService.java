package com.bac.ecr.hdf.components.merge.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.InFeed;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;

/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */
public class RowLevelMergeService extends AbstractMergeService {
	
	final static Logger logger = Logger.getLogger(RowLevelMergeService.class);
	

	public RowLevelMergeService(JavaSparkContext jsc, SQLContext sqlCtx, HiveContext hiveCtx, HadoopLogger hadoopLogger) {
		super(jsc, sqlCtx, hiveCtx, hadoopLogger);
	}


	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.merge.service.AbstractMergeService#processMergeRequest(com.bac.ecr.hdf.components.merge.beans.MergeRequest)
	 */
	@Override
	public void processMergeRequest(MergeRequest mergeArgs) throws DataMergeException {		
		List<InFeed> inFeedList = mergeArgs.getInFeed();
		DataFrame[] inFeedDFArray = new DataFrame[inFeedList.size()];		
		try {
			for (int i = 0; i < inFeedList.size(); i++) {
				inFeedDFArray[i] = SchemaOperationsUtil.createDataFrameFromTable(inFeedList.get(i).getFeedName(), inFeedList.get(i).getFilterCond(), this.getHiveCtx());				
			}			
			DataFrame mergedDf = doMerge(inFeedDFArray);
			mergedDf.explain(true);
			long mergedCount = mergedDf.count();
			logger.info("*********** total number of records after merge " + mergedCount);
			if (mergeArgs.isRemoveDups()) {
				DataFrame distinctRecDf = mergedDf.select("*").distinct();
				distinctRecDf.explain(true);
				long distinctCount = distinctRecDf.count();
				logger.info("*********** total number of records after removing duplicates " + distinctCount);
				getHadoopLogger().info("DataMerge", mergeArgs.getOutFeed().getFeedName(), 
						String.format("Total of %d duplicate records deleted after merging the tables.", (mergedCount - distinctCount)));
				writeToTarget(distinctRecDf,mergeArgs);				
			} else {
				writeToTarget(mergedDf,mergeArgs);				
			}			
		} catch(Exception e) {
			//e.printStackTrace();
			throw new DataMergeException(e);
		}


		
	}

	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.merge.service.AbstractMergeService#doMerge(org.apache.spark.sql.DataFrame[])
	 */
	@SuppressWarnings("unchecked")
	@Override
	public DataFrame doMerge(DataFrame... inFeedDF) throws DataMergeException {
		DataFrame[] inFeedDFArray = inFeedDF;
		StructType inFeedSchema = inFeedDFArray[0].schema();
		JavaRDD[] rowRDD = new JavaRDD[inFeedDFArray.length];
		for (int i = 0; i < inFeedDFArray.length; i++) {
			rowRDD[i] = inFeedDFArray[i].javaRDD();
			rowRDD[i].toDebugString();
		}				
		JavaRDD<Row> mergedRDD = this.getJsc().union(rowRDD);
		mergedRDD.toDebugString();
		logger.info("******* Merging of dataframes completed.");
		return this.getHiveCtx().createDataFrame(mergedRDD, inFeedSchema);		
	}



	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.merge.service.AbstractMergeService#doMerge(boolean, java.lang.String, org.apache.spark.sql.DataFrame[])
	 */
	@Override
	public DataFrame doMerge(boolean removeDups, String mergeType, DataFrame[] dfArray) throws DataMergeException {
		// TODO Auto-generated method stub
		DataFrame mergedDf = doMerge(dfArray);
		mergedDf.explain(true);
		Long mergedCount = mergedDf.count();
		logger.info("*********** total number of records after merge " + mergedCount);
		if (removeDups) {
			DataFrame distinctRecDf = mergedDf.distinct();
			distinctRecDf.explain(true);
			Long distinctCount = distinctRecDf.count();
			logger.info("*********** total number of records after removing duplicates " + distinctCount);
			return 	distinctRecDf;		
		} else {
			return mergedDf;
		}
		
	}
}
