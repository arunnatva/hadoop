package com.bac.ecr.hdf.components.merge.utils;

public class DataMergeConstants {

	 public final static String ROW="row";
	 public final static String COLUMN="column";
	 public final static String MERGE_TYPE="mergeType";
	 public final static String REMOVE_DUPS="removeDups";
	 public final static String IN_FEED="infeed";
	 public final static String OUT_FEED="outfeed";
	 public final static String LOG_SEPERATOR="***********************";
	 public final static String MERGE_ARG_SEPERATOR = "|";
	 public final static String MERGE_JSON="mergeJSON";
	
	public DataMergeConstants() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * STDZErrorCodes Enum lists all the possible exception messages for DataStandardization. Takes parameter and returns 
	 * appropriate error message to be logged in to hadoop logging framework . 
	 * 
	 */
	public enum MergeErrorCodes {
		
		MERGE_100("MERGE-100 : Invalid Command line arguments, please review the arguments"),
		MERGE_101("MERGE-101 : Column count mismatch among source datasets"),
		MERGE_102("MERGE-102 : Column Names mismatch among source datasets"),
		MERGE_103("MERGE-103 : Column data types mismatch among source datasets"),	
		MERGE_104("MERGE-104 : Column count mismatch among source and target datasets"),
		MERGE_105("MERGE-105 : Column Names and Data Type mismatch among source and target datasets"),
		MERGE_106("MERGE-106 : Data Type mismatch among source and target datasets"),
		MERGE_107("MERGE-107 : Column Names and Data Type mismatch among source datasets"),
		MERGE_108("MERGE-108 : Unable to read the Merge Configuration JSON file. Please verify "),
		MERGE_109("MERGE-109 : Merge Configuration JSON is invalid"),
		MERGE_110("MERGE-110 : Value for static partition column should not be empty.");
		
		private final String mergeErrorCode;
		
		private MergeErrorCodes(String mergeErrorCode) {
	        this.mergeErrorCode = mergeErrorCode;
	    }
	    
	    public String value() {
	    	return mergeErrorCode;
	    }
	}
}
