package com.bac.ecr.hdf.components.merge.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.execution.QueryExecutionException;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.beans.SrcTableSchema;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;

public class DataMergeUtil {

	final static Logger logger = Logger.getLogger(DataMergeUtil.class);

	/**
	 * This method compares the given two source table schema objects and throws
	 * DataMergeException object if there is any mismatch in terms of column
	 * names, data types and sequence
	 * 
	 * @param srcTableSchema1
	 * @param srcTableSchema2
	 * @throws DataMergeException
	 */
	public static void compareSrcTableSchemas(SrcTableSchema srcTableSchema1,
			SrcTableSchema srcTableSchema2) throws DataMergeException {
			
		List<String> colNamesDataTypes1 = srcTableSchema1.getColNamesDataTypes();
		List<String> colNamesDataTypes2 = srcTableSchema2.getColNamesDataTypes();
		
		if ((colNamesDataTypes1 != null) && (colNamesDataTypes2 != null)
				&& (colNamesDataTypes1.size() != colNamesDataTypes2.size())) {
			logger.info(DataMergeConstants.LOG_SEPERATOR);
			logger.error("Number of columns does not match for the following two source tables.");
			logger.error(srcTableSchema1.getSrcTableName() + " : " + colNamesDataTypes1.size() );
			logger.error(srcTableSchema2.getSrcTableName() + ": " + colNamesDataTypes2.size() );
			logger.info(DataMergeConstants.LOG_SEPERATOR);
			throw new DataMergeException(
					DataMergeConstants.MergeErrorCodes.MERGE_101.value()+  srcTableSchema1.getSrcTableName() + " and " + srcTableSchema2.getSrcTableName());
		} else{
			List<String> distinctColumn = compareLists(colNamesDataTypes1, colNamesDataTypes2, srcTableSchema1.getSrcTableName(), srcTableSchema2.getSrcTableName());
			if(distinctColumn.size()!= 0){			
				logger.info(DataMergeConstants.LOG_SEPERATOR);
				logger.error("Column Names and datatypes or its ordering does not match between the following two source tables.");
				logger.error(srcTableSchema1.getSrcTableName());
				logger.error(srcTableSchema2.getSrcTableName());
				logger.error(String.join(" , ", distinctColumn));
				logger.info(DataMergeConstants.LOG_SEPERATOR);
				throw new DataMergeException(
						DataMergeConstants.MergeErrorCodes.MERGE_107.value() +" "+ String.join(" , ", distinctColumn));
			}
		}	
		
	}
	
	
	/**This method compares the given source and target table schema objects and throws
	 * DataMergeException object if there is any mismatch in terms of column
	 * names, data types and sequence
	 * 
	 * @param srcTableSchema
	 * @param trgTableSchema
	 * @throws DataMergeException
	 */
	public static void compareSrcTrgTableSchemas(SrcTableSchema srcTableSchema,
			SrcTableSchema trgTableSchema) throws DataMergeException {
		
		List<String> colNamesDataTypes1 = srcTableSchema.getColNamesDataTypes();
		List<String> colNamesDataTypes2 = trgTableSchema.getColNamesDataTypes();
		
		if ((colNamesDataTypes1 != null) && (colNamesDataTypes2 != null)
				&& (colNamesDataTypes1.size() != colNamesDataTypes2.size())) {
			logger.info(DataMergeConstants.LOG_SEPERATOR);
			logger.error("Number of columns does not match for the following source and target tables.");
			logger.error(srcTableSchema.getSrcTableName() + " : " + colNamesDataTypes1.size() );
			logger.error(trgTableSchema.getSrcTableName() + ": " + colNamesDataTypes2.size() );
			logger.info(DataMergeConstants.LOG_SEPERATOR);
			throw new DataMergeException(
					DataMergeConstants.MergeErrorCodes.MERGE_104.value()+  srcTableSchema.getSrcTableName() + " and " + trgTableSchema.getSrcTableName());
		} else{
			//sorted source and target column names for comparison and in target table column names can be in any order
			Collections.sort(colNamesDataTypes1);
			Collections.sort(colNamesDataTypes2);
			List<String> distinctColumn = compareLists(colNamesDataTypes1, colNamesDataTypes2, srcTableSchema.getSrcTableName(), trgTableSchema.getSrcTableName());
			if(distinctColumn.size()!= 0){			
				logger.info(DataMergeConstants.LOG_SEPERATOR);
				logger.error("Column Names and datatypes or its ordering does not match between the following source and target tables.");
				logger.error(srcTableSchema.getSrcTableName());
				logger.error(trgTableSchema.getSrcTableName());
				logger.error(String.join(" , ", distinctColumn));
				logger.info(DataMergeConstants.LOG_SEPERATOR);
				throw new DataMergeException(
						DataMergeConstants.MergeErrorCodes.MERGE_105.value() +" "+ String.join(" , ", distinctColumn));
			}
		}	
	}

	/**
	 * This method compares the source table schemas which are provided as input
	 * to the merge component and throws DataMergeException object if there is
	 * any mismatch in terms of column names, data types and sequence
	 * 
	 * @param mergeRequest
	 * @param hiveCtx
	 * @throws QueryExecutionException
	 * @throws AnalysisException
	 * @throws DataMergeException
	 * 
	 */
	public static boolean compareSchemas(MergeRequest mergeRequest,
			HiveContext hiveCtx) throws QueryExecutionException,
			AnalysisException, DataMergeException {

		List<MergeRequest.InFeed> inputFeeds = mergeRequest.getInFeed();
		List<SrcTableSchema> srcTableSchemas = new ArrayList<SrcTableSchema>(
				inputFeeds.size());

		for (MergeRequest.InFeed feed : inputFeeds) {
			String[] dbTableNames = feed.getFeedName().split("\\.");

			logger.info("Database name : " + dbTableNames[0]);
			logger.info("Table name : " + dbTableNames[1]);

			StructType rawTableSchema = SchemaOperationsUtil.getSchemaFromHive(
					dbTableNames[0], dbTableNames[1], hiveCtx);

			//List<String> colNames = new ArrayList<String>();
			//List<String> colDataTypes = new ArrayList<String>();

			List<String> colNameDataTypes = new ArrayList<String>();
			
			for (StructField field : rawTableSchema.fields()) {
				colNameDataTypes.add(field.name() + " : "+ field.dataType().toString());
				
			}

			SrcTableSchema srcTblSchema = new SrcTableSchema();
			srcTblSchema.setSrcTableName(feed.getFeedName());
			srcTblSchema.setColNamesDataTypes(colNameDataTypes);
			
			//srcTblSchema.setColNames(colNames);
			//srcTblSchema.setColDataTypes(colDataTypes);

			logger.info(DataMergeConstants.LOG_SEPERATOR);
			logger.info(srcTblSchema.toString());
			logger.info(DataMergeConstants.LOG_SEPERATOR);
			srcTableSchemas.add(srcTblSchema);
		}

		if (inputFeeds.size() > 1) {
			for (int counter = 2; counter <= inputFeeds.size(); counter++) {
				DataMergeUtil.compareSrcTableSchemas(
						srcTableSchemas.get(counter - 2),
						srcTableSchemas.get(counter - 1));
			}
		}
	return true;
	}

	
/**
 * Extracts Source and Target table schema and calls compareSrcTrgTableSchemas function for schema comparison
 * @param mergeRequest
 * @param hiveCtx
 * @return boolean (if both schema match methos returns true)
 * @throws QueryExecutionException
 * @throws AnalysisException
 * @throws DataMergeException
 */
public static boolean extractCompareTrgSrcSchemas(MergeRequest mergeRequest,HiveContext hiveCtx) throws QueryExecutionException, AnalysisException, DataMergeException {
	
	// Source schema validation Begins
	List<MergeRequest.InFeed> srcFeed = mergeRequest.getInFeed();
	MergeRequest.OutFeed trgFeed = mergeRequest.getOutFeed();
	List<String> staticPartition = mergeRequest.getOutFeed().getStaticPartitionsColumns();
	
	//extracting first source table from InFeed
	String srcDbTable = srcFeed.get(0).getFeedName();

	//parsing first source table name and db name 
	String[] srcDbTableNames = srcDbTable.split("\\.");
		
		logger.info("Source Database name : " + srcDbTableNames[0]);
		logger.info("Source Table name : " + srcDbTableNames[1]);
		
		//extracting source table schema
		StructType srcTableSchema = SchemaOperationsUtil
				.getSchemaFromHive(srcDbTableNames[0],
						srcDbTableNames[1], hiveCtx);
		
		List<String> colNamesDataTypeSrc = new ArrayList<String>();
		

		for (StructField field : srcTableSchema.fields()) {
			colNamesDataTypeSrc.add(field.name().trim()+":"+field.dataType().toString().trim());
			
		}
		
		//setting source table objects
		SrcTableSchema srcTblSchemaObj = new SrcTableSchema();
		srcTblSchemaObj.setSrcTableName(srcDbTable);
		srcTblSchemaObj.setColNamesDataTypes(colNamesDataTypeSrc);
		

		logger.info(DataMergeConstants.LOG_SEPERATOR);
		logger.info(srcTblSchemaObj.toString());
		logger.info(DataMergeConstants.LOG_SEPERATOR);
		
		//parsing target db and table name
		String[] trgDbTableNames = trgFeed.getFeedName().split("\\.");
				
		logger.info("Target Database name : " + trgDbTableNames[0]);
		logger.info("Target Table name : " + trgDbTableNames[1]);
				
		//extracting target table schema
		StructType trgTableSchema =  SchemaOperationsUtil
						.getSchemaFromHive(trgDbTableNames[0],
								trgDbTableNames[1], hiveCtx);
		
		List<String> colNamesDataTypesTrg = new ArrayList<String>();
	

		for (StructField field : trgTableSchema.fields()) {
			if(staticPartition.size() > 0) {
				if(!staticPartition.contains(field.name())) //for removing static partitions from target column names
					colNamesDataTypesTrg.add(field.name().trim()+":"+field.dataType().toString().trim());}
			else
				colNamesDataTypesTrg.add(field.name().trim()+":"+field.dataType().toString().trim());
			}		
				
		//setting target table object
		SrcTableSchema trgTblSchemaObj = new SrcTableSchema();
		trgTblSchemaObj.setSrcTableName(trgFeed.getFeedName());
		trgTblSchemaObj.setColNamesDataTypes(colNamesDataTypesTrg);
		
		logger.info(DataMergeConstants.LOG_SEPERATOR);
		logger.info(trgTblSchemaObj.toString());
		logger.info(DataMergeConstants.LOG_SEPERATOR);
				
		DataMergeUtil.compareSrcTrgTableSchemas(srcTblSchemaObj,trgTblSchemaObj );
	
// Source Target schema validation Ends
	return true;
}


/**
 * validateMergeCommandLineArgs method checks for mandatory config JSON input arguments.
 * @param inputArgsMap
 * @return boolean
 */
public static boolean validateMergeCommandLineArgs(
		Map<String, String> inputArgsMap) {
	if (inputArgsMap.size() < 1 || null == inputArgsMap.get(DataMergeConstants.MERGE_JSON)) {
		return false;
	}
	return true;
}


	/**To compare two column:datatype lists.If at same index both lists have different column:dataType the column:dataType will be add to new list. 
	 * @param colListOne
	 * @param colListTwo
	 * @param tableOne
	 * @param tableTwo
	 * @return diffColumn (list with different column name and datatype with table name appended)
	 */
	public static List<String> compareLists(List<String> colListOne , List<String> colListTwo , String tableOne , String tableTwo){
		
		List<String> diffColumn = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		
		for(int counter = 0; counter < colListOne.size(); counter++) {
		   
			if(!colListOne.get(counter).equalsIgnoreCase(colListTwo.get(counter))){
				
				sb.append(tableOne).append(".").append(colListOne.get(counter)).append(" VS ").append(tableTwo).append(".").append(colListTwo.get(counter)); 
				diffColumn.add(sb.toString());
				}
		   }
		return diffColumn;
	}


}
