package com.bac.ecr.hdf.components.merge.utils;

import org.apache.commons.lang3.Validate;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.InFeed;

public class ValidateInputJson {

	public static void validateJson(MergeRequest merge) throws Exception {

		Validate.notNull(merge, "MergeRequest object cannot be null");

		String mergeType = merge.getMergeType();
		Validate.notNull(mergeType,
				"\"mergeType\" field element is missing in the input JSON");
		Validate.validState(
				"row".equals(mergeType) || "column".equals(mergeType),
				"Invalid merge type " + mergeType
						+ " , merge type values must be row or column");

		Validate.isTrue(merge.getInFeed().size() > 0,
				"\"inFeed\" field element is missing in the input JSON");
		for (InFeed input : merge.getInFeed()) {
			Validate.notBlank(input.getFeedName(),
					"\"feedName\" field value of \"inFeed\" element cannot be blank");
			Validate.matchesPattern(
					input.getFeedName(),
					"(?i)[a-zA-Z0-9_]+\\.[a-zA-Z0-9_]+",
					input.getFeedName()
							+ " is invalid. \"feedName\" value of \"inFeed\" element should follow the following pattern: <databaseName>.<tableName>");
		}

		Validate.notNull(merge.getOutFeed(),
				"\"outFeed\" field element is missing in the input JSON");
		Validate.notBlank(merge.getOutFeed().getFeedName(),
				"\"feedName\" field value of \"outFeed\" element cannot be blank");
		Validate.matchesPattern(
				merge.getOutFeed().getFeedName(),
				"(?i)[a-zA-Z0-9_]+\\.[a-zA-Z0-9_]+",
				merge.getOutFeed().getFeedName()
						+ " is invalid. \"feedName\" value of \"outFeed\" element should follow the following pattern: <databaseName>.<tableName>");

		if ("column".equals(mergeType)) {
			Validate.notNull(merge.getOverlay(),
					"\"overlay\" field element is missing in the input JSON");
			Validate.notBlank(merge.getOverlay(),
					"\"overlay\" field value cannot be blank");
			Validate.matchesPattern(
					merge.getOverlay(),
					"(?i)[a-zA-Z0-9_]+\\.[a-zA-Z0-9_]+",
					merge.getOverlay()
							+ " is invalid. \"overlay\" value should follow the following pattern: <databaseName>.<tableName>");

			String overlayTableName = merge.getOverlay().trim();
			boolean isOverlayTableNameExists = false;
			for (InFeed inputFeed : merge.getInFeed()) {
				if (!isOverlayTableNameExists) {
					isOverlayTableNameExists = inputFeed.getFeedName().trim()
							.equalsIgnoreCase(overlayTableName) ? true : false;
				}
			}

			Validate.isTrue(
					isOverlayTableNameExists,
					"\"overlay\" field value should match with any one of the \"inFeed\" element's feedName values");

			Validate.isTrue(merge.getInFeed().size() == 2,
					"For a column level merge, user needs to specify only two infeed details");
		}

	}

}
