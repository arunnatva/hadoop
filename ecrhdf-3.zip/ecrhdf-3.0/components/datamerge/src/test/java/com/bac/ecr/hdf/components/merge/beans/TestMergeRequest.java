package com.bac.ecr.hdf.components.merge.beans;


import org.junit.Assert;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;

public class TestMergeRequest {

	@Test
	public void testInfeed(){
		
		String validInFeedNoFilter = "ale_alpide_staging_dev1.accountlevel";
		String validInFeedFilter = "ale_alpide_staging_dev1.accountlevel|asofdate='2016-11-30'";
		String validInFeedFilterWithAnd = "ale_alpide_staging_dev1.accountlevel|asofdate='2016-11-30' and sor = '303'";
		String validOutFeedPartitions = "ale_alpide_staging_dev1.accountlevel|partkey1,partkey2='abcd',partkey3";
										
		/*try{
			MergeRequest.InFeed inFeed = new MergeRequest.InFeed();
			Assert.fail("Expecting an exception");
		}catch(NullPointerException ne){}*/
		
		MergeRequest.InFeed inFeed1 = new MergeRequest.InFeed(validInFeedNoFilter,null);
		Assert.assertEquals(inFeed1.getFeedName(), "ale_alpide_staging_dev1.accountlevel");
		Assert.assertEquals(inFeed1.getFilterCond(), null);

		MergeRequest.InFeed inFeed2 = new MergeRequest.InFeed(validInFeedFilter.split("\\|")[0],validInFeedFilter.split("\\|")[1]);
		Assert.assertEquals(inFeed2.getFeedName(), "ale_alpide_staging_dev1.accountlevel");
		Assert.assertEquals(inFeed2.getFilterCond(), "asofdate='2016-11-30'");

		MergeRequest.InFeed inFeed3 = new MergeRequest.InFeed(validInFeedFilterWithAnd.split("\\|")[0],validInFeedFilterWithAnd.split("\\|")[1]);
		Assert.assertEquals(inFeed3.getFeedName(), "ale_alpide_staging_dev1.accountlevel");
		Assert.assertEquals(inFeed3.getFilterCond(), "asofdate='2016-11-30' and sor = '303'");
				
		MergeRequest.OutFeed outFeed = new MergeRequest.OutFeed(validOutFeedPartitions.split("\\|")[0],null);
		Assert.assertEquals(outFeed.getFeedName(), "ale_alpide_staging_dev1.accountlevel");
		//Assert.assertEquals(inFeed4.getPartitions(), "partkey1,partkey2='abcd',partkey3");
	}
	
}
