package com.bac.ecr.hdf.components.merge.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.InFeed;
import com.bac.ecr.hdf.components.merge.beans.MergeRequest.OutFeed;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.frameworks.logging.DummyHadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;



public class TestColumnLevelMergeService {

	private static SparkConf sparkConfig;
	HadoopLogger hadoopLogger;
	private static transient JavaSparkContext jsc;
	private static ColumnLevelMergeService service;
	private static StructType schemaType;
	private static  HiveContext sqlContext ;
	
	@BeforeClass
	public static void setUp(){
		if (System.getProperty("os.name").contains("Windows")){
			System.setProperty("hadoop.home.dir", "C:\\hadoop\\hadoop-2.6.5.tar\\hadoop-2.6.5\\hadoop-2.6.5");
		}
		
		sparkConfig =  new SparkConf().setMaster("local").setAppName("Column Merge Test");
		System.out.println("creating new sparkcontext...");		
		jsc = new JavaSparkContext(sparkConfig);
		sqlContext = new org.apache.spark.sql.hive.HiveContext(jsc.sc());
		MergeRequest request = new MergeRequest();
		service = new ColumnLevelMergeService(request, sqlContext, jsc, new DummyHadoopLogger());
		
		List<StructField> schema = new ArrayList<StructField>();
		schema.add(DataTypes.createStructField("cccp_key", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("guar_id", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("guartr_seq_no", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("acc_ln_guarante_cd", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("guarantor_gci_typ", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("guarantor_gci", DataTypes.StringType, true));
		schemaType = DataTypes.createStructType(schema);
		
	}
	@AfterClass
	public static void tearDown(){
		jsc.stop();
		jsc = null;
		sqlContext = null;
	}
	/*
	 * Get the Test data ready
	 * Prepare a DataFrame with actual data
	 * prepare a DataFrame with Overlay data
	 * Compare the schema - validate both are the same
	 * For a join query that will overlay the columns
	 * Return the resulting DataFrame
	 */
	
	/** Test cases
	 * 
	 */
	
	@Test
	public void testColumnLevelMergeService(){
		
		//HiveContext sqlContext = new org.apache.spark.sql.hive.HiveContext(jsc.sc());
		
		MergeRequest mergeRequest = new MergeRequest();		
		mergeRequest.setJoinColumns("cccp_key");
		mergeRequest.setOverlayFields("guarantor_gci_typ");
		mergeRequest.setRemoveDups(true);
		
		//Same rows scenario			
		String dataFilePath = "src/test/resources/columnLevelMerge/same-number-of-rows/facility_risk.txt";
		String overLayDataFilePath = "src/test/resources/columnLevelMerge/same-number-of-rows/facility_risk_overlay.txt";		
		DataFrame sourceData = getTestDataAsDataFrame(dataFilePath, schemaType,sqlContext);
		Assert.assertEquals(10, sourceData.count());

		DataFrame overLayData = getTestDataAsDataFrame(overLayDataFilePath, schemaType,sqlContext);
		Assert.assertEquals(10, overLayData.count());
		
		//Either of Data Frames if null should be captured and Exception should be thrown
		try{			
			service.doMerge(null, null);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			
			service.doMerge( null, overLayData);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		
		
		//Prepare the Overlay Data
		DataFrame mergedDataFrame;
		
		try{
			service.setMergeRequest(mergeRequest);
			mergedDataFrame = service.doMerge(sourceData, overLayData);
			mergedDataFrame.show(50);
			Assert.assertEquals(10,mergedDataFrame.count());
			Assert.assertEquals("K",getValueForOneRow(mergedDataFrame, "cccp_key", "9887159","guarantor_gci_typ" ));
			Assert.assertEquals("L",getValueForOneRow(mergedDataFrame, "cccp_key", "9882126","guarantor_gci_typ" ));
			Assert.assertEquals("L",getValueForOneRow(mergedDataFrame, "cccp_key", "9882133","guarantor_gci_typ" ));			
			
		}catch(NullPointerException ie){
			ie.printStackTrace();
			Assert.fail("UnExpected Exception");	
		}
		//Source having more rows - Source should retain same number of rows
		String dataFilePathSourceMoreRows = "src/test/resources/columnLevelMerge/source-more-rows/facility_risk.txt";
		String overLayDataFilePathSourceMoreRows = "src/test/resources/columnLevelMerge/source-more-rows/facility_risk_overlay.txt";		
		DataFrame sourceDataSourceMoreRows = getTestDataAsDataFrame(dataFilePathSourceMoreRows, schemaType,sqlContext);
		Assert.assertEquals(10, sourceDataSourceMoreRows.count());

		DataFrame overLayDataSourceMoreRows = getTestDataAsDataFrame(overLayDataFilePathSourceMoreRows, schemaType,sqlContext);
		Assert.assertEquals(3, overLayDataSourceMoreRows.count());
		try{
			service.setMergeRequest(mergeRequest);
			mergedDataFrame = service.doMerge(sourceDataSourceMoreRows, overLayDataSourceMoreRows);
			mergedDataFrame.show(50);
			Assert.assertEquals(10,mergedDataFrame.count());
			
		}catch(NullPointerException ie){
			ie.printStackTrace();
			Assert.fail("UnExpected Exception");	
		}
		//Overlay Having More rows - Souce should still retain the same number of rows
		String dataFilePathOverlayMoreRows = "src/test/resources/columnLevelMerge/overlay-more-rows/facility_risk.txt";
		String overLayDataFilePathOverlayMoreRows = "src/test/resources/columnLevelMerge/overlay-more-rows/facility_risk_overlay.txt";		
		DataFrame sourceDataOverlayMoreRows = getTestDataAsDataFrame(dataFilePathOverlayMoreRows, schemaType,sqlContext);
		Assert.assertEquals(10, sourceDataOverlayMoreRows.count());

		DataFrame overLayDataOverlayMoreRows = getTestDataAsDataFrame(overLayDataFilePathOverlayMoreRows, schemaType,sqlContext);
		Assert.assertEquals(11, overLayDataOverlayMoreRows.count());
		try{
			service.setMergeRequest(mergeRequest);
			mergedDataFrame = service.doMerge(sourceDataOverlayMoreRows, overLayDataOverlayMoreRows);
			mergedDataFrame.show(50);
			Assert.assertEquals(10,mergedDataFrame.count());
			
		}catch(NullPointerException ie){
			ie.printStackTrace();
			Assert.fail("UnExpected Exception");	
		}
		//Test the Dedup functionality
		
		//Overlay Having More rows - Souce should still retain the same number of rows
		String dataFilePathSourceWithDups = "src/test/resources/columnLevelMerge/source-with-dups/facility_risk.txt";
		String overLayDataFilePathSourceWithDups = "src/test/resources/columnLevelMerge/source-with-dups/facility_risk_overlay.txt";		
		DataFrame sourceDataSourceWithDups = getTestDataAsDataFrame(dataFilePathSourceWithDups, schemaType,sqlContext);
		Assert.assertEquals(11, sourceDataSourceWithDups.count());

		DataFrame overLayDataSourceWithDups = getTestDataAsDataFrame(overLayDataFilePathSourceWithDups, schemaType,sqlContext);
		Assert.assertEquals(3, overLayDataSourceWithDups.count());
		try{
			service.setMergeRequest(mergeRequest);
			mergedDataFrame = service.doMerge(sourceDataSourceWithDups, overLayDataSourceWithDups);			
			Assert.assertEquals(10,mergedDataFrame.count());
			
		}catch(NullPointerException ie){
			ie.printStackTrace();
			Assert.fail("UnExpected Exception");	
		}
		//Adding FIlter conditions
		
		
	}
	
	/**
	 * doMerge
	 * @param df
	 * @param filterColumn
	 * @param filterValue
	 * @param selectSolumn
	 * @return
	 */
	@Test
	public void testDoMerge() throws DataMergeException{
		//MAke sure exceptions are thrown for 
		//Null input
		//1 data frmae
		//3 data frames
		//One of ht edfs being null
		String dataFilePathSourceMoreRows = "src/test/resources/columnLevelMerge/source-more-rows/facility_risk.txt";
		String overLayDataFilePathSourceMoreRows = "src/test/resources/columnLevelMerge/source-more-rows/facility_risk_overlay.txt";		
		DataFrame sourceDataSourceMoreRows = getTestDataAsDataFrame(dataFilePathSourceMoreRows, schemaType,sqlContext);
		Assert.assertEquals(10, sourceDataSourceMoreRows.count());

		DataFrame overLayDataSourceMoreRows = getTestDataAsDataFrame(overLayDataFilePathSourceMoreRows, schemaType,sqlContext);
		try{
			service.doMerge(null);
			Assert.fail("Expected exception");
		}catch(NullPointerException e){}
		
		try{
			service.doMerge(sourceDataSourceMoreRows,sourceDataSourceMoreRows,sourceDataSourceMoreRows);
			Assert.fail("Expected exception");
		}catch(IllegalArgumentException e){}
		try{
			service.doMerge(sourceDataSourceMoreRows);
			Assert.fail("Expected exception");
		}catch(IllegalArgumentException e){}
		
		try{
			service.doMerge(sourceDataSourceMoreRows,null);
			Assert.fail("Expected exception");
		}catch(NullPointerException e){}
		
		try{
			service.doMerge(null,sourceDataSourceMoreRows);
			Assert.fail("Expected exception");
		}catch(NullPointerException e){}
	}
	
	private String getValueForOneRow(DataFrame df,String filterColumn, String filterValue, String selectSolumn){
		List<Row> opRows = df.filter(df.col(filterColumn).equalTo(filterValue))
				.select(df.col(selectSolumn)).collectAsList();
				
		Assert.assertEquals(1, opRows.size());
		return opRows.get(0).getString(0);
				
	}
	
	/**Test for the following scenarios
	/
	 * 1) Expected inputs being null should throw a null pointer exception with proper
	 * 	  messages
	 * 2) 3 scenarios - No Overlay fields mentioned
	 *    			  - Overlay field mentioned with 1 field
	 *    			 - Overlay field mentioned with 2 field
	 *    
	 */
	
	@Test
	public void testBuildSelectClause(){
		
		String sourceDFTableName = "s";
		String overLayDFTableName = "o";
		String overLayFields = "A";
		
		List<StructField> schema = new ArrayList<StructField>();
		schema.add(DataTypes.createStructField("A", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("B", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("C", DataTypes.StringType, true));
		StructType sampleSchemaType = DataTypes.createStructType(schema);
		
		try{
			service.buildSelectClause(null, sourceDFTableName, overLayDFTableName, overLayFields);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.buildSelectClause(schemaType, null, overLayDFTableName, overLayFields);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.buildSelectClause(schemaType, sourceDFTableName, null, overLayFields);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}	
				
		//No Overlay field mentioned:
		System.out.println(" COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(o.C , s.C) AS C ");
		System.out.println(service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,null));
		Assert.assertEquals( " COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(o.C , s.C) AS C ", 
						service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,null) );
		System.out.println(service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,null ));
		
		System.out.println(" COALESCE(o.A , s.A) AS A , COALESCE(s.B) AS B , COALESCE(s.C) AS C ");
		System.out.println(service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,overLayFields));
		
		Assert.assertEquals( " COALESCE(o.A , s.A) AS A , COALESCE(s.B) AS B , COALESCE(s.C) AS C ", 
				service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,overLayFields) );
		
		overLayFields = "A,B";
		
		System.out.println(" COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(s.C) AS C ");
		System.out.println(service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,overLayFields));

		Assert.assertEquals( " COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(s.C) AS C ", 
				service.buildSelectClause(sampleSchemaType, sourceDFTableName, overLayDFTableName,overLayFields) );

		//Normal scenario
		//Assert.assertEquals(" sourceDFTableName.cccp_key , sourceDFTableName.guar_id , sourceDFTableName.guartr_seq_no , sourceDFTableName.acc_ln_guarante_cd , overLayDFTableName.guarantor_gci_typ , sourceDFTableName.guarantor_gci ",
		//				service.buildSelectClause(schemaType, sourceDFTableName, overLayDFTableName,overLayFields ));
		//expected select clause

	}
	
	@Test
	public void testCreateColumnMergeQuery(){
		
		MergeRequest mergeRequest = new MergeRequest();
		mergeRequest.setJoinColumns("C");
		mergeRequest.setOverlayFields("A,B");
		
		List<StructField> schema = new ArrayList<StructField>();
		schema.add(DataTypes.createStructField("A", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("B", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("C", DataTypes.StringType, true));
		StructType sampleSchemaType = DataTypes.createStructType(schema);
		
		try{
			service.createColumnMergeQuery(schemaType, null, null);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.createColumnMergeQuery(schemaType, null, "overLayData");
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.createColumnMergeQuery(schemaType, "sourceData", "overLayData");
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.createColumnMergeQuery(schemaType, "sourceData", null);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		
		//Build the MergeRequest object:
		//Expected output:
		//"SELECT  sourceDFName.cccp_key , sourceDFName.guar_id , sourceDFName.guartr_seq_no , sourceDFName.acc_ln_guarante_cd , overLayDFName.guarantor_gci_typ , sourceDFName.guarantor_gci  FROM sourceDFName LEFT OUTER JOIN overLayDFName ON  ( sourceDFName.cccp_key = overLayDFName.cccp_key ) "
		//Test for multiple overlay fields
		service.setMergeRequest(mergeRequest);
		System.out.println("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ");
		System.out.println(service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		Assert.assertEquals("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ",
							service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		//Test for single overlay field
		mergeRequest = new MergeRequest();
		mergeRequest.setJoinColumns("C");
		mergeRequest.setOverlayFields("A");
		service.setMergeRequest(mergeRequest);
		System.out.println("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(s.B) AS B , COALESCE(s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ");
		System.out.println(service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		Assert.assertEquals("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(s.B) AS B , COALESCE(s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ",
							service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		//Test for default case of no overlay fields
		mergeRequest = new MergeRequest();
		mergeRequest.setJoinColumns("C");		
		service.setMergeRequest(mergeRequest);
		System.out.println("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(o.C , s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ");
		System.out.println(service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		Assert.assertEquals("SELECT  COALESCE(o.A , s.A) AS A , COALESCE(o.B , s.B) AS B , COALESCE(o.C , s.C) AS C  FROM s LEFT OUTER JOIN o ON  ( s.C = o.C ) ",
							service.createColumnMergeQuery(sampleSchemaType, "s", "o"));
		
		
	}
	
	//TBD
	@Test
	public void testbuildWhereClause(){
		String dataFrameTableName = "sourceDFName";
		
	}
	
	@Test
	public void testbuildJoinClause(){
		String sourceDFName = "sourceDFName";
		String overLayDFName = "overLayDFName";
		try{
			service.buildJoinClause("cccp_key", null, null);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.buildJoinClause("cccp_key", null, "overLayData");
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		try{
			service.buildJoinClause("cccp_key", "sourceData", "overLayData");			
		}catch(NullPointerException ie){Assert.fail("Expected Exception");}
		try{
			service.buildJoinClause(null, "sourceData", null);
			Assert.fail("Expected Exception");
		}catch(NullPointerException ie){}
		
		//Blank Join Key
		try{
			service.buildJoinClause("", sourceDFName, overLayDFName);
			Assert.fail();
		}catch(IllegalArgumentException exception){}
		//Single Join Key
		Assert.assertEquals(service.buildJoinClause("cccp_key", sourceDFName, overLayDFName)," ( sourceDFName.cccp_key = overLayDFName.cccp_key ) ");
		//Multiple join keys
		System.out.println(service.buildJoinClause("cccp_key,acc_apsys_id", sourceDFName, overLayDFName));
		Assert.assertEquals(service.buildJoinClause("cccp_key,acc_apsys_id", sourceDFName, overLayDFName),
				" ( sourceDFName.cccp_key = overLayDFName.cccp_key AND sourceDFName.acc_apsys_id = overLayDFName.acc_apsys_id ) ");
	}
	
	//This method should accept a String
	//It assumes the string is prevalidated to have the proper syntax
	//
	//Parse the string to make sure
	//Test for 
	@Test
	public void testbuildDataFrameFromFeed(){
		
		try{
			service.buildDataFrameFromFeed(null);
			Assert.fail("Expecting exception");
		}catch(NullPointerException e){}
		//Create the data set.. Build a table and provide that as a reference.
		
		sqlContext.sql("CREATE DATABASE  IF NOT EXISTS TEST_DB");
		sqlContext.sql("DROP TABLE  IF EXISTS TEST_DB.gaur ");
		sqlContext.sql("CREATE TABLE IF NOT EXISTS TEST_DB.gaur (cccp_key STRING,guar_id STRING,guartr_seq_no STRING,acc_ln_guarante_cd STRING,guarantor_gci_typ STRING,guarantor_gci STRING )");
		String dataFilePath = "src/test/resources/columnLevelMerge/same-number-of-rows/facility_risk.txt";
		DataFrame sourceData = getTestDataAsDataFrame(dataFilePath, schemaType,sqlContext);
		Assert.assertEquals(10, sourceData.count());
		sourceData.registerTempTable("sourceData");
		sqlContext.sql("INSERT INTO TEST_DB.gaur SELECT * FROM sourceData");

		InFeed feedWithOutFilter = new InFeed("TEST_DB.gaur", null);
		Assert.assertEquals(null,feedWithOutFilter.getFilterCond());
		Assert.assertEquals(feedWithOutFilter.getFeedName(), "TEST_DB.gaur");			
		DataFrame frameWithOutFilter = service.buildDataFrameFromFeed(feedWithOutFilter);
		Assert.assertEquals("Expected 5 records for With 1 filters case",10, frameWithOutFilter.count());

		
		InFeed feedWithFilter = new InFeed("TEST_DB.gaur", "guartr_seq_no='1'");
		Assert.assertEquals(feedWithFilter.getFilterCond(), "guartr_seq_no='1'");
		Assert.assertEquals(feedWithFilter.getFeedName(), "TEST_DB.gaur");			
		DataFrame frameWithFilter = service.buildDataFrameFromFeed(feedWithFilter);
		Assert.assertEquals("Expected 5 records for With 1 filters case", 5, frameWithFilter.count());
		
		InFeed feedWithTwoFilters = new InFeed("TEST_DB.gaur","guartr_seq_no='1' AND guarantor_gci_typ = 'L'");
		Assert.assertEquals(feedWithTwoFilters.getFilterCond(), "guartr_seq_no='1' AND guarantor_gci_typ = 'L'");
		Assert.assertEquals(feedWithTwoFilters.getFeedName(), "TEST_DB.gaur");			
		DataFrame frameWithTwoFilters = service.buildDataFrameFromFeed(feedWithTwoFilters);
		Assert.assertEquals("Expected 3 records for With 2 filters case", 3, frameWithTwoFilters.count());
		
	}
	
	private DataFrame getTestDataAsDataFrame(String fileLocation, StructType schema,HiveContext sqlContext){
		
		JavaRDD<Row> guarRDDAs = jsc.textFile(fileLocation,1).map (guarRow -> {													
			String[] values = guarRow.split("\\|");
			return RowFactory.create(values[0],values[1],values[2],values[3],values[4],values[5]);													
			});
		return sqlContext.createDataFrame(guarRDDAs, schema);	
	}
	
	
	//buildMergedDataPersistenceQuery
	/** Test for the below scenarios:
	 *  //When there is not partitions
	 *  //When there is just one static partitions
	 *  //When there is just one dynamic partition
	 *  //When there is a static followed by dynamic partitions
	 */
	@Test
	public void testBuildMergedDataPersistenceQuery(){
		String outputDataFrameTempTable = "outputDataFrameTempTable";		
		MergeRequest mergeRequest = new MergeRequest();
		
		OutFeed noPartition = new OutFeed("o",new ArrayList<String>());
		
		OutFeed onlyDynamicPartition = new OutFeed("o",Arrays.asList("A"));
		OutFeed multipleDynamicPartition = new OutFeed("o",Arrays.asList("B","A"));
		OutFeed onlyStaticPartition = new OutFeed("o",Arrays.asList("asofdate='2016-10-30'"));
		OutFeed multipleStaticPartitions = new OutFeed("o",Arrays.asList("asofdate='2016-10-30'","sor='555'"));
		OutFeed staticAndDynamicPartition = new OutFeed("o",Arrays.asList("asofdate='2016-10-30'","A"));
		
		List<StructField> schema = new ArrayList<StructField>();
		schema.add(DataTypes.createStructField("A", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("B", DataTypes.StringType, true));
		schema.add(DataTypes.createStructField("C", DataTypes.StringType, true));
		StructType sampleSchemaType = DataTypes.createStructType(schema);
		
		mergeRequest.setOutFeed(noPartition);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		Assert.assertEquals("INSERT OVERWRITE TABLE o SELECT * FROM outputDataFrameTempTable",
				service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		
		mergeRequest.setOutFeed(onlyDynamicPartition);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		Assert.assertEquals("INSERT OVERWRITE TABLE o PARTITION(A) SELECT B,C,A FROM outputDataFrameTempTable",
				service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));

		
		mergeRequest.setOutFeed(multipleDynamicPartition);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		Assert.assertEquals("INSERT OVERWRITE TABLE o PARTITION(B,A) SELECT C,B,A FROM outputDataFrameTempTable",
				service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));

		
		mergeRequest.setOutFeed(onlyStaticPartition);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		System.out.println("INSERT OVERWRITE TABLE o PARTITION(asofdate='2016-10-30') SELECT A,B,C FROM outputDataFrameTempTable");
		Assert.assertEquals("INSERT OVERWRITE TABLE o PARTITION(asofdate='2016-10-30') SELECT A,B,C FROM outputDataFrameTempTable",
				service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));

		
		mergeRequest.setOutFeed(multipleStaticPartitions);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		System.out.println ("INSERT OVERWRITE TABLE o PARTITION(asofdate='2016-10-30',sor='555') SELECT A,B,C FROM outputDataFrameTempTable");
		Assert.assertEquals("INSERT OVERWRITE TABLE o PARTITION(asofdate='2016-10-30',sor='555') SELECT A,B,C FROM outputDataFrameTempTable",
							service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));

		
		mergeRequest.setOutFeed(staticAndDynamicPartition);
		service.setMergeRequest(mergeRequest);		
		System.out.println(service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));
		Assert.assertEquals("INSERT OVERWRITE TABLE o PARTITION(asofdate='2016-10-30',A) SELECT B,C,A FROM outputDataFrameTempTable",
				service.buildMergedDataPersistenceQuery(sampleSchemaType, outputDataFrameTempTable));

		
	}
	
	
}
