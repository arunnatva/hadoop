package com.bac.ecr.hdf.components.merge.tests;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import com.bac.ecr.hdf.components.merge.beans.SrcTableSchema;
import com.bac.ecr.hdf.components.merge.utils.DataMergeUtil;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;

public class CompareSourceTargetSchemasTest {

	SrcTableSchema srcTblSchema1;
	SrcTableSchema trgTblSchema1;
	SrcTableSchema srcTblSchema2;
	SrcTableSchema srcTblSchema3;
	SrcTableSchema trgTblSchema2;

	@Before
	public void prepareTestData() {
		srcTblSchema1 = new SrcTableSchema();
		srcTblSchema1.setSrcTableName("ale_retail_other_raw_dev1.src_test_table1");
		srcTblSchema1.setColNamesDataTypes(Arrays.asList("col1:IntegerType", "col2:IntegerType", "col3:IntegerType", "col4:StringType",
				"col5:StringType"));

		trgTblSchema1 = new SrcTableSchema();
		trgTblSchema1.setSrcTableName("ale_retail_other_raw_dev1.trg_test_table1");
		trgTblSchema1
				.setColNamesDataTypes(Arrays.asList("col1:IntegerType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		srcTblSchema2 = new SrcTableSchema();
		srcTblSchema2.setSrcTableName("ale_retail_other_raw_dev1.src_test_table2");
		srcTblSchema2
				.setColNamesDataTypes(Arrays.asList("col2:IntegerType", "col1:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		srcTblSchema3 = new SrcTableSchema();
		srcTblSchema3.setSrcTableName("ale_retail_other_raw_dev1.src_test_table3");
		srcTblSchema3
				.setColNamesDataTypes(Arrays.asList("col1:StringType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		trgTblSchema2 = new SrcTableSchema();
		trgTblSchema2.setSrcTableName("ale_retail_other_raw_dev1.trg_test_table2");
		trgTblSchema2
				.setColNamesDataTypes(Arrays.asList("col1:StringType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));
	}

	/*
	 * Test method for the input scenario
	 * "Number of columns does not match for the given source and target table schemas."
	 */
	@Test(expected = DataMergeException.class)
	public void noOfColsMismatchTest() throws DataMergeException {
		DataMergeUtil.compareSrcTrgTableSchemas(srcTblSchema1,
				trgTblSchema1);
	}

	
	/*
	 * Test method for the input scenario
	 * "Column datatypes or its ordering does not match for the given source and target table schemas."
	 */
	@Test(expected = DataMergeException.class)
	public void colNameAndDatatypesMismatchTest() throws DataMergeException {
		DataMergeUtil.compareSrcTrgTableSchemas(trgTblSchema1,
				srcTblSchema3);
	}

	/*
	 * Test method for the input scenario
	 * "Given source and target table schemas have same column names, data types and sequence"
	 */
	@Test
	public void srcTableSchemasMatchTest() {
		try {
			DataMergeUtil.compareSrcTrgTableSchemas(srcTblSchema3,
					trgTblSchema2);
		} catch (DataMergeException e) {
			Assert.fail("Exception should not be thrown.");

		}
	}
	


}
