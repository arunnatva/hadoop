package com.bac.ecr.hdf.components.merge.tests;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.SrcTableSchema;
import com.bac.ecr.hdf.components.merge.utils.DataMergeUtil;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;

public class CompareTableSchemasTest {

	SrcTableSchema srcTblSchema1;
	SrcTableSchema srcTblSchema2;
	SrcTableSchema srcTblSchema3;
	SrcTableSchema srcTblSchema4;
	SrcTableSchema srcTblSchema5;

	@Before
	public void prepareTestData() {
		srcTblSchema1 = new SrcTableSchema();
		srcTblSchema1.setSrcTableName("ale_retail_other_raw_dev1.test_table1");
		
		srcTblSchema1.setColNamesDataTypes(Arrays.asList("col1:IntegerType", "col2:IntegerType", "col3:IntegerType", "col4:StringType",
				"col5:StringType"));
		
		
		
		/*
		srcTblSchema1.setColNames(Arrays.asList("col1", "col2", "col3", "col4",
				"col5"));
		srcTblSchema1.setColDataTypes(Arrays.asList("IntegerType",
				"IntegerType", "IntegerType", "StringType", "StringType"));
		*/
		
		srcTblSchema2 = new SrcTableSchema();
		srcTblSchema2.setSrcTableName("ale_retail_other_raw_dev1.test_table2");
		srcTblSchema2.setColNamesDataTypes(Arrays.asList("col1:IntegerType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		
		/*
		srcTblSchema2
				.setColNames(Arrays.asList("col1", "col2", "col3", "col4"));
		srcTblSchema2.setColDataTypes(Arrays.asList("IntegerType",
				"IntegerType", "IntegerType", "StringType"));*/
		

		srcTblSchema3 = new SrcTableSchema();
		srcTblSchema3.setSrcTableName("ale_retail_other_raw_dev1.test_table3");
		srcTblSchema3
		.setColNamesDataTypes(Arrays.asList("col2:IntegerType", "col1:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		
		/*
		srcTblSchema3
				.setColNames(Arrays.asList("col2", "col1", "col3", "col4"));
		srcTblSchema3.setColDataTypes(Arrays.asList("IntegerType",
				"IntegerType", "IntegerType", "StringType"));
		*/
		
		srcTblSchema4 = new SrcTableSchema();
		srcTblSchema4.setSrcTableName("ale_retail_other_raw_dev1.test_table4");
		srcTblSchema4
				.setColNames(Arrays.asList("col1:StringType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));
		
		
		/*srcTblSchema4
				.setColNames(Arrays.asList("col1", "col2", "col3", "col4"));
		srcTblSchema4.setColDataTypes(Arrays.asList("StringType",
				"IntegerType", "IntegerType", "StringType"));
		 * */

		srcTblSchema5 = new SrcTableSchema();
		srcTblSchema5.setSrcTableName("ale_retail_other_raw_dev1.test_table5");
		
		srcTblSchema5.setColNames(Arrays.asList("col1:StringType", "col2:IntegerType", "col3:IntegerType", "col4:StringType"));

		/*
		srcTblSchema5
				.setColNames(Arrays.asList("col1", "col2", "col3", "col4"));
		srcTblSchema5.setColDataTypes(Arrays.asList("StringType",
				"IntegerType", "IntegerType", "StringType"));*/
	}

	/*
	 * Test method for the input scenario
	 * "Number of columns does not match for the given two source table schemas."
	 */
	@Test(expected = DataMergeException.class)
	public void noOfColsMismatchTest() throws DataMergeException {
		DataMergeUtil.compareSrcTableSchemas(srcTblSchema1,
				srcTblSchema2);
	}

	/*
	 * Test method for the input scenario
	 * "Column names or its ordering does not match for the given two source table schemas."
	 */
	@Test(expected = DataMergeException.class)
	public void colNamesMismatchTest() throws DataMergeException {
		DataMergeUtil.compareSrcTableSchemas(srcTblSchema2,
				srcTblSchema3);
	}

	/*
	 * Test method for the input scenario
	 * "Column datatypes or its ordering does not match for the given two source table schemas."
	 */
	@Test(expected = DataMergeException.class)
	public void colDatatypesMismatchTest() throws DataMergeException {
		DataMergeUtil.compareSrcTableSchemas(srcTblSchema2,
				srcTblSchema4);
	}

	/*
	 * Test method for the input scenario
	 * "Given two source table schemas have same column names, data types and sequence"
	 */
	@Test
	public void srcTableSchemasMatchTest() {
		try {
			DataMergeUtil.compareSrcTableSchemas(srcTblSchema4,
					srcTblSchema5);
		} catch (DataMergeException e) {
			Assert.fail("Exception should not be thrown.");

		}
	}
}
