package com.bac.ecr.hdf.components.merge.tests;

import org.junit.Assert;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.driver.DataMerge;
import com.bac.ecr.hdf.components.merge.utils.DataMergeException;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;

public class PopulateMergeRequestFromJsonTest {

	@Test
	public void testCommandLineArgsParsing() throws Exception {
		
		String mergeJson = new String("{\"mergeType\" : \"row\",\"removeDups\" : true,\"inFeed\" : [ {\"feedName\" : \"srcdb1.tbl1\",\"filterCond\" : \"asofdate='2016-10-31' and sor in ('555','ACBS')\"},{\"feedName\" : \"srcdb2.tbl2\",\"filterCond\" : \"period_date='2016-10-31' and balance < 10000\"}],\"outFeed\" : {\"feedName\" : \"srcdb3.tbl3\",\"partitions\" : [\"partkey1\",\"partkey2='2016-10-31'\",\"partkey3\"]},\"joinColumns\" : \"col1,col2,col3\",\"overlay\" : \"srcdb1.tbl1\",\"overlayFields\" : \"col1,col2\"}");
 		
		MergeRequest mr = new MergeRequest();
		mr = (MergeRequest) JsonParseUtil.parseJSON(mergeJson, mr); 
		Assert.assertEquals("srcdb3.tbl3",mr.getOutFeed().getFeedName());
		Assert.assertEquals("asofdate='2016-10-31' and sor in ('555','ACBS')", mr.getInFeed().get(0).getFilterCond());
		Assert.assertEquals("col1,col2,col3",mr.getJoinColumns());
		Assert.assertEquals("srcdb1.tbl1", mr.getOverlay());
		Assert.assertEquals("col1,col2", mr.getOverlayFields());
	}
	
	
}
