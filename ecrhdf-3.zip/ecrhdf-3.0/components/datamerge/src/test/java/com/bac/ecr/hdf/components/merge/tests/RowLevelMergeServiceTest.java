package com.bac.ecr.hdf.components.merge.tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.Path;
import org.junit.Test;
import org.testng.Assert;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.merge.service.RowLevelMergeService;
import com.bac.ecr.hdf.components.merge.utils.DataMergeUtil;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;

public class RowLevelMergeServiceTest extends BaseTest {

	private static final String SOURCE_FILE="src/test/resources/inputSampleJsons/rowLevelMergeTest.json";
	
	 @Test
	public void mergeJsonParsingTest() {
		Path path = new Path(SOURCE_FILE);
		System.out.println(path.toString());
		try {
			MergeRequest mergeRequest = new MergeRequest();
			String mergeJson = getJsonConfig(path.toString());
			mergeRequest = (MergeRequest)JsonParseUtil.parseJSON(mergeJson, mergeRequest);
			List<String> lst = mergeRequest.getOutFeed().getPartitions();
			//lst.forEach(arg -> System.out.println(arg));
			RowLevelMergeService rlmgs = new RowLevelMergeService(getJsc(), getSqlContext(), getHiveCtx(),null);
			Map<String,String> partitionsMap = rlmgs.getPartitionColValuesAsMap(lst);
			Set<String> keySet = partitionsMap.keySet();
			String[] clumns = keySet.toArray(new String[keySet.size()]);
			//System.out.println(clumns.length);
			keySet.forEach(arg -> System.out.println(arg));
			//Arrays.stream(clumns).forEach(arg -> System.out.println(arg));
			//Arrays.stream(clumns).forEach(arg -> System.out.println(partitionsMap.get(arg)));
			//System.out.println("*************");
			String[] columns = rlmgs.getPartitionColsArry(lst);
			//Arrays.stream(columns).forEach(arg -> System.out.println(arg));
			Assert.assertEquals(false, StringUtils.isNotBlank(partitionsMap.get("ac_appsys_id")));

			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
		/**
		 * getJsonConfig reads the file from path and returns as String.
		 * @param filePath
		 * @return String
		 * @throws IOException
		 */
		public static String getJsonConfig(String filePath) throws IOException {
			String jsonConfig = null;
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(new File(filePath)));
				StringBuilder sb = new StringBuilder();
				String line = br.readLine();
				while (line != null) {
					sb.append(line);
					sb.append("\n");
					line = br.readLine();
				}
				jsonConfig = sb.toString();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				br.close();
			}

			return jsonConfig;
		}

}
