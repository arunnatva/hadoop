package com.bac.ecr.hdf.components.merge.tests;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;



public class SubstituteDynamicValuesTest {

	@Test
	public void testDynamicValueSubstitution() throws Exception {

		String mergeJson = new String("{\"mergeType\" : \"row\",\"removeDups\" : true,\"inFeed\" : [ {\"feedName\" : \"srcdb1.tbl1\",\"filterCond\" : \"asofdate=${asofdate} and sor in ('555','ACBS')\"},{\"feedName\" : \"srcdb2.tbl2\",\"filterCond\" : \"period_date=${period_date} and balance < 10000\"}],\"outFeed\" : {\"feedName\" : \"srcdb3.tbl3\",\"partitions\" : [\"partkey1\",\"partkey2=${partkey2}\",\"partkey3\"]},\"joinColumns\" : \"col1,col2,col3\",\"overlay\" : \"srcdb1.tbl1\",\"overlayFields\" : \"col1,col2\"}");

	    Map<String, String> map = new HashMap<String, String>();
	    map.put("asofdate", "'2016-10-31'");
	    map.put("period_date", "'2016-11-30'");
	    map.put("partkey2","'abcd'");
	    	    
	    String mergeJson1 = CommonUtils.substituteDynamicValues(mergeJson,map);
	    /*
	    Properties props = new Properties();
	    for (Map.Entry<String, String> entry : map.entrySet()) {
	        props.put(entry.getKey(), entry.getValue());
	    }
	    String mergeJson1 = CommonUtils.substituteVariablesWithValues(mergeJson, props);
	    */
	    
	    System.out.println(mergeJson1);
	    MergeRequest mr = new MergeRequest();
		mr = (MergeRequest) JsonParseUtil.parseJSON(mergeJson1, mr); 
	    Assert.assertEquals("asofdate='2016-10-31' and sor in ('555','ACBS')", mr.getInFeed().get(0).getFilterCond());
	    Assert.assertEquals("period_date='2016-11-30' and balance < 10000", mr.getInFeed().get(1).getFilterCond());
	    Assert.assertEquals("partkey2='abcd'", mr.getOutFeed().getPartitions().get(1));
	}
}
