package com.bac.ecr.hdf.components.merge.utils;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;

import com.bac.ecr.hdf.components.merge.beans.MergeRequest;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;

public class TestValidateInputJson {

	/**
	 * Test cases for:
	 *  Merge Request being blank
	 *  If mergeType is null in the Merge Request
	 *  If Merge Request contains invalid mergeType
	 *  If inFeed is null in the Merge Request
	 *  If any of the Input Feed Name is blank or null
	 *  If any of the Input Feed Name is invalid 
	 *  If outFeed is null in the Merge Request
	 *  If Output Feed Name is null or blank
	 *  If Output Feed Name is invalid
	 *  If mergeType is column and overlay is blank or null
	 *  If mergeType is column and overlay value is invalid 
	 *  If mergeType is column and overlay value not matching with any of the Input Feed Names
	 *  If mergeType is column and user specified more than two infeed details 
	 */
	@Test
	public void testValidateInputJson() {

		// Merge Request being blank
		try {
			ValidateInputJson.validateJson(null);
			Assert.fail("Expected Exception");
		} catch (Exception e) {

		}

		// If mergeType is null in the Merge Request
		try {
			String mergeTypeValFailJson1 = FileUtils
					.readFileToString(new File(
							"src/test/resources/inputSampleJsons/mergeTypeValFailJson1"));
			MergeRequest mergeTypeValFailRequest1 = (MergeRequest) JsonParseUtil
					.parseJSON(mergeTypeValFailJson1, new MergeRequest());
			ValidateInputJson.validateJson(mergeTypeValFailRequest1);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If Merge Request contains invalid mergeType
		try {
			String mergeTypeValFailJson2 = FileUtils
					.readFileToString(new File(
							"src/test/resources/inputSampleJsons/mergeTypeValFailJson2"));
			MergeRequest mergeTypeValFailRequest2 = (MergeRequest) JsonParseUtil
					.parseJSON(mergeTypeValFailJson2, new MergeRequest());
			ValidateInputJson.validateJson(mergeTypeValFailRequest2);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If inFeed is null in the Merge Request
		try {
			String inFeedValFailJson1 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/inFeedValFailJson1"));
			MergeRequest inFeedValFailRequest1 = (MergeRequest) JsonParseUtil
					.parseJSON(inFeedValFailJson1, new MergeRequest());
			ValidateInputJson.validateJson(inFeedValFailRequest1);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If any of the Input Feed Name is blank or null
		try {
			String inFeedValFailJson2 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/inFeedValFailJson2"));
			MergeRequest inFeedValFailRequest2 = (MergeRequest) JsonParseUtil
					.parseJSON(inFeedValFailJson2, new MergeRequest());
			ValidateInputJson.validateJson(inFeedValFailRequest2);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If any of the Input Feed Name is invalid
		try {
			String inFeedValFailJson3 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/inFeedValFailJson3"));
			MergeRequest inFeedValFailRequest3 = (MergeRequest) JsonParseUtil
					.parseJSON(inFeedValFailJson3, new MergeRequest());
			ValidateInputJson.validateJson(inFeedValFailRequest3);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If outFeed is null in the Merge Request
		try {
			String outFeedValFailJson1 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/outFeedValFailJson1"));
			MergeRequest outFeedValFailRequest1 = (MergeRequest) JsonParseUtil
					.parseJSON(outFeedValFailJson1, new MergeRequest());
			ValidateInputJson.validateJson(outFeedValFailRequest1);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If Output Feed Name is null or blank
		try {
			String outFeedValFailJson2 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/outFeedValFailJson2"));
			MergeRequest outFeedValFailRequest2 = (MergeRequest) JsonParseUtil
					.parseJSON(outFeedValFailJson2, new MergeRequest());
			ValidateInputJson.validateJson(outFeedValFailRequest2);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If Output Feed Name is invalid
		try {
			String outFeedValFailJson3 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/outFeedValFailJson3"));
			MergeRequest outFeedValFailRequest3 = (MergeRequest) JsonParseUtil
					.parseJSON(outFeedValFailJson3, new MergeRequest());
			ValidateInputJson.validateJson(outFeedValFailRequest3);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If mergeType is column and overlay is blank or null
		try {
			String overlayValFailJson1 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/overlayValFailJson1"));
			MergeRequest overlayValFailRequest1 = (MergeRequest) JsonParseUtil
					.parseJSON(overlayValFailJson1, new MergeRequest());
			ValidateInputJson.validateJson(overlayValFailRequest1);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If mergeType is column and overlay value is invalid
		try {
			String overlayValFailJson2 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/overlayValFailJson2"));
			MergeRequest overlayValFailRequest2 = (MergeRequest) JsonParseUtil
					.parseJSON(overlayValFailJson2, new MergeRequest());
			ValidateInputJson.validateJson(overlayValFailRequest2);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If mergeType is column and overlay value not matching with any of the
		// Input Feed Names
		try {
			String overlayValFailJson3 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/overlayValFailJson3"));
			MergeRequest overlayValFailRequest3 = (MergeRequest) JsonParseUtil
					.parseJSON(overlayValFailJson3, new MergeRequest());
			ValidateInputJson.validateJson(overlayValFailRequest3);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// If mergeType is column and user specified more than two infeed
		// details
		try {
			String inFeedValFailJson4 = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/inFeedValFailJson4"));
			MergeRequest inFeedValFailRequest4 = (MergeRequest) JsonParseUtil
					.parseJSON(inFeedValFailJson4, new MergeRequest());
			ValidateInputJson.validateJson(inFeedValFailRequest4);
			Assert.fail("Expected Exception");
		} catch (Exception e) {
			// e.printStackTrace();
		}

		// Success case
		try {
			String mergeJson = FileUtils.readFileToString(new File(
					"src/test/resources/inputSampleJsons/mergeJson"));
			MergeRequest mergeRequest = (MergeRequest) JsonParseUtil.parseJSON(
					mergeJson, new MergeRequest());
			ValidateInputJson.validateJson(mergeRequest);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("UnExpected Exception");
		}

	}

}
