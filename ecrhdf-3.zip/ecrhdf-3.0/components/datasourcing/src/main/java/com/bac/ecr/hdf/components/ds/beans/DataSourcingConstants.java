package com.bac.ecr.hdf.components.ds.beans;

/**
 * 
 * @author ZKZB9LR
 *
 */
public class DataSourcingConstants {

/**
 * This ENUM enumerates the different db driver classes. We can get rid of it if we find a better way to populate db driver
 * classes.
 * @author ZKZB9LR
 *
 */
public enum DatabaseDriver {
		
		ORACLE("oracle.jdbc.OracleDriver"), NETEZZA("org.netezza.Driver"),TERADATA("com.teradata.jdbc.TeraDriver"),
		DB2("com.ibm.db2.jcc.DB2Driver"),MSSQL("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		private final String dbDriver;

	    private DatabaseDriver(String dbDriver) {
	        this.dbDriver = dbDriver;
	    }
	    
	    public String value() {
	    	return dbDriver;
	    }
	    
	}
	
 public enum Layer {
	
	SOURCING("Sourcing"), RAWLAYER("RAWLayer"),ARCHIVE("Archive");
	
	private final String layer;

    private Layer(String layer) {
        this.layer = layer;
    }
    
    public String value() {
    	return layer;
    }
    
}

	
	public enum DSErrorCodes {
		
		DSRC_100("DSRC-100 : Config JSON file not found, Please review Config JSON Path"),
		DSRC_101("DSRC-101 : Mapping JSON file not found, Please review the Mapping JSON Path"),
		DSRC_102("DSRC-102 : Missing Input JSON files, Please check the arguments"),
		DSRC_103("DSRC-103 : Missing mandatory arguments, Please review the arguments list"),
		DSRC_104("DSRC-104 : DI Process Failed. Look for DI Error Messages for details"),
		DSRC_105("DSRC-105 : Error in Archiving source data. Please check Config JSON for Archive File Path"),
		DSRC_106("DSRC-106 : Configuration JSON file parsing failed. Please review Config file"),
		DSRC_107("DSRC-107 : Mapping JSON file parsing failed. Please review Mapping file"),
		DSRC_108("DSRC-108 : Config json is missing some mandatory fields. Please review config file"),
		DSRC_109("DSRC-109 : JSON Mapping does not match with Hive Schema. Please review JSON Mapping & Hive Schema"),
		DSRC_110("DSRC-110 : Data Mapping Object is NULL, cannot generate the Schema objects"),
		DSRC_111("DSRC-111 : Unable to fetch partitioned column names, please review the DDL & Mapping JSON"),
		DSRC_112("DSRC-112 : Unable to perform insert overwrite on Hive table, please review the hive schema and mapping"),
		DSRC_113("DSRC-113 : Unable to identify whether columns are in Source File"),
		DSRC_114("DSRC-114 : Unable to identify whether columns are in Partitioned or not");
		
		private final String dsrcErrorCode;
		
		private DSErrorCodes(String dsrcErrorCode) {
	        this.dsrcErrorCode = dsrcErrorCode;
	    }
	    
	    public String value() {
	    	return dsrcErrorCode;
	    }
	}

}
