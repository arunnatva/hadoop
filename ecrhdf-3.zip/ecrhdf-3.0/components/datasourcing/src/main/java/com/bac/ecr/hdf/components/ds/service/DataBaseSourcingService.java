package com.bac.ecr.hdf.components.ds.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.log4j.Logger;
import org.apache.spark.Accumulator;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.datanucleus.util.StringUtils;

import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckService;
import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckServiceFactory;
import com.bac.ecr.hdf.components.ds.beans.DataSourcingConstants.DSErrorCodes;
import com.bac.ecr.hdf.components.ds.beans.DataSourcingConstants.Layer;
import com.bac.ecr.hdf.components.ds.utils.DataSourcingException;
import com.bac.ecr.hdf.components.ds.utils.DataSourcingUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.HdfsUtils;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;



/**
 * DataBaseSourcingService class is used to import the data from the given database.
 * This class contains methods to get the data from the database ,then process the text data to parquet data and places in the raw layer
 * 
 * @author zkpsz5o(Ravi Kambalapally)
 * @date 10/14/2016
 * @application name : ECR System Engineering
 * 
 *
 */

public class DataBaseSourcingService extends DataSourcingService {
	final static Logger logger =Logger.getLogger(DataBaseSourcingService.class);
	List<String> logArgs = new ArrayList<String>();

	/**
	 * processFile method is used to process the sqoop imported text file. 
	 * This method creates an dataframe from the imported text file to perform the DI checks and finally writes the dataframe to raw layer
	 * @param jsc 
	 * @param sqlContext
	 * @param hiveCtx 
	 * @param conf 
	 * @param fs
	 * @param inputArgsMap
	 * @param schemaMapLst
	 * @param config
	 * @throws Exception
	 */
	public void processFeed(JavaSparkContext jsc, SQLContext sqlContext,HiveContext hiveCtx, Configuration conf, FileSystem fs,
			Map<String, String> inputArgsMap, SchemaMappingList schemaMapLst,RawConfiguration config) throws Exception {
		
		logger.info(new StringBuilder()
				.append(Constants.PRINT_FORMATTER)
				.append("Processing of Sqoop Imported File Started...")
				.append(Constants.PRINT_FORMATTER)
				.toString()
			);
		
		DataIntegrityCheckService diService = null;
		DataFrame sourceDF = null;
		HadoopLogger hadoopLogger = getHadoopLogger();
		try{
			
			StructType rawTableSchema = SchemaOperationsUtil.getSchemaFromHive(config.getTgtHiveDatabaseName(),config.getTgtHiveTableName(), hiveCtx);
			StructType srcSchemaMapping = SchemaOperationsUtil.getSrcFileSchemaMapping(rawTableSchema,schemaMapLst.getColumnMapping());
			StructField[] temp = srcSchemaMapping.fields();
			String[] schemaFields = new String[temp.length];
			for (int i = 0; i < temp.length; i++){
				schemaFields[i] = temp[i].dataType().toString();
			}
			Broadcast<String[]> structFields = jsc.broadcast(schemaFields);
			Accumulator[] accumlatorArr = new Accumulator[temp.length];
			for (int i = 0; i < accumlatorArr.length; i++) {
				accumlatorArr[i] = jsc.accumulator(0, temp[i].name());
			}
			diService = DataIntegrityCheckServiceFactory.diService(Constants.DATABASE);
			sourceDF = SchemaOperationsUtil.convertSourceToDataFrame(jsc.textFile(config.getSrcFeedLocation()),srcSchemaMapping, structFields, config, hiveCtx, accumlatorArr);
			sourceDF.count();
			StringBuilder nullValueCount = new StringBuilder();
			for (int i = 0; i < accumlatorArr.length; i++) {					
				if (Long.parseLong(accumlatorArr[i].value().toString()) > 0) {
					nullValueCount.append(String.format("Column %s has %s null values. Please validate if that is expected output.",temp[i].name(),accumlatorArr[i].value().toString() )).append("\n");						
				}					
			}			
		
			logger.info(new StringBuilder()
					.append(Constants.PRINT_FORMATTER)
					.append("Data Itegrity Checks processing started....")
					.append(Constants.PRINT_FORMATTER)
					.toString()
				);           
	   
			if (!diService.performDIValidations(config, sourceDF,null,hiveCtx,null,null,inputArgsMap,null)) {

				logger.info(new StringBuilder()
						.append(Constants.PRINT_FORMATTER)
						.append(DSErrorCodes.DSRC_104.value())
						.append(Constants.PRINT_FORMATTER)
						.toString()
					); 
				hadoopLogger.exception(Layer.SOURCING.value(), config.getArchiveDirLocation().trim(), 
						DSErrorCodes.DSRC_104.value() + " Exception in archiving file.");
		   		throw new DataSourcingException(DSErrorCodes.DSRC_104.value());
			}

			if (config.isHasTablePartitions()) {

				if (null != config.getTgtPartitionColumns()) {

					String[] partiton_columns = config.getTgtPartitionColumns().split(Constants.COMMA);
					List<String> dynamicValuesLst = DataSourcingUtil
							.getSrcInAndOutColumnMap(schemaMapLst).get(Constants.COLUMNS_NOT_IN_SRC_FILE);
					Map<String, List<SchemaMapping>> columnsMap = DataSourcingUtil.getPatitionsColumnsSchemaInOrder(schemaMapLst);
					List<SchemaMapping> partitonLst = columnsMap.get(Constants.COLUMNS_IN_PARTITION);
					String[] notInPartitionsLst = DataSourcingUtil.getColumnsNotInPartitions(columnsMap.get(Constants.COLUMNS_NOT_IN_PARTITION));
					DataFrame finalDataFrame = DataSourcingUtil.addColumnsToDF(sourceDF, partitonLst, dynamicValuesLst,inputArgsMap,rawTableSchema);
					sourceDF.unpersist();
					finalDataFrame.persist();
					DataSourcingUtil.writePartitionedDFToRaw(partiton_columns,notInPartitionsLst,finalDataFrame,hiveCtx,config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName());
					hadoopLogger.info(Layer.RAWLAYER.value(), config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName() , 
										config.getSrcFeedLocation() + "File moved to Raw Layer");

				}

			} else {
				
				DataSourcingUtil.writeDFToRaw(sourceDF,hiveCtx,config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName(), rawTableSchema);
				hadoopLogger.info(Layer.RAWLAYER.value(), config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName() , 
									config.getSrcFeedLocation() + "File moved to Raw Layer");

			}
			
			hadoopLogger.info(Layer.SOURCING.value(), config.getSrcFeedName().trim(), nullValueCount.toString());

			
			if (config.isArchiveFile() && StringUtils.notEmpty(config.getArchiveDirLocation())) {
				try {
					HdfsUtils.archiveFile(fs, config.getSrcFeedLocation().trim(), config.getArchiveDirLocation().trim(), conf, false) ;	
					hadoopLogger.info(Layer.ARCHIVE.value(), config.getArchiveDirLocation().trim(), "File Archived");
				} catch(Exception e) {
					hadoopLogger.exception(Layer.ARCHIVE.value(), config.getArchiveDirLocation().trim(), 
											DSErrorCodes.DSRC_105.value() + " Exception in archiving file.", e);
					logger.error(DSErrorCodes.DSRC_105.value());					
					throw new DataSourcingException(DSErrorCodes.DSRC_105.value(),e);
				}
			}
		} catch (DataSourcingException dse) {
			hadoopLogger.exception(Layer.SOURCING.value(), dse.getMessage(), dse);
			dse.printStackTrace();
		}finally{
			hadoopLogger.close();
		}
	}
}
