package com.bac.ecr.hdf.components.ds.service;

import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

import com.bac.ecr.hdf.components.di.DataIntegrityDriver;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogFactory;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;

public abstract class DataSourcingService {
	
	

	/**
	 * processFeed method reads the file from source location and process DI validations,
	 * inserts into parquet table and archives the file to archive directory.
	 * @param jsc
	 * @param sqlContext
	 * @param hiveCtx
	 * @param conf
	 * @param fs
	 * @param inputArgsMap
	 * @param schemaMapLst
	 * @param config
	 * @throws Exception
	 */
	public abstract void processFeed(JavaSparkContext jsc,
										SQLContext sqlContext,
										HiveContext hiveCtx, 
										Configuration conf, 
										FileSystem fs, 
										Map<String,String> inputArgsMap, 
										SchemaMappingList schemaMapLst, 
										RawConfiguration config
									) throws Exception ;
	
	
	/**
	 * getHadoopLogger method returns HadoopLogger instance.
	 * @return HadoopLogger
	 */
	protected HadoopLogger getHadoopLogger(){
		return HadoopLogFactory.getInstance(this.getClass().getSimpleName(), DDI_LAYER.SOURCE, new Configuration());
	}
}
