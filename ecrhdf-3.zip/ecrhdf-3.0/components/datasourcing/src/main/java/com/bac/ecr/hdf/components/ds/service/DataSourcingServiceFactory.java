package com.bac.ecr.hdf.components.ds.service;


import com.bac.ecr.hdf.components.utils.commonbeans.Constants;

public class DataSourcingServiceFactory {

	
	/**
	 * createService method retuns the corresponding class instance depending on file format.
	 * @param feedType
	 * @return DataSourcingService
	 */
	public static DataSourcingService createService(String feedType) {
		DataSourcingService ds = null;		
		
		if (Constants.DELIMITED.equals(feedType.toUpperCase())) {			
			ds = new DelimiterFileService();
		} else if (Constants.FIXEDLENGTH.equals(feedType.toUpperCase())) {
			ds = new DelimiterFileService();
		} else if (Constants.VARIABLELENGTH.equals(feedType.toUpperCase())){
			ds = new DelimiterFileService();
		} else if(Constants.DATABASE.equals(feedType.toUpperCase()))
			ds = new DataBaseSourcingService();
		return ds;
	}
	
}
