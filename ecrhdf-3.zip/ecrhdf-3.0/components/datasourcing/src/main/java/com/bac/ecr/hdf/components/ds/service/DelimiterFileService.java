/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */
package com.bac.ecr.hdf.components.ds.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.Accumulator;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.datanucleus.util.StringUtils;

import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckService;
import com.bac.ecr.hdf.components.di.service.DataIntegrityCheckServiceFactory;
import com.bac.ecr.hdf.components.ds.beans.DataSourcingConstants.DSErrorCodes;
import com.bac.ecr.hdf.components.ds.beans.DataSourcingConstants.Layer;
import com.bac.ecr.hdf.components.ds.utils.DataSourcingException;
import com.bac.ecr.hdf.components.ds.utils.DataSourcingUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.HdfsUtils;
import com.bac.ecr.hdf.components.utils.commonutils.HeaderTrailerOperationsUtil;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;

public class DelimiterFileService extends DataSourcingService {

	private final static Logger logger = Logger.getLogger(DelimiterFileService.class);

	
	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.ds.service.DataSourcingService#processFeed(org.apache.spark.api.java.JavaSparkContext, 
	 * org.apache.spark.sql.SQLContext, 
	 * org.apache.spark.sql.hive.HiveContext, 
	 * org.apache.hadoop.conf.Configuration, 
	 * org.apache.hadoop.fs.FileSystem, 
	 * java.util.Map, 
	 * com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList, 
	 * com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration)
	 */
	public void processFeed(JavaSparkContext jsc,
			SQLContext sqlContext,
			HiveContext hiveCtx, 
			Configuration conf, 
			FileSystem fs, 
			Map<String,String> inputArgsMap, 
			SchemaMappingList schemaMapLst, 
			RawConfiguration config) throws Exception {


		DataIntegrityCheckService diService = null;
		HadoopLogger hadoopLogger = getHadoopLogger();
		try {		
			// this code is to read file into an RDD 
			JavaRDD<String> inputData = jsc.textFile(config.getSrcFeedLocation());
			inputData.toDebugString();
			StructType rawTableSchema = SchemaOperationsUtil.getSchemaFromHive(config.getTgtHiveDatabaseName(),config.getTgtHiveTableName(), hiveCtx);
			StructType srcFileSchemaMapping = SchemaOperationsUtil.getSrcFileSchemaMapping(rawTableSchema,schemaMapLst.getColumnMapping());
			StructField[] temp = srcFileSchemaMapping.fields();
			String[] schemaFields = new String[temp.length];
			for (int i = 0; i < temp.length; i++){
				schemaFields[i] = temp[i].dataType().toString();
			}
			Broadcast<String[]> structFields = jsc.broadcast(schemaFields);			
			diService = DataIntegrityCheckServiceFactory.diService(config.getSrcFileFormat());						
			Accumulator[] accumlatorArr = new Accumulator[temp.length];
			for (int i = 0; i < accumlatorArr.length; i++) {
				accumlatorArr[i] = jsc.accumulator(0, temp[i].name());
			}

			DataFrame rawTableDf = null;
			JavaRDD<String> preparedData;
			String headerRecord ="",trailerRecord ="";
			headerRecord = (config.isHasHeader()) ? HeaderTrailerOperationsUtil.extractHeader(inputData,config) : "";
			trailerRecord = (config.isHasTrailer()) ? HeaderTrailerOperationsUtil.extractTrailerRecord(fs, new Path(config.getSrcFeedLocation())) : "";

			if (config.isHasHeader() || config.isHasTrailer()) {
				preparedData = inputData.filter(HeaderTrailerOperationsUtil.removeHDRTRL(config,headerRecord.trim(),trailerRecord.trim()));	
			} else {
				preparedData = inputData;
			}

			//JavaRDD<String> headerTrailerFiltered = inputData.filter(DataSourcingUtil.removeHDRTRL(config,headerRecord,trailerRecord));
			rawTableDf = SchemaOperationsUtil.convertSourceToDataFrame(preparedData, srcFileSchemaMapping,structFields,  config, hiveCtx, accumlatorArr);
			rawTableDf.count();
			StringBuilder nullValueCount = new StringBuilder();
			for (int i = 0; i < accumlatorArr.length; i++) {					
				if (Long.parseLong(accumlatorArr[i].value().toString()) > 0) {
					nullValueCount.append(String.format("Column %s has %s null values. Please validate if that is expected output.",temp[i].name(),accumlatorArr[i].value().toString() )).append("\n");						
				}					
			}
			
			rawTableDf.explain(true);
			boolean diChecksResult = diService.performDIValidations(config,rawTableDf,rawTableSchema,hiveCtx,trailerRecord,headerRecord,inputArgsMap,srcFileSchemaMapping);


			if (diChecksResult) {
				if (config.isHasTablePartitions()) {


					if (null != config.getTgtPartitionColumns()) {


						String[] partiton_columns=config.getTgtPartitionColumns().split(",");
						List<String> dynamicValuesLst = DataSourcingUtil.getSrcInAndOutColumnMap(schemaMapLst).get(Constants.COLUMNS_NOT_IN_SRC_FILE);
						Map<String,List<SchemaMapping>> columnsMap = DataSourcingUtil.getPatitionsColumnsSchemaInOrder(schemaMapLst);
						List<SchemaMapping> partitonLst = columnsMap.get(Constants.COLUMNS_IN_PARTITION);
						String[] notInPartitionsLst = DataSourcingUtil.getColumnsNotInPartitions(columnsMap.get(Constants.COLUMNS_NOT_IN_PARTITION));
						DataFrame finalDataFrame = DataSourcingUtil.addColumnsToDF(rawTableDf, partitonLst, dynamicValuesLst, inputArgsMap, rawTableSchema);
						finalDataFrame.explain(true);
						DataSourcingUtil.writePartitionedDFToRaw(partiton_columns, notInPartitionsLst,finalDataFrame,hiveCtx , config.getTgtHiveDatabaseName()+"."+config.getTgtHiveTableName());
						hadoopLogger.info(Layer.RAWLAYER.value(), config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName() , 
								config.getSrcFeedLocation() + "File moved to Raw Layer");
					} 


				} else {
					DataSourcingUtil.writeDFToRaw(rawTableDf, hiveCtx , config.getTgtHiveDatabaseName()+"."+config.getTgtHiveTableName(), rawTableSchema);
					hadoopLogger.info(Layer.RAWLAYER.value(), config.getTgtHiveDatabaseName() + "."+ config.getTgtHiveTableName() , 
							config.getSrcFeedLocation() + "File moved to Raw Layer");
				}


				hadoopLogger.info(Layer.SOURCING.value(), config.getSrcFeedName().trim(), nullValueCount.toString());

				//Archive the file to Archive Directory location

				if (config.isArchiveFile() && StringUtils.notEmpty(config.getArchiveDirLocation())) {
					try {
						HdfsUtils.archiveFile(fs, config.getSrcFeedLocation().trim(), config.getArchiveDirLocation().trim(), conf, false) ;	
						hadoopLogger.info(Layer.ARCHIVE.value(), config.getArchiveDirLocation().trim(), "File Archived");
					} catch(IOException ie) {
						hadoopLogger.exception(Layer.ARCHIVE.value(), config.getArchiveDirLocation().trim(), 
								DSErrorCodes.DSRC_105.value() + " Exception in archiving file.", ie);
						logger.error(DSErrorCodes.DSRC_105.value());					
						throw new DataSourcingException(DSErrorCodes.DSRC_105.value(),ie);
					}
				}
			}
		} catch(Exception e) {
			hadoopLogger.exception(Layer.SOURCING.value(), e.getMessage(), e);
			throw e;
		}finally{
			hadoopLogger.close();
		}
	}



	
	
}
