package com.bac.ecr.hdf.components.ds.service;

import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;

public class FixedLengthFileService extends DataSourcingService {

	
	/* (non-Javadoc)
	 * @see com.bac.ecr.hdf.components.ds.service.DataSourcingService#processFeed(org.apache.spark.api.java.JavaSparkContext, 
	 * org.apache.spark.sql.SQLContext, 
	 * org.apache.spark.sql.hive.HiveContext, 
	 * org.apache.hadoop.conf.Configuration, 
	 * org.apache.hadoop.fs.FileSystem, 
	 * java.util.Map, 
	 * com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList, 
	 * com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration)
	 */
	public void processFeed(JavaSparkContext jsc,
			SQLContext sqlContext,
			HiveContext hiveCtx, 
			Configuration conf, 
			FileSystem fs, 
			Map<String,String> inputArgsMap, 
			SchemaMappingList schemaMapLst, 
			RawConfiguration config) throws Exception {
		
	}
}
