/**
	 * @author : ZKZB9LR
	 * @Description : This is a custom exception class for data sourcing project, and it is used for throwing application
	 * specific exceptions
	 */
	
package com.bac.ecr.hdf.components.ds.utils;

public class DataSourcingException extends RuntimeException {

	public DataSourcingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataSourcingException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DataSourcingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DataSourcingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DataSourcingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
