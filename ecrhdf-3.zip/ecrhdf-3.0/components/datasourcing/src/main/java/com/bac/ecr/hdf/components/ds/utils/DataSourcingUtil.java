package com.bac.ecr.hdf.components.ds.utils;

import java.io.EOFException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bac.ecr.hdf.components.ds.beans.DataSourcingConstants.DSErrorCodes;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;
/**
 * @author ZKFYMQ6
 *
 */
public class DataSourcingUtil {
	
	final static Logger logger = Logger.getLogger(DataSourcingUtil.class);
   
	
	

	/**
	 * This method compares the schemas obtained from JSON mapping & Hive and returns true if both schemas match
	 * @param mappingSchema
	 * @param hiveSchema
	 * @return boolean
	 * @throws : DataSourcingException
	 */
	public boolean validateMappingSchemaWithHiveSchema(StructType mappingSchema, StructType hiveSchema) {
		boolean result = false;
		int counter=0;
		
		StructField[] hiveColumns = hiveSchema.fields();
		for (int idx=0;idx < hiveColumns.length; idx++) {
			if (mappingSchema.contains(hiveColumns[idx])) {
				counter++;
			}
		}
		result = (counter == hiveColumns.length) ? true : false;
		if (!result) {
			throw new DataSourcingException(DSErrorCodes.DSRC_109.value());
		}
		return result;

	}
	
	/**
	 * Return a HashMap  with  source column name value  as key and columnMapping object as value
	 * @param raw
	 * @return Map<String,SchemaMapping>
	 */
	public static Map<String,SchemaMapping> getRawColumnMap(SchemaMappingList raw) {
		Map<String,SchemaMapping> rawMap = new HashMap<String,SchemaMapping>();
		
		if (null != raw) {
			raw.getColumnMapping().forEach(rcm -> {
				rawMap.put(rcm.getColumnName(), rcm);
			});
		} else {
			logger.error(DSErrorCodes.DSRC_110.value());
			throw new DataSourcingException(DSErrorCodes.DSRC_110.value());
		}
		
		return rawMap;
	}
	
			
	/**
	 * Checks if partition column name exists in given hive schema
	 * @param partArg
	 * @param schema
	 * @return Boolean
	 * @throws Exception
	 */
	public static Boolean isPartitionExists(ArrayList<String> partArg,StructType schema) throws Exception {
		
		String[] columns = schema.fieldNames();
		
		for(String value: partArg){
			String[] fields = value.split(Pattern.quote("="), -1);
			String columnName = fields[0];
				
			if(!Arrays.stream(columns).anyMatch(i -> i.trim().equalsIgnoreCase(columnName))){		
				return false;
			}
			}
		return true;
		
	}


	/**
	 * writePartitionedDFToRaw method writes the data frame to hive table with partitions.
	 * @param partitoned_column
	 * @param trgSchema
	 * @param finalInputDF
	 * @param hiveContext
	 * @param trgTable
	 */
	public static void writePartitionedDFToRaw(String[] partitoned_column, String[] trgSchema,DataFrame finalInputDF, HiveContext hiveContext , String trgTable) {
		try {
			StringBuilder hiveQuerySB = new StringBuilder();
			hiveContext.registerDataFrameAsTable(finalInputDF, "trg_tbl");
			hiveQuerySB.append("insert overwrite table " + trgTable +" partition(").append(String.join(",", partitoned_column)).append(") select ").append(String.join(",", trgSchema)).append(",").append(String.join(",", partitoned_column)).append(" from trg_tbl");
			
			hiveContext.sql(hiveQuerySB.toString());
			hiveContext.sql("MSCK REPAIR TABLE "+trgTable);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(DSErrorCodes.DSRC_111.value());
			throw new DataSourcingException(DSErrorCodes.DSRC_111.value(),e);
		}
	}
	
	/**
	 * writeDFToRaw method inserts the data frame to hive table with out partitions.
	 * @param InputDF
	 * @param hiveContext
	 * @param trgTable
	 * @param trgSchema
	 */
	public static void writeDFToRaw(DataFrame InputDF, HiveContext hiveContext , String trgTable, StructType trgSchema){
		try {
			StringBuilder hiveQuerySB = new StringBuilder();
			hiveContext.registerDataFrameAsTable(InputDF, "trg_tbl");
			hiveQuerySB.append("insert overwrite table " + trgTable +" select ").append(String.join(",", trgSchema.fieldNames())).append(" from trg_tbl");
			hiveContext.sql(hiveQuerySB.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(DSErrorCodes.DSRC_112.value());
			throw new DataSourcingException(DSErrorCodes.DSRC_112.value(),e);
		}
	}

	/**
	 * getCurrentTimeStamp method returns timestamp in UTC time zone.
	 * @return String
	 */
	public static String getCurrentTimeStamp(){	 
		 final SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
	     f.setTimeZone(TimeZone.getTimeZone("UTC"));
	     return f.format(new Date());
	 }


	/**
	 * getSrcInAndOutColumnMap method returns a map with arraylists for mapping columns present in source feed file 
	 * and the columns that are not in source file which needs to be taken from user provided input.
	 * @param schemaMapLst
	 * @return Map<String,List<String>>
	 */
	public static Map<String,List<String>> getSrcInAndOutColumnMap(SchemaMappingList schemaMapLst) {
		Map<String,List<String>> columnMap = new HashMap<String,List<String>>();
		List<String> columnsNotInSrcFileLst = new ArrayList<String>();
		List<String> columnsInSrcFileLst = new ArrayList<String>();	
		try{
		schemaMapLst.getColumnMapping().forEach(schema -> { 
			if (!schema.isInSourceFile())  {
				columnsNotInSrcFileLst.add(schema.getColumnName().trim());
			} else if (schema.isInSourceFile()){
				columnsInSrcFileLst.add(schema.getColumnName().trim());
			}
			
		});

		columnMap.put(Constants.COLUMNS_NOT_IN_SRC_FILE, columnsNotInSrcFileLst);
		columnMap.put(Constants.COLUMNS_IN_SRC_FILE, columnsInSrcFileLst);
		} catch(Exception e){
			logger.error(DSErrorCodes.DSRC_113.value());
			throw new DataSourcingException(DSErrorCodes.DSRC_113.value(),e);
		}
		return columnMap;
	}

	/**
	 * getPatitionsColumnsSchemaInOrder method returns a map of arrayList with columns that are in partitions and columns not in partitions.
	 * @param schemaMapLst
	 * @return Map<String,List<SchemaMapping>>
	 */
	public static Map<String,List<SchemaMapping>> getPatitionsColumnsSchemaInOrder(SchemaMappingList schemaMapLst) {
		Map<String,List<SchemaMapping>> columnsMap = new HashMap<String,List<SchemaMapping>>();
		List<SchemaMapping> columnsInPartitionLst = new ArrayList<SchemaMapping>();
		List<SchemaMapping> columnsNotInPartitionLst = new ArrayList<SchemaMapping>();
		try{
		schemaMapLst.getColumnMapping().forEach(schema -> { 
			if(StringUtils.isNotEmpty(schema.getIsPartitioned()) && ("Y".toUpperCase().equals(schema.getIsPartitioned().toUpperCase()))) {
				columnsInPartitionLst.add(schema);
			} else {
				columnsNotInPartitionLst.add(schema);
			}
		});
		Collections.sort(columnsInPartitionLst,new Comparator<SchemaMapping>() {
			public int compare(SchemaMapping m1, SchemaMapping m2) {
				return m1.getPartitionOrder() - m2.getPartitionOrder();
			}
		});
		Collections.sort(columnsNotInPartitionLst,new Comparator<SchemaMapping>() {
			public int compare(SchemaMapping m1, SchemaMapping m2) {
				return m1.getPartitionOrder() - m2.getPartitionOrder();
			}
		});
		columnsMap.put(Constants.COLUMNS_IN_PARTITION, columnsInPartitionLst);
		columnsMap.put(Constants.COLUMNS_NOT_IN_PARTITION, columnsNotInPartitionLst);
	} catch(Exception e){
		logger.error(DSErrorCodes.DSRC_114.value());
		throw new DataSourcingException(DSErrorCodes.DSRC_114.value(),e);
	}
		return columnsMap;
	}
	

	/**
	 * addColumnsToDF method add extra columns to the existing DF with dynamic values.
	 * @param dataFrame
	 * @param partitonLst
	 * @param dynamicValuesLst
	 * @param inputArgsMap
	 * @param rawTableSchema
	 * @return DataFrame
	 */
	public static DataFrame addColumnsToDF(DataFrame dataFrame, List<SchemaMapping> partitonLst, List<String> dynamicValuesLst, Map<String,String> inputArgsMap, StructType rawTableSchema) {
		DataFrame finalDF =  dataFrame; 
		//this code added for debugging, dont commit it
		for (String dval : dynamicValuesLst) {
			System.out.println("dval : "+dval);
		}
		for (SchemaMapping schema: partitonLst) {
			  String partitionedColumnName = schema.getColumnName().trim();
			if (dynamicValuesLst.contains(partitionedColumnName)) {
				String partitionValue = inputArgsMap.get(partitionedColumnName);
				System.out.println(" partitioned column value : "+partitionValue);
				String dataType = rawTableSchema.apply(partitionedColumnName).dataType().toString();
				System.out.println("data type of partitioned column : "+dataType);
				finalDF = finalDF.withColumn(partitionedColumnName, functions.lit(SchemaOperationsUtil.getColumnDataTypeVal(dataType,partitionValue)));
			}

		}
		return finalDF;
	}
	
	

	/**
	 * getColumnsNotInPartitions  method retuns columns not in partitions.
	 * @param notInPartitionsLst
	 * @return String[]
	 */
	public static String[] getColumnsNotInPartitions(List<SchemaMapping> notInPartitionsLst) {
		List<String> lst = new ArrayList<String>();
		
		notInPartitionsLst.forEach(schema -> {
			lst.add(schema.getColumnName().trim());
		});
		String[] notInPartitionsArr = new String[lst.size()];
		
		return lst.toArray(notInPartitionsArr);
	}


	/**
	 * getTimestampAppendedString method returns date and time seperated by "/".
	 * @param archiveDir
	 * @return String
	 */
	public static String getTimestampAppendedString(String archiveDir) {
		String[] dateTime =  getDateAsString().split(":");
		if (archiveDir.endsWith("/")) {
			return archiveDir+dateTime[0]+"/"+dateTime[1];
		} else {
			return archiveDir+"/"+dateTime[0]+"/"+dateTime[1];
		}		
	}
	

	/**
	 * getDateAsString method returns date and time in UTC timezone.
	 * @return String
	 */
	public static String getDateAsString() {
		 final SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd:HH-mm-ss");
	     f.setTimeZone(TimeZone.getTimeZone("UTC"));
	     return f.format(new Date());
	}
	

}