#!/bin/bash
echo 'prepare for workflow'
HDFS_TEMP_DIR=$1
#hadoop fs -put -f integrity_workflow.xml /haas/pks/peaks_sit1/work/sit1/hdpf/
hdfs dfs -put -f integrity_workflow.xml ${HDFS_TEMP_DIR}
echo 'copied workflow xml'
hdfs dfs -put -f nzjdbc3.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f terajdbc4.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f sqljdbc4.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f ojdbc6.jar ${HDFS_TEMP_DIR}/lib/
hadoop fs -put -f dataintegrity-1.0.0.jar ${HDFS_TEMP_DIR}
echo 'copied the jar to app path'
hdfs dfs -put -f config.json ${HDFS_TEMP_DIR}
hdfs dfs -put -f mapping.json ${HDFS_TEMP_DIR}
hdfs dfs -put -f hive-site.xml ${HDFS_TEMP_DIR}
hdfs dfs -put -f hadooplog4j.properties ${HDFS_TEMP_DIR}
echo 'copied JSON files'

oozie job -oozie https://lrdne22epapd1i.corp.bankofamerica.com:11443/oozie -run -config integrity.properties
