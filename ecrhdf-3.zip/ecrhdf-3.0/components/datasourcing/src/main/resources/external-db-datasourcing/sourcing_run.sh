#!/bin/bash
#hdfs dfs -rm -r -skipTrash hdfs://nameservice1/haas/pks/peaks_sit1/work/sit1/hdpf/facility_risk
#hdfs dfs -rm -r -skipTrash hdfs://nameservice1/haas/pks/peaks_sit1/work/sit1/hdpf/facility_lifelink
echo 'prepare for workflow'
HDFS_TEMP_DIR=$1
hdfs dfs -put -f sourcing_workflow.xml ${HDFS_TEMP_DIR}
echo 'copied workflow xml'
hdfs dfs -put -f nzjdbc3.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f terajdbc4.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f sqljdbc4.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f ojdbc6.jar ${HDFS_TEMP_DIR}/lib/
hdfs dfs -put -f datasourcing-1.0.0.jar ${HDFS_TEMP_DIR}
echo 'copied the jar to app path'
hdfs dfs -put -f config.json ${HDFS_TEMP_DIR}
hdfs dfs -put -f mapping.json ${HDFS_TEMP_DIR}
hdfs dfs -put -f hive-site.xml ${HDFS_TEMP_DIR}
hdfs dfs -put -f hadooplog4j.properties ${HDFS_TEMP_DIR}
echo 'copied JSON files'

oozie job -oozie https://lrdne22epapd1i.corp.bankofamerica.com:11443/oozie -run -config sourcing.properties
