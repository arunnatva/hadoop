package com.bac.ecr.hdf.components.ds.tests;

import org.apache.hadoop.fs.Path;
import org.testng.annotations.Test;

public class DataSourcingTest extends BaseTest {
	private static final String SOURCE_FILE="src/test/resources/source_guart_file";
	
  @Test(enabled=true)
  public void LoadSourceFile() {

	  Path path = new Path(SOURCE_FILE);

	  System.out.println(path.toString());
	  //JavaRDD<String> inputData = getJsc().textFile(path.toString());
	  
	  //System.out.println(inputData.count());
  }
}
