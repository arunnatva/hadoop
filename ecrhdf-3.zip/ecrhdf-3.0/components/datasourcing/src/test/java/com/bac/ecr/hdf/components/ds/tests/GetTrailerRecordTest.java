package com.bac.ecr.hdf.components.ds.tests;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.components.utils.commonutils.HeaderTrailerOperationsUtil;

public class GetTrailerRecordTest {

	//FileSystem lfs = new LocalFileSystem();
	//Path path = new Path("src/test/resources/sampleFile.txt");
	Path path = new Path("src/test/resources/source_guart_file");
	
	@Test(enabled=true)
	public void getTrailerRec() throws IOException {
	
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		String trailerRec = HeaderTrailerOperationsUtil.extractTrailerRecord(fs, path);
		System.out.println("trailer rec : "+trailerRec);
		Assert.assertEquals("TRAILER,4",trailerRec);
		
	}
	
}
