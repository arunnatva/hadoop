package com.bac.ecr.hdf.components.ds.tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
//import com.bac.ecr.di.beans.MapToRaw;

public class JsonParseUtilTest {

	private JsonParseUtil jsonParseUtil = new JsonParseUtil();
	File jsonConfigFile;
	String json="";
	RawConfiguration dataSrcConfig = new RawConfiguration();


	@BeforeClass
	public void beforeClass() throws IOException {
		json = getJsonConfig("src/test/resources/jsonConfig.txt");
	}

	@Test(enabled=true)
	public  void testMapToRaw() throws JsonParseException, JsonMappingException, IOException, Exception {
		String jsonString = new String("{\"columnMapping\": [{\"srcColumnName\":\"RECORD_CD\",\"srcColumnDataType\":\"string\",\"targetColumnName\":\"RECORD_CD\",\"targetColumnDataType\":\"string\",\"businessDesc\":\"Code to identify each Record Type\"},{\"srcColumnName\":\"SEGMENTATION_EXPOSURE_AM\",\"srcColumnDataType\":\"Double\",\"targetColumnName\":\"SEGMENTATION_EXPOSURE_AM\",\"targetColumnDataType\":\"Double\",\"businessDesc\":\"Segmentation Exposure Amount\"},{\"srcColumnName\":\"GLA_NO\",\"srcColumnDataType\":\"Int\",\"targetColumnName\":\"GLA_NO\",\"targetColumnDataType\":\"Int\",\"businessDesc\":\"Ledger No\"}]}");
		SchemaMappingList mapToRaw = new SchemaMappingList();


		mapToRaw = (SchemaMappingList)jsonParseUtil.parseJSON(jsonString, mapToRaw);
		Assert.assertEquals(mapToRaw.getColumnMapping().size(), 3);

	}

	@Test(enabled=true)
	public  void testDataSourcingConfiguration() throws JsonParseException, JsonMappingException, IOException, Exception {
		RawConfiguration config = new RawConfiguration();
		//System.out.println("file details : "+jsonConfigFile.getName()+" "+jsonConfigFile.getAbsolutePath());
		dataSrcConfig = (RawConfiguration)jsonParseUtil.parseJSON(json, config);
		if (dataSrcConfig.getTgtFeedLocation() != null) {
			System.out.println("tgt feed loc : "+dataSrcConfig.getTgtFeedLocation());
		}
		System.out.println("trailer chk : "+dataSrcConfig.getTrailerCheckConfig());
		Assert.assertEquals(dataSrcConfig.isHasHeader(),true);
		Assert.assertEquals(dataSrcConfig.isHasTrailer(),false);
		Assert.assertEquals(dataSrcConfig.getTgtFeedLocation(),null);
		
	}

	public static String getJsonConfig(String filePath) throws IOException {
		String jsonConfig = null;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(filePath)));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			jsonConfig = sb.toString();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			br.close();
		}

		return jsonConfig;
	}
}
