package com.bac.ecr.hdf.components.ds.tests;

import java.util.Arrays;
import java.util.Map;

import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.components.ds.utils.DataSourcingUtil;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;

public class PatitionTest extends BaseTest{
	
	private static final String MAPPING_FILE="src/test/resources/mapping.json";
	private static final String CONFIG_FILE="src/test/resources/jsonConfig.txt";
	
  @Test
  public void parseMappingJson()  throws Exception {
	  
	  
	  String configJson = JsonParseUtilTest.getJsonConfig(CONFIG_FILE);
	  
	  String mappingJson = JsonParseUtilTest.getJsonConfig(MAPPING_FILE);
	  
	  SchemaMappingList schemaMapLst = (SchemaMappingList)JsonParseUtil.parseJSON(mappingJson,new SchemaMappingList());
	  System.out.println(" size is " + schemaMapLst.getColumnMapping().size());
	  Map<String,SchemaMapping> rawMap = DataSourcingUtil.getRawColumnMap(schemaMapLst);
	  RawConfiguration config = (RawConfiguration) JsonParseUtil.parseJSON(configJson, new RawConfiguration());
	 // List<String> notAvalLst = DataSourcingUtil.getDynamicValuesList(schemaMapLst);
	  //notAvalLst.forEach(str -> System.out.println("not in list " + str));
	  
	  StructType st = SchemaOperationsUtil.getSchemaFromJsonMapping(schemaMapLst.getColumnMapping());
	  StructField[] sf = st.fields();
	  Arrays.stream(sf).forEach(sfld -> System.out.println(sfld.name() + "  :  " + sfld.dataType().typeName()));
	  
	  //System.out.println(DataSourcingUtil.getTimestampAppendedString("/haas/ale/ale_dev2/work/hdpf/archive"));
	  
	  
	  System.out.println(DataSourcingUtil.getCurrentTimeStamp());
	  
  }
}
