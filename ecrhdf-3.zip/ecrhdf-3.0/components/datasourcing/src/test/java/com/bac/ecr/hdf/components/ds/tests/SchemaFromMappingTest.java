package com.bac.ecr.hdf.components.ds.tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.spark.sql.types.StructType;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.components.utils.commonutils.SchemaOperationsUtil;

public class SchemaFromMappingTest {

	String json="";
	
	@BeforeClass
	public void beforeClass() throws IOException {
		json = getMappingJson("src/test/resources/mapping.json");
	}
	
	
	@Test(enabled=true)
	public void testSchema() throws Exception {
		SchemaMappingList mapToRaw = new SchemaMappingList();

		mapToRaw = (SchemaMappingList)JsonParseUtil.parseJSON(json, mapToRaw);
		Assert.assertEquals(mapToRaw.getColumnMapping().size(), 27);
		StructType schema = SchemaOperationsUtil.getSchemaFromJsonMapping(mapToRaw.getColumnMapping());
		System.out.println(schema.json());
		
	}
	
	
	
	
	public static String getMappingJson(String filePath) throws IOException {
		String jsonConfig = null;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(filePath)));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			jsonConfig = sb.toString();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			br.close();
		}

		return jsonConfig;
	}
}
