package com.bac.ecr.hdf.components.standardization.driver;

import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;

import com.bac.ecr.hdf.components.standardization.service.DataStandardizationService;
import com.bac.ecr.hdf.components.standardization.util.DataStandardizationConstants.STDZErrorCodes;
import com.bac.ecr.hdf.components.standardization.util.DataStandardizationException;
import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationMappingList;
//import com.bac.ecr.hdf.components.datastandardization.*;
import com.bac.ecr.hdf.components.utils.commonutils.CommonUtils;
import com.bac.ecr.hdf.components.utils.commonutils.HdfsUtils;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogFactory;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;


public class DataStandardization {

	final static Logger logger = Logger.getLogger(DataStandardization.class);
	static HadoopLogger hadoopLoger = null;
	public static void main(String[] args) throws Exception {
		
		
		SparkConf sparkConf = new SparkConf().setAppName("Data Standardization");
		sparkConf.set("spark.sql.parquet.compression.codec", "snappy");
		JavaSparkContext jsc = new JavaSparkContext(sparkConf);			
		hadoopLoger = HadoopLogFactory.getInstance(DataStandardization.class.getSimpleName(), DDI_LAYER.DATA_STANDARDIZATION, jsc.hadoopConfiguration());
		
		StandardizationConfiguration standardizationConfig = null;
		StandardizationMappingList standardizationMappingLst = null;
		String configJson = null;
		String mappingJson = null;
		Properties properties = new Properties();
		try {
			Configuration conf = new Configuration();
			FileSystem fs = FileSystem.get(conf);
			
			Map<String,String> inputArgsMap = CommonUtils.getInputArgsMap(args);
			
			if (!CommonUtils.validateInputConfigParams(inputArgsMap)) {				
				throw new DataStandardizationException(STDZErrorCodes.STDZ_102.value());
			}
			
			// If Environment propeties is not provided then dont look for it since it is as optional parameter
			if (inputArgsMap.get(Constants.ENVIRONMENT_PROPERTIES) != null || 
					!StringUtils.isBlank(inputArgsMap.get(Constants.ENVIRONMENT_PROPERTIES))){
				try {				
					properties = HdfsUtils.readProperties(fs, new Path(inputArgsMap.get(Constants.ENVIRONMENT_PROPERTIES).trim()));
							    	
				} catch (Exception e){
						logger.error(STDZErrorCodes.STDZ_110.value());
						throw new DataStandardizationException(STDZErrorCodes.STDZ_110.value(),e);
				}
			}else{
				logger.warn("Environment Properties(envProperties) not provided. Parameterized Jsons might fail.");
			}
			
			try {
				configJson = CommonUtils.substituteVariablesWithValues(HdfsUtils.readHdfsFile(fs, new Path(inputArgsMap.get(Constants.CONFIG_JSON).trim())),
																		properties);
			} catch(Exception e) {								
				throw new DataStandardizationException(STDZErrorCodes.STDZ_100.value(),e);
			}
			
			try {
				mappingJson = HdfsUtils.readHdfsFile(fs, new Path(inputArgsMap.get(Constants.MAPPING_JSON).trim()));			
			} catch(Exception e) {
				throw new DataStandardizationException(STDZErrorCodes.STDZ_101.value(),e);	
			}
			
						
			try {
				standardizationConfig = (StandardizationConfiguration) JsonParseUtil.parseJSON(configJson, new StandardizationConfiguration());				
			} catch(Exception e) {
				throw new DataStandardizationException(STDZErrorCodes.STDZ_106.value(),e);
			}
						
			try {				
				standardizationMappingLst = (StandardizationMappingList)JsonParseUtil.parseJSON(mappingJson,new StandardizationMappingList());
			} catch (Exception e) {
				throw new DataStandardizationException(STDZErrorCodes.STDZ_107.value(),e);
			}
			//TODO Need to move this string to a constant
			String whereClause = inputArgsMap.get("whereClauseArgs");
			DataStandardizationService service = new DataStandardizationService(standardizationConfig, standardizationMappingLst, jsc,hadoopLoger);			
			service.processFeed(whereClause);
			hadoopLoger.info("DataStandardization", 
							standardizationConfig.getTgtFeedDatabaseName() + "." + standardizationConfig.getTgtFeedName(),
							"Data Standardization completed.");
			
		}  catch (DataStandardizationException dse) {
			logger.error(dse.getMessage());
			hadoopLoger.exception("DataStandardization", dse.getMessage());
			dse.printStackTrace();
			throw dse;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			hadoopLoger.close();
			jsc.close();
		}
		
	}
    
	
	/**
	 * dataStandardize method applies standardization rules to the input Dataframe and returns the standardized Dataframe.
	 * @param mapping   Standardization mapping JSON file
	 * @param jsc  		Spark Context 
	 * @param inputDF   Dataframe
	 * @param hadoopLogger HadoopLogger
	 * @return DataFrame
	 */	
	
	public static DataFrame dataStandardize(StandardizationMappingList mapping,JavaSparkContext jsc,DataFrame inputDF,HadoopLogger hadoopLogger) throws Exception{
		DataStandardizationService dsService = new DataStandardizationService(mapping,jsc,hadoopLogger);
		return dsService.performDataStandardization(inputDF);
		
		
	}
	
	/**
	 * dataStandardize method applies standardization rules on the given table in the configuration and returns the Dataframe.
	 * @param config    Standardization Configuration JSON file
	 * @param mapping   Standardization mapping JSON file
	 * @param jsc  		Spark Context 
	 * @param hadoopLogger HadoopLogger
	 * @return DataFrame
	 */	
	
	
	public static DataFrame dataStandardize(StandardizationConfiguration config ,StandardizationMappingList mapping,JavaSparkContext jsc,HadoopLogger hadoopLogger) throws Exception{
		return dataStandardize(config,mapping,jsc,hadoopLogger,"");
		
		
	}
	
	/**
	 * dataStandardize method applies standardization rules on the given table in the configuration and writes the standardized data to the target table
	 * @param config    Standardization Configuration JSON file
	 * @param mapping   Standardization mapping JSON file
	 * @param jsc  		Spark Context
	 * @param hadoopLogger HadoopLogger
	 * @return None
	 */	
	
	public static void dataStandardize(JavaSparkContext jsc,StandardizationConfiguration config ,StandardizationMappingList mapping,HadoopLogger hadoopLogger) throws Exception{
     dataStandardize(jsc,config,mapping,hadoopLogger,"");			
	}
	
	/**
	 * dataStandardize method applies standardization rules on the given table in the configuration and returns the Dataframe.
	 * @param config    Standardization Configuration JSON file
	 * @param mapping   Standardization mapping JSON file
	 * @param jsc  		Spark Context 
	 * @param hadoopLogger HadoopLogger
	 * @param whereClauseArgs Filter condition
	 * @return DataFrame
	 */	
	
	public static DataFrame dataStandardize(StandardizationConfiguration config ,StandardizationMappingList mapping,JavaSparkContext jsc,HadoopLogger hadoopLogger,String whereClauseArgs) throws Exception{
		DataStandardizationService dsService = new DataStandardizationService(config,mapping,jsc,hadoopLogger);
		return dsService.performDataStandardization(dsService.loadInputDataFrame(), whereClauseArgs);
			
	}
	
	/**
	 * dataStandardize method applies standardization rules on the given table in the configuration and writes the standardized data to the target table
	 * @param config    Standardization Configuration JSON file
	 * @param mapping   Standardization mapping JSON file
	 * @param jsc  		Spark Context 
	 * @param hadoopLogger HadoopLogger
	 * @param whereClauseArgs Filter condition
	 * @return None
	 */	

	public static void dataStandardize(JavaSparkContext jsc,StandardizationConfiguration config ,StandardizationMappingList mapping,HadoopLogger hadoopLogger,String whereClauseArgs) throws Exception{
		DataStandardizationService dsService = new DataStandardizationService(config,mapping,jsc,hadoopLogger);
		dsService.processFeed(whereClauseArgs);
				
	}
	
	



}
