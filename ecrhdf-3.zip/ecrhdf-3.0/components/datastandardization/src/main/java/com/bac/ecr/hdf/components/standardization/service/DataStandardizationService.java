package com.bac.ecr.hdf.components.standardization.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.hive.HiveContext;

import com.bac.ecr.hdf.components.standardization.util.DataStandardizationConstants;
import com.bac.ecr.hdf.components.standardization.util.DataStandardizationException;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.DefaultValuesEnum;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;

/**
 * @author ZKZB9LR
 *
 */
/**
 * @author ZKZB9LR
 *
 */
public class DataStandardizationService {

	final static Logger logger = Logger.getLogger(DataStandardizationService.class);
	
	private final static String AS_LITERAL =" AS ";
	private final static String SELECT_LITERAL = " SELECT ";
	private final static String FROM_LITERAL = " FROM ";
	private final static String WHERE_LITERAL = " WHERE ";
	private final static String INSERT_INTO_LITERAL = "INSERT INTO TABLE";
	
	private final static String COL_LITERAL ="col";
	private final static int ZERO_LITERAL=0;
	StandardizationConfiguration config;
	StandardizationMappingList mappingList;
	JavaSparkContext javaSparkContext;
	HiveContext hiveCtx;
    HadoopLogger hadoopLogger ;
	
	
	public DataStandardizationService(StandardizationConfiguration aConfig, 
										StandardizationMappingList aMappingList, 
										JavaSparkContext aJavaSparkContext,HadoopLogger aHadoopLogger){
		this.config = aConfig;
		this.mappingList = aMappingList;
		this.javaSparkContext = aJavaSparkContext;
		this.hadoopLogger=aHadoopLogger;
	}
	
	public DataStandardizationService(StandardizationMappingList aMappingList,
			JavaSparkContext aJavaSparkContext,HadoopLogger aHadoopLogger) {
		this.mappingList=aMappingList;
		this.javaSparkContext=aJavaSparkContext;
		this.hadoopLogger=aHadoopLogger;
	}
	
	/**
	 * Take the Configuration and Mapping as inputs
	 * Prepare Standardization Query
	 * Apply the standardization
	 * Persist the output  
	 */
	
	protected HiveContext getHiveContext(){
		
		if (hiveCtx != null) return hiveCtx;
		
		hiveCtx = new HiveContext(getJavaSparkContext().sc());		
		hiveCtx.setConf("hive.exec.dynamic.partition", "true");
		hiveCtx.setConf("hive.exec.dynamic.partition.mode", "nonstrict");
		return hiveCtx;
	}
	
	protected JavaSparkContext getJavaSparkContext(){
		return javaSparkContext;
	}
	
	
	
	/**
	 * @Description: This method wraps the core processing for data standardization. It does the following:
	 * Loads up the input hive table data into a data frame
	 * Builds the SQL query for standardization based on the standardization rules
	 * Applies the standardizations on input DataFrame
	 * Persists the output DataFrame
	 * @parameters :
	 * @return :
	 * @throws Exception 
	 * @throws :
	 */
	public void processFeed(String whereClauseArgs) throws Exception {
		DataFrame sourceDF = loadInputDataFrame();
		DataFrame outputDF = performDataStandardization(sourceDF, whereClauseArgs);
		String outputDataFrameTempTable = "outputDataFrameTempTable";
		
		try{
			StringBuilder hiveQuery  = new StringBuilder();
			outputDF.registerTempTable(outputDataFrameTempTable);
			if (StringUtils.isBlank(config.getTgtFeedPartitionedColumns())){
				hiveQuery.append(("INSERT OVERWRITE TABLE " + config.getTgtFeedDatabaseName() + "." + config.getTgtFeedName() + " SELECT * FROM " + outputDataFrameTempTable));
			}else{
				hiveQuery.append("insert overwrite table " + 
									config.getTgtFeedDatabaseName() + 
									"." + 
									config.getTgtFeedName()  +
									" partition(").
									append(String.join(",", config.getTgtFeedPartitionedColumns())).
									append(") select ").
									append(String.join(",", buildSourceColumns())).
									append(",").
									append(String.join(",", config.getTgtFeedPartitionedColumns())).
									append(" from " + outputDataFrameTempTable);	
			}
			logger.info(hiveQuery.toString());			
			getHiveContext().sql(hiveQuery.toString());
			
		}catch(Exception e){
			throw new DataStandardizationException(DataStandardizationConstants.STDZErrorCodes.STDZ_109.value(), e);
		}
	}
	
	
	
		
	/**
	 * @Description: This method loads an input DataFrame from the SourceFeed Name (Hive table) coming from the Configuration
	 * @parameters : Hive Context, Configuration
	 * @return : DataFrame
	 * @throws : None
	 */
	public DataFrame loadInputDataFrame() {
		DataFrame inputDF = getHiveContext().sql("SELECT * FROM " + config.getSrcFeedDatabaseName() + "." + config.getSrcFeedName());
		System.out.println("Input Query:" + "SELECT * FROM " + config.getSrcFeedDatabaseName() + "." + config.getSrcFeedName());
		logger.info("*******************Source Field Names:*******************");
		for (String name : inputDF.schema().fieldNames()){
			logger.info(name);
		}
		
		return inputDF;
	}
	
	
	/**
	 * @Description: This method reads a dataframe as an argument and applies the given standardization rules to produce the standardized dataframe. 
	 * @parameters : DataFrame
	 * @return : DataFrame
	 * @throws : None
	 */
	public DataFrame performDataStandardization(DataFrame sourceDF) throws Exception {
       return performDataStandardization(sourceDF, "");
		
	}
	
	
	/**
	 * @Description: This method reads a dataframe as argument applies standardization rules on the same to produce the expected/ 
	 * standardized dataframe. This signature is required to have the ability to consume a dataframe and produce another after applying
	 * standardization rules.
	 * @parameters : DataFrame
	 * @return : DataFrame
	 * @throws : None
	 */
	public DataFrame performDataStandardization(DataFrame sourceDF, String whereClauseArgs) throws Exception {
		DataFrame outputDF = null;
		
		String fromDataFrameTable = "sourceDF";
		try {
			sourceDF.registerTempTable(fromDataFrameTable);
			outputDF = getHiveContext().sql(this.buildStandardizationQuery(whereClauseArgs, fromDataFrameTable));		
		} catch(Exception e) {
			throw new DataStandardizationException("Unable to perform dataStandardization", e);
		}
		return outputDF;
		
	}
	
	
	
	/**
	 * @Description:
	 * @parameters :
	 * @return :
	 * @throws :
	 */
	public String buildStandardizationQuery(String whereClauseArgs,String fromDataFrame){

		StringBuilder queryBuilder = new StringBuilder(SELECT_LITERAL);
		logger.info("********Loaded DataFrame: Query");
		logger.info(buildSelectClause());
		queryBuilder.append(buildSelectClause())
		 			.append(buildFromClause(fromDataFrame))
		 			.append(buildWhereClause(whereClauseArgs));
		logger.info(queryBuilder.toString());
		hadoopLogger.info(DDI_LAYER.DATA_STANDARDIZATION.toString(), " Standardization Query Generated from the DSMAPPING.JSON file "+" '"+queryBuilder.toString()+"' ");
		return queryBuilder.toString();
	}
		
	
	/**
	 * @Description: This method builds SELECT clause with all the columns along with standardization rules applied on those columns.
	 * @parameters : None
	 * @return : String
	 * @throws : None
	 */
	public String buildSelectClause(){
		StringBuilder selectClause = new StringBuilder();
		List<StandardizationMapping> listOfMappings = mappingList.getColStand();
		
		for (StandardizationMapping mapping : listOfMappings) {
			selectClause.append(getExpression(mapping))
						.append(",");
		}
		
		String removeLastComma = selectClause.toString();
		return removeLastComma.substring(0, removeLastComma.length() - 1);
	}
	
	
	/**
	 * @Description: This method builds SELECT clause with all the columns along with standardization rules applied on those columns.
	 * @parameters : None
	 * @return : String
	 * @throws : None
	 */
	public String buildSourceColumns(){
		StringBuilder selectClause = new StringBuilder();
		List<StandardizationMapping> listOfMappings = mappingList.getColStand();
		
		for (StandardizationMapping mapping : listOfMappings) {
			
			if (config.getTgtFeedPartitionedColumns().contains(mapping.getTgtColumnName()))
				continue;
			
			selectClause.append(mapping.getTgtColumnName()).append(AS_LITERAL).append(mapping.getTgtColumnName())
						.append(",");
		}
		
		String removeLastComma = selectClause.toString();
		return removeLastComma.substring(0, removeLastComma.length() - 1);
	}
	
	/**
	 * @Description: This method builds SELECT clause with all the columns along with standardization rules applied on those columns.
	 * @parameters : None
	 * @return : String
	 * @throws : None
	 */
	public String buildSelectClauseWithOnlyTargetColumnNames(){
		StringBuilder selectClause = new StringBuilder();
		List<StandardizationMapping> listOfMappings = mappingList.getColStand();
		
		for (StandardizationMapping mapping : listOfMappings) {
			selectClause.append(mapping.getTgtColumnName()).append(",");						
		}
		
		String removeLastComma = selectClause.toString();
		return removeLastComma.substring(0, removeLastComma.length() - 1);
	}
	
	
	/**
	 * @Description: This method builds the FROM clause by appending the database and table names to the "FROM" string. 
	 * This method reads the db, table names from config object
	 * @parameters : None 
	 * @return : String
	 * @throws : None
	 */
	public String buildFromClause(){
		StringBuilder fromClause = new StringBuilder(FROM_LITERAL);
		fromClause.append(config.getSrcFeedDatabaseName()).
					append(".").
					append(config.getSrcFeedName());
		return fromClause.toString(); 
	}
	
	/**
	 * @Description: This method builds the FROM clause by appending the database and table names to the "FROM" string. 
	 * This method reads the db, table names from config object
	 * @parameters : String 
	 * @return : String
	 * @throws : None
	 */
	public String buildFromClause(String fromTable){
		StringBuilder fromClause = new StringBuilder(FROM_LITERAL);
		fromClause.append(fromTable);									
		return fromClause.toString(); 
	}
	
	
	
	
	/**
	 * @Description: This method builds the WHERE clause of the query by reading runtime arguments passed to the driver
	 * @parameters : String
	 * @return : String
	 * @throws : None
	 */
	public String buildWhereClause(String whereClauseArgs){
		
		if (StringUtils.isBlank(whereClauseArgs)) return "";
		
		return new StringBuilder(WHERE_LITERAL).
					append(whereClauseArgs).
					toString();		
	}
	
	
	/**
	 * @Description: This method reads an object of "StandardizationMapping" and builds an expression based on the standardization rule.
	 * 1. If there is no rule, it returns the source column name itself
	 * 2. If there is a rule, it replaces the string "col" with the column name and returns the expression.
	 * @parameters : StandardizationMapping
	 * @return : Expression String (Examples: trim(column_name), lpad(column_name) etc.,)
	 * @throws : None
	 */
	
	public String getExpression(StandardizationMapping mapping) {
		
		StringBuilder expr= new StringBuilder();
		
		if (StringUtils.isBlank(mapping.getStandardizationRule()) ) {
			expr.append(mapping.getSrcColumnName());				
		}else if( DefaultValuesEnum.getColumnValueDefault(mapping.getStandardizationRule()) != null){
			DefaultValuesEnum defaultValue = DefaultValuesEnum.getColumnValueDefault(mapping.getStandardizationRule());
			expr.append(defaultValue.getValue());
		}else {					
			expr.append(StringUtils.replace(mapping.getStandardizationRule(), 
										COL_LITERAL, 
										mapping.getSrcColumnName()));
		}
		
		expr.append(AS_LITERAL).append(mapping.getTgtColumnName()).append(" ");
		
		return expr.toString();
	}
	
}
