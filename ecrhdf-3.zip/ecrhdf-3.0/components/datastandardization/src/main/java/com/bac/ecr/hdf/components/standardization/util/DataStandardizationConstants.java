package com.bac.ecr.hdf.components.standardization.util;

public class DataStandardizationConstants {

	public DataStandardizationConstants() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * STDZErrorCodes Enum lists all the possible exception messages for DataStandardization. Takes parameter and returns 
	 * appropriate error message to be logged in to hadoop logging framework . 
	 * 
	 */
	public enum STDZErrorCodes {
		
		STDZ_100("STDZ-100 : Config JSON file not found, Please review Config JSON Path"),
		STDZ_101("STDZ-101 : Mapping JSON file not found, Please review the Mapping JSON Path"),
		STDZ_102("STDZ-102 : Missing Input JSON files, Please check the arguments"),
		STDZ_103("STDZ-103 : Missing mandatory arguments, Please review the arguments list"),				
		STDZ_104("STDZ-104 : Configuration JSON file parsing failed. Please review Config file"),
		STDZ_105("STDZ-105 : Mapping JSON file parsing failed. Please review Mapping file"),
		STDZ_106("STDZ-106 : Config json is missing some mandatory fields. Please review config file"),
		STDZ_107("STDZ-107 : JSON Mapping does not match with Hive Schema. Please review JSON Mapping & Hive Schema"),
		STDZ_108("STDZ-108 : Given default value is not allowed."),
		STDZ_109("STDZ-109 : Error performing data Standardization. Please check the logs to resolve the error."),
		STDZ_110("STDZ-110 : Missing ENV property file not found, Please review ENV specific property file Path");
		
		private final String stdzErrorCode;
		
		private STDZErrorCodes(String stdzErrorCode) {
	        this.stdzErrorCode = stdzErrorCode;
	    }
	    
	    public String value() {
	    	return stdzErrorCode;
	    }
	}
	
}
