package com.bac.ecr.hdf.components.standardization.util;

public class DataStandardizationException extends Exception {

	public DataStandardizationException() {
		// TODO Auto-generated constructor stub
	}

	public DataStandardizationException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DataStandardizationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DataStandardizationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DataStandardizationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
