package com.bac.ecr.hdf.components.datastandardization.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.bac.ecr.hdf.components.standardization.service.DataStandardizationService;
import com.bac.ecr.hdf.components.standardization.util.DataStandardizationException;
import com.bac.ecr.hdf.components.standardization.util.DataStandardizationConstants.STDZErrorCodes;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.StandardizationMappingList;
import com.bac.ecr.hdf.components.utils.commonutils.JsonParseUtil;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger;



// Class to test Data Standardization service.

public class TestDataStandardizationService {

	StandardizationConfiguration config = new StandardizationConfiguration();
	StandardizationMappingList mappingList = new StandardizationMappingList();
	DataStandardizationService service;
	SparkConf sparkConfig;
	HadoopLogger hadoopLogger;
	private transient JavaSparkContext jsc;

	@Before
	public void setUp(){
		config.setSrcFeedDatabaseName("HOMELOANS_RAW");
		config.setSrcFeedName("SOR_337");
				
		config.setTgtFeedLocation("ALPIDE_STAGING_DEV1");
		config.setTgtFeedName("SOR_337_DS");
		
		config.setTgtFeedPartitioned(true);
		config.setTgtFeedPartitionedColumns("asofdate,sor");
		List<StandardizationMapping> list = new ArrayList<StandardizationMapping>();
		//StandardizationMapping mapping = new StandardizationMapping(aSrcColumnName, aSrcColumnType, aStandardizationRule, aTgtColumnName, aTgtColumnType)
		list.add(new StandardizationMapping("cccp_key","bigint","","cccp_key","bigint"));
		list.add(new StandardizationMapping("proc_yymm_dt","bigint","","proc_yymm_dt","bigint"));
		list.add(new StandardizationMapping("acc_appsys_id","bigint","trim(col)","acc_appsys_id","bigint"));
		list.add(new StandardizationMapping("accno","bigint","ltrim(col)","accno","string"));
		list.add(new StandardizationMapping("guartr_seq_no","bigint","rtrim(col)","guartr_seq_no","bigint"));
		list.add(new StandardizationMapping("guar_id","int","lpad(col)","guar_id","int"));
		list.add(new StandardizationMapping("guar_nm","bigint","rpad(col)","guar_nm","bigint"));
		list.add(new StandardizationMapping("guar_type_cd","bigint","substr(col,1,5)","guar_type_cd_mod","bigint"));
		list.add(new StandardizationMapping("guarantor_gci_typ","char","","guarantor_gci_typ","char"));
		list.add(new StandardizationMapping("guar_percent","bigint","","guar_percent","bigint"));
		list.add(new StandardizationMapping("guar_percent_2","bigint",null,"guar_percent_2","bigint"));
		System.out.println("New context");
		list.add(new StandardizationMapping("currency_code","bigint","date_format(col, format)","currency_code","bigint"));
		mappingList.setColStand(list);
		sparkConfig =  new SparkConf().setMaster("local").setAppName("Data Standardisation Test");
		System.out.println("creating new sparkcontext...");
		
		jsc = new JavaSparkContext(sparkConfig);
		
		service = new DataStandardizationService(config, mappingList, jsc,hadoopLogger);
		
	}
	@After
	public void tearDown(){
		jsc.stop();
		jsc = null;
	}

	
	
	@Test @Ignore
	public void testProcessFeed(){
		try{
			service.processFeed("");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//For this method you need the table to be already existing...
	//The run this query
	//see the output
	
	@Test @Ignore
	public void testPerformDataStandardization(){
		//Load a Data Frame
		//SQLContext sqlContext = new org.apache.spark.sql.SQLContext(jsc.sc());
		HiveContext sqlContext = new org.apache.spark.sql.hive.HiveContext(jsc.sc());
		//C:\\Users\\emaynard\\Desktop\\data.txt
		String filePath = "/test/resources/ds_simple/part-00001";
		DataFrame df = sqlContext.read().parquet(filePath) ;
		Assert.assertNotNull(df);
		df.show();
	}
	
	@Test
	public void testGetExpression(){
		List<StandardizationMapping> list = mappingList.getColStand();
		
		Assert.assertEquals("cccp_key AS cccp_key ",
				service.getExpression(list.get(0)));
		
		Assert.assertEquals("proc_yymm_dt AS proc_yymm_dt ",
				service.getExpression(list.get(1)));
		
		Assert.assertEquals("trim(acc_appsys_id) AS acc_appsys_id ",
				service.getExpression(list.get(2)));
		
		Assert.assertEquals("ltrim(accno) AS accno ",
				service.getExpression(list.get(3)));
		
		Assert.assertEquals("rtrim(guartr_seq_no) AS guartr_seq_no ",
				service.getExpression(list.get(4)));
		
		Assert.assertEquals("lpad(guar_id) AS guar_id ",
				service.getExpression(list.get(5)));

		
		Assert.assertEquals("substr(guar_type_cd,1,5) AS guar_type_cd_mod ",
				service.getExpression(list.get(7)));

		list.add(new StandardizationMapping("guar_percent_2_col","bigint","substr(col,1,5)","guar_percent_2_col","bigint"));
		
		Assert.assertEquals("substr(guar_percent_2_col,1,5) AS guar_percent_2_col ",
				service.getExpression(list.get(12)));
		
		
	}
	
	@Test
	public void testBuildSelectClause(){
		System.out.println("##" + service.buildSelectClause() + "##");
		System.out.println("##" + "cccp_key AS cccp_key ,proc_yymm_dt AS proc_yymm_dt ,trim(acc_appsys_id) AS acc_appsys_id ,ltrim(accno) AS accno ,rtrim(guartr_seq_no) AS guartr_seq_no ,lpad(guar_id) AS guar_id ,rpad(guar_nm) AS guar_nm ,substr(guar_type_cd,1,5) AS guar_type_cd_mod ,guarantor_gci_typ AS guarantor_gci_typ ,guar_percent AS guar_percent ,date_format(currency_code, format) AS currency_code " + "##");
		Assert.assertEquals("cccp_key AS cccp_key ,proc_yymm_dt AS proc_yymm_dt ,trim(acc_appsys_id) AS acc_appsys_id ,ltrim(accno) AS accno ,rtrim(guartr_seq_no) AS guartr_seq_no ,lpad(guar_id) AS guar_id ,rpad(guar_nm) AS guar_nm ,substr(guar_type_cd,1,5) AS guar_type_cd_mod ,guarantor_gci_typ AS guarantor_gci_typ ,guar_percent AS guar_percent ,guar_percent_2 AS guar_percent_2 ,date_format(currency_code, format) AS currency_code ",service.buildSelectClause());
	}
	
	@Test 
	public void testFormStandardizationQuery(){
		String query = service.buildStandardizationQuery("asofdate='2016-10-31'","sourceDF");
		System.out.println("##" + query + "##");
		System.out.println("##" + " SELECT cccp_key AS cccp_key ,proc_yymm_dt AS proc_yymm_dt ,trim(acc_appsys_id) AS acc_appsys_id ,ltrim(accno) AS accno ,rtrim(guartr_seq_no) AS guartr_seq_no ,lpad(guar_id) AS guar_id ,rpad(guar_nm) AS guar_nm ,substr(guar_type_cd,1,5) AS guar_type_cd_mod ,guarantor_gci_typ AS guarantor_gci_typ ,guar_percent AS guar_percent ,date_format(currency_code, format) AS currency_code  FROM sourceDF WHERE asofdate='2016-10-31'" + "##");
		Assert.assertEquals(" SELECT cccp_key AS cccp_key ,proc_yymm_dt AS proc_yymm_dt ,trim(acc_appsys_id) AS acc_appsys_id ,ltrim(accno) AS accno ,rtrim(guartr_seq_no) AS guartr_seq_no ,lpad(guar_id) AS guar_id ,rpad(guar_nm) AS guar_nm ,substr(guar_type_cd,1,5) AS guar_type_cd_mod ,guarantor_gci_typ AS guarantor_gci_typ ,guar_percent AS guar_percent ,guar_percent_2 AS guar_percent_2 ,date_format(currency_code, format) AS currency_code  FROM sourceDF WHERE asofdate='2016-10-31'"
							,query);
	}
	@Test
	public void testFormFromClause(){
		Assert.assertEquals(" FROM HOMELOANS_RAW.SOR_337 ".trim(), service.buildFromClause().trim());
	}
	@Test
	public void testbuildWhereClause(){
		
		Assert.assertEquals(" WHERE gla_no in ('15327','15343','12345')", 
				service.buildWhereClause("gla_no in ('15327','15343','12345')"));
		
		Assert.assertEquals("", 
				service.buildWhereClause(""));
		
		Assert.assertEquals("", 
				service.buildWhereClause(null));
	}
	
	@Test
	public void testDefaultValues() throws Exception {
		//Load the json and create mapping and config objects.
		String config = FileUtils.readFileToString(new File("src/test/resources/ds_default_test/hdpf_guart_partitioned_ds_dsconfig.json"));
		String mapping = FileUtils.readFileToString(new File("src/test/resources/ds_default_test/hdpf_guart_partitioned_ds_dsmapping.json"));
		String mappingForNullTest = FileUtils.readFileToString(new File("src/test/resources/ds_default_test/hdpf_guart_partitioned_ds_dsmapping_null.json"));
		
		StandardizationConfiguration standardizationConfig = (StandardizationConfiguration) JsonParseUtil.parseJSON(config, new StandardizationConfiguration());				
		StandardizationMappingList standardizationMappingLst = (StandardizationMappingList)JsonParseUtil.parseJSON(mapping,new StandardizationMappingList());
		StandardizationMappingList standardizationMappingLstForNull = (StandardizationMappingList)JsonParseUtil.parseJSON(mappingForNullTest,new StandardizationMappingList());
		
	DataStandardizationService service = new DataStandardizationService(standardizationConfig, standardizationMappingLst, jsc,hadoopLogger);
		String opQuery = "cccp_key AS cccp_key ,proc_yymm_dt AS proc_yymm_dt ,trim(acc_appsys_id) AS acc_appsys_id ,lpad(accno,21,'0') AS accno ,rtrim(guartr_seq_no) AS guartr_seq_no ,lpad(guar_id,12,'0') AS guar_id ,rpad(guar_nm) AS guar_nm ,substr(guar_type_cd,1,5) AS guar_type_cd ,guarantor_gci_typ AS guarantor_gci_typ ,guar_percent AS guar_percent ,currency_code AS currency_code ,guart_am AS guart_am ,ltrim(substr(guart_ccy_am,1,10)) AS guart_ccy_am ,date_format(guarte_exp_dt, 'EEEE') AS guarte_exp_dt ,cast(ext_guarantor_rating as DECIMAL(20,5)) AS ext_guarantor_rating ,' ' AS ext_guartr_rating_source ,0 AS intr_guarantor_rating ,Y AS affiliate_guarantee_flag ,guarantor_gci AS guarantor_gci ,guarantee_type_class AS guarantee_type_class ,guarantor_id_class AS guarantor_id_class ,substr(sor_client_no,1,5) AS sor_client_no ,privacy_cd AS privacy_cd ,last_update_timestamp AS last_update_timestamp ,cccp_key_ckdgt AS cccp_key_ckdgt ,asof_date AS asof_date ";
		Assert.assertEquals(opQuery,service.buildSelectClause());

	DataStandardizationService serviceForNull = new DataStandardizationService(standardizationConfig, standardizationMappingLstForNull, jsc,hadoopLogger);
		String opQueryForNull = "' ' AS ext_guartr_rating_source ,0 AS intr_guarantor_rating ,null AS privacy_cd ,cccp_key_ckdgt AS cccp_key_ckdgt ,asof_date AS asof_date ";
		System.out.println(serviceForNull.buildSelectClause());
		Assert.assertEquals(opQueryForNull,serviceForNull.buildSelectClause());

		
	}
}