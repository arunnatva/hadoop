package com.bac.ecr.hdf.components.standardization.driver;

import org.junit.Test;

public class TestDataStandardization {

	//Test Scenarios:
	
	//Call the DataStandardization with parametrs
	//Call with all the 3 parameters
	//Call with 2 parameters - Only config and mapping json	
	//call with no parameters - Should throw an exception
	//Call with more than 3 parameters - Should be accepteed

	
	@Test
	public void testMain(){
		
		String configJson = "src/test/resources/hdpf_guart_partitioned_ds_dsconfig.json";
		String mappingJson = "src/test/resources/hdpf_guart_partitioned_ds_dsmapping.json";
		String properties = "alpide_oozie_dev1.properties";
		String[] validInputs =  {configJson,mappingJson,properties};
		try{
			DataStandardization.main(validInputs);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
