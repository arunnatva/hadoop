package com.bac.ecr.hdf.components.standardization.util;



import org.junit.Assert;
import org.junit.Test;

public class TestDataStandardizationConstants {


	
}
