package com.bac.ecr.hdf.components.utils.commonbeans;


/**
 * @author ZKFYMQ6
 * This class is to maintain static constants across the application
 */
public class Constants {
	
	//constants for column presence status.
	public final static String COLUMNS_IN_SRC_FILE = "columnsInSrcFile";
	public final static String COLUMNS_NOT_IN_SRC_FILE = "columnsNotInSrcFile";
	public final static String COLUMNS_NOT_IN_PARTITION = "columnsNotInPartition";
	public final static String COLUMNS_IN_PARTITION = "columnsInPartition";
	
	//file type constants
	public static final String DELIMITED = "DELIMITED";
	public static final String FIXEDLENGTH = "FIXEDLENGTH";
	public static final String VARIABLELENGTH = "VARIABLELENGTH";
	public static final String DATABASE = "DATABASE";
	
	//DI check constants
	public static final String NULLCHECK = "NULL";
	public static final String DUPCHECK = "DUP";
	public static final String COUNTCHECK = "COUNT";
	public static final String SUMCHECK = "SUM";
	public static final String DICHECK_TEMPTABLE = "DICHECK";
	
	public static final String COMMA = ",";
	
	//validation constants
	public static final String SUCCESS_VALIDATIONS = "SUCCESS";
	public static final String FAILED_VALIDATIONS = "FAIL";
	
	public final static String DATE_TIME_FORMAT = "yyyy-MM-dd:HH-mm-ss";
	
	public static final String HEADER_DATE = "headerDate";
	
	//input json constants
	public final static String CONFIG_JSON = "configJSON";
	public final static String MAPPING_JSON = "mappingJSON";
	public final static String FILTER_CONDITION="filterCondition";
	
	public final static String ENVIRONMENT_PROPERTIES = "envProperties"; 
	
	public final static String VERSION = "version";
	
	public final static String PRINT_FORMATTER="*************************************";
	


/*
 * Enum for Database drivers
 * ORACLE = "oracle.jdbc.OracleDriver"
 * NETEZZA = "org.netezza.Driver"
 * TERADATA = "com.teradata.jdbc.TeraDriver"
 * DB2 = "com.ibm.db2.jcc.DB2Driver"
 * MSSQL = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
 * 
 * */

public enum DatabaseDriver {
	
	ORACLE("oracle.jdbc.OracleDriver"), NETEZZA("org.netezza.Driver"),TERADATA("com.teradata.jdbc.TeraDriver"),
	DB2("com.ibm.db2.jcc.DB2Driver"),MSSQL("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	
	private final String dbDriver;

    private DatabaseDriver(String dbDriver) {
        this.dbDriver = dbDriver;
    }
    
    public String value() {
    	return dbDriver;
    }
    
}



}