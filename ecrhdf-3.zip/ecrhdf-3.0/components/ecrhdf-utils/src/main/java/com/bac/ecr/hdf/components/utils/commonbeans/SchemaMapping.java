package com.bac.ecr.hdf.components.utils.commonbeans;



public class SchemaMapping {

	private String columnName;
	private String columnType;
	private String isPartitioned;
	private int partitionOrder;
	private boolean isInSourceFile;
	private String columnChecks;
	private int ordinal;
	
	public SchemaMapping(){}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}


	public String getIsPartitioned() {
		return isPartitioned;
	}


	public void setIsPartitioned(String isPartitioned) {
		this.isPartitioned = isPartitioned;
	}


	public int getPartitionOrder() {
		return partitionOrder;
	}


	public void setPartitionOrder(int partitionOrder) {
		this.partitionOrder = partitionOrder;
	}

	public boolean isInSourceFile() {
		return isInSourceFile;
	}

	public void setInSourceFile(boolean isInSourceFile) {
		this.isInSourceFile = isInSourceFile;
	}

	public String getColumnChecks() {
		return columnChecks;
	}


	public void setColumnChecks(String columnChecks) {
		this.columnChecks = columnChecks;
	}


	public int getOrdinal() {
		return ordinal;
	}


	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}



	
	
}
