package com.bac.ecr.hdf.components.utils.commonbeans;

import java.util.List;

public class SchemaMappingList {

	private List<SchemaMapping> columnMapping;

	public List<SchemaMapping> getColumnMapping() {
		return columnMapping;
	}

	public void setColumnMapping(List<SchemaMapping> columnMapping) {
		this.columnMapping = columnMapping;
	}
	
	
}
