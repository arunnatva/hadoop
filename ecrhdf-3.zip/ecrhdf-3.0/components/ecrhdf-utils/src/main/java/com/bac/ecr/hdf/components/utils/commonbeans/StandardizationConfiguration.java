package com.bac.ecr.hdf.components.utils.commonbeans;

import java.io.Serializable;

/**
 * @author zkpsz5o
 *
 */
public class StandardizationConfiguration implements Serializable {
	
	private String srcFeedDatabaseName;
	private String srcFeedName;
	private String srcFeedFormat;
	private String tgtFeedDatabaseName;
    private String tgtFeedName;
    private String tgtFeedLocation;
    private String tgtFeedFormat;
	private boolean isTgtFeedPartitioned;
	private String tgtFeedPartitionedColumns;


	
	
	public String getSrcFeedDatabaseName() {
		return srcFeedDatabaseName;
	}
	public void setSrcFeedDatabaseName(String srcFeedDatabaseName) {
		this.srcFeedDatabaseName = srcFeedDatabaseName;
	}
	public String getSrcFeedName() {
		return srcFeedName;
	}
	public void setSrcFeedName(String srcFeedName) {
		this.srcFeedName = srcFeedName;
	}
	public String getTgtFeedDatabaseName() {
		return tgtFeedDatabaseName;
	}
	public void setTgtFeedDatabaseName(String tgtFeedDatabaseName) {
		this.tgtFeedDatabaseName = tgtFeedDatabaseName;
	}
	public String getTgtFeedLocation() {
		return tgtFeedLocation;
	}
	public void setTgtFeedLocation(String tgtFeedLocation) {
		this.tgtFeedLocation = tgtFeedLocation;
	}
	public String getTgtFeedName() {
		return tgtFeedName;
	}
	public void setTgtFeedName(String tgtFeedName) {
		this.tgtFeedName = tgtFeedName;
	}
	public boolean isTgtFeedPartitioned() {
		return isTgtFeedPartitioned;
	}
	public void setTgtFeedPartitioned(boolean isTgtFeedPartitioned) {
		this.isTgtFeedPartitioned = isTgtFeedPartitioned;
	}
	public void setIsTgtFeedPartitioned(boolean isTgtFeedPartitioned) {
		this.isTgtFeedPartitioned = isTgtFeedPartitioned;
	}	
	public String getTgtFeedPartitionedColumns() {
		return tgtFeedPartitionedColumns;
	}
	public void setTgtFeedPartitionedColumns(String tgtFeedPartitionedColumns) {
		this.tgtFeedPartitionedColumns = tgtFeedPartitionedColumns;
	}
	public String getSrcFeedFormat() {
		return srcFeedFormat;
	}
	public void setSrcFeedFormat(String srcFeedFormat) {
		this.srcFeedFormat = srcFeedFormat;
	}
	public String getTgtFeedFormat() {
		return tgtFeedFormat;
	}
	public void setTgtFeedFormat(String tgtFeedFormat) {
		this.tgtFeedFormat = tgtFeedFormat;
	}
		
}
