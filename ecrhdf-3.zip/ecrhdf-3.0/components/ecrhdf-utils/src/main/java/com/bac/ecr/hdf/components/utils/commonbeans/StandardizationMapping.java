package com.bac.ecr.hdf.components.utils.commonbeans;

/**
 * @author zkpsz5o
 *
 */
public class StandardizationMapping {

	private String srcColumnName;
	private String srcColumnType;
	private String standardizationRule;
	private String tgtColumnName;
	private String tgtColumnType;
	
	public StandardizationMapping(){}

	public StandardizationMapping(String aSrcColumnName, 
								String aSrcColumnType, 
								String aStandardizationRule, 
								String aTgtColumnName, 
								String aTgtColumnType){
		
		srcColumnName = aSrcColumnName;
		srcColumnType = aSrcColumnType;
		standardizationRule = aStandardizationRule;
		tgtColumnName = aTgtColumnName;
		tgtColumnType = aTgtColumnType;
	}
	
	public String getSrcColumnName() {
		return srcColumnName;
	}

	public void setSrcColumnName(String srcColumnName) {
		this.srcColumnName = srcColumnName;
	}

	public String getSrcColumnType() {
		return srcColumnType;
	}

	public void setSrcColumnType(String srcColumnType) {
		this.srcColumnType = srcColumnType;
	}

	public String getStandardizationRule() {
		return standardizationRule;
	}

	public void setStandardizationRule(String standardizationRule) {
		this.standardizationRule = standardizationRule;
	}

	public String getTgtColumnName() {
		return tgtColumnName;
	}

	public void setTgtColumnName(String tgtColumnName) {
		this.tgtColumnName = tgtColumnName;
	}

	public String getTgtColumnType() {
		return tgtColumnType;
	}

	public void setTgtColumnType(String tgtColumnType) {
		this.tgtColumnType = tgtColumnType;
	}





	
	
}
