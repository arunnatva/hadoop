package com.bac.ecr.hdf.components.utils.commonbeans;

import java.util.List;



/**
 * @author zkpsz5o
 *
 */
public class StandardizationMappingList {

	private List<StandardizationMapping> colStand;

	public List<StandardizationMapping> getColStand() {
		return colStand;
	}

	public void setColStand(List<StandardizationMapping> colStand) {
		this.colStand = colStand;
	}


	
	
}