package com.bac.ecr.hdf.components.utils.commonutils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.bac.ecr.hdf.components.utils.commonbeans.Constants;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMappingList;

public class CommonUtils {

	final static Logger logger = Logger.getLogger(CommonUtils.class);

	/**
	 * getDateTimeAsString method returns date and time in UTC timezone.
	 * @param format
	 * @return String
	 */
	public static String getDateTimeAsString(String format) {
		final SimpleDateFormat f = new SimpleDateFormat(format);
		f.setTimeZone(TimeZone.getTimeZone("UTC"));
		return f.format(new Date());
	}

	
	/**
	 * getInputArgsMap method return input args in key value pairs as map.
	 * @param args
	 * @return Map<String, String>
	 */
	public static Map<String, String> getInputArgsMap(String[] args) throws Exception {
		Map<String, String> argsMap = new HashMap<String, String>();
		Arrays.stream(args)
				.forEach(
						arg -> {
							String[] keyVal = arg.split("=",2);
							if (keyVal.length == 2) {
								argsMap.put(keyVal[0].trim(), keyVal[1].trim());
							} else {
								logger.error("Usage: Please pass arguments as key=value format for : "
										+ arg);
								System.out
										.println("Usage: Please pass arguments as key=value format for : "
												+ arg);
								System.exit(1);
							}
						});
		return argsMap;
	}

	/**
	 * validateInputConfigParams method checks for mandatory config JSON input arguments.
	 * @param inputArgsMap
	 * @return boolean
	 */
	public static boolean validateInputConfigParams(
			Map<String, String> inputArgsMap) {
		if (inputArgsMap.size() < 2 || null == inputArgsMap.get(Constants.CONFIG_JSON)
				|| null == inputArgsMap.get(Constants.MAPPING_JSON)) {
			return false;
		}
		return true;
	}

	
	
	/**
	 * substituteDynamicValues() method accepts a string & a HashMap as arguments, and replaces the words that have this format ${###} with actual values from HashMap
	 * @param inputString
	 * @param inputArgsMap
	 * @return outputString
	 */
	public static String substituteDynamicValues(String inputString, Map<String,String> inputArgsMap) {
		String outputString = inputString;
		for (Map.Entry<String, String> entry : inputArgsMap.entrySet()) {
	        outputString = outputString.replace("${" + entry.getKey() + "}", entry.getValue());
	    }		
		return outputString;
	}
	
	
	
	
	/**
	 * getSrcInAndOutColumnMap method returns a map with arraylists for mapping columns present in source feed file 
	 * and the columns that are not in source file which needs to be taken from user provided input.
	 * @param schemaMapLst
	 * @return Map<String,List<String>>
	 */
	public static Map<String, List<String>> getSrcInAndOutColumnMap(
			SchemaMappingList schemaMapLst) {
		Map<String, List<String>> columnMap = new HashMap<String, List<String>>();
		List<String> columnsNotInSrcFileLst = new ArrayList<String>();
		List<String> columnsInSrcFileLst = new ArrayList<String>();
		schemaMapLst.getColumnMapping().forEach(schema -> {
			if (!schema.isInSourceFile()) {
				columnsNotInSrcFileLst.add(schema.getColumnName().trim());
			} else if (schema.isInSourceFile()) {
				columnsInSrcFileLst.add(schema.getColumnName().trim());
			}

		});

		columnMap.put(Constants.COLUMNS_NOT_IN_SRC_FILE, columnsNotInSrcFileLst);
		columnMap.put(Constants.COLUMNS_IN_SRC_FILE, columnsInSrcFileLst);
		return columnMap;
	}

	/**
	 * getPatitionsColumnsSchemaInOrder method returns a map of arrayList with columns that are in partitions and columns not in partitions.
	 * @param schemaMapLst
	 * @return Map<String,List<SchemaMapping>>
	 */
	public static Map<String, List<SchemaMapping>> getPatitionsColumnsSchemaInOrder(
			SchemaMappingList schemaMapLst) {
		Map<String, List<SchemaMapping>> columnsMap = new HashMap<String, List<SchemaMapping>>();
		List<SchemaMapping> columnsInPartitionLst = new ArrayList<SchemaMapping>();
		List<SchemaMapping> columnsNotInPartitionLst = new ArrayList<SchemaMapping>();
		schemaMapLst.getColumnMapping()
				.forEach(
						schema -> {
							if (StringUtils.isNotEmpty(schema
									.getIsPartitioned())
									&& ("Y".toUpperCase().equals(
											schema.getIsPartitioned()
													.toUpperCase()))) {
								columnsInPartitionLst.add(schema);
							} else {
								columnsNotInPartitionLst.add(schema);
							}
						});
		Collections.sort(columnsInPartitionLst,
				new Comparator<SchemaMapping>() {
					public int compare(SchemaMapping m1, SchemaMapping m2) {
						return m1.getPartitionOrder() - m2.getPartitionOrder();
					}
				});
		Collections.sort(columnsNotInPartitionLst,
				new Comparator<SchemaMapping>() {
					public int compare(SchemaMapping m1, SchemaMapping m2) {
						return m1.getPartitionOrder() - m2.getPartitionOrder();
					}
				});
		columnsMap.put(Constants.COLUMNS_IN_PARTITION, columnsInPartitionLst);
		columnsMap.put(Constants.COLUMNS_NOT_IN_PARTITION, columnsNotInPartitionLst);

		return columnsMap;
	}

	/**
	 * getColumnsNotInPartitions  method retuns columns not in partitions.
	 * @param notInPartitionsLst
	 * @return String[]
	 */
	public static String[] getColumnsNotInPartitions(
			List<SchemaMapping> notInPartitionsLst) {
		List<String> lst = new ArrayList<String>();

		notInPartitionsLst.forEach(schema -> {
			lst.add(schema.getColumnName().trim());
		});
		String[] notInPartitionsArr = new String[lst.size()];

		return lst.toArray(notInPartitionsArr);
	}

	
	/**
	 * getListValuesAsString method takes string list 
	 * and concatenates the list to single string seperated by new line character.
	 * @param List<String>
	 * @return String
	 */
	public static String getListValuesAsString(List<String> lst) {
		StringBuilder sb = new StringBuilder();
		lst.forEach(str -> sb.append(str).append("\n"));
		return sb.toString();
	}


	/**
	 * getVariableArgsToString method takes variable argument Strings and 
	 * concatenates the list to single string seperated by new line character.
	 * @param String...messages
	 * @return String
	 */
	public static String getVariableArgsToString(String...messages){
		StringBuilder sb = new StringBuilder();
		for (String message : messages) {
			sb.append(message).append("\n");
		}							
		return sb.toString();
	}
	
	/**
	 * getDecimalTypeAndScale method takes string value of DecimalType having precision and scale and return an array
	 * dataType and scale. 
	 * @param String
	 * @return String[]
	 */	
	public static String[] getDecimalTypeAndScale(String dataType) {
		   String[] precisionArr = new String[3];
		   precisionArr[0] = dataType.substring(0, dataType.indexOf("(")).trim();
		   String[] precisionScale = dataType.substring(dataType.indexOf("(") + 1, dataType.lastIndexOf(")")).split(",");
		   if (null != precisionScale && "".equals(precisionScale[0].trim())) {
			   precisionArr[1] = "999";
		   } else {
			   precisionArr[1] = precisionScale[0].trim();
		   }		   
		   if (null != precisionScale && precisionScale.length > 1) {
			   precisionArr[2] = precisionScale[1].trim();
		   } else {
			   precisionArr[2] = "0";
		   }		   
		   return precisionArr;
	}
	
	/**
	 * This method takes an expression that might contain expression language style 
	 * variables like ${variable} and substitutes the respective value from the 
	 * @param expression - Expresion that needs substituting variables
	 * @param properties - Properties that contains name value pairs
	 * @return String - Variables Substituted expression
	 * @throws IllegalStateException - If any of the variables are not provided in the properties file
	 */
    public static String substituteVariablesWithValues(String expression, Properties properties){    	
        String regex = "\\$\\{(\\w+)\\}";
        ArrayList<String> unFoundVariableNames = new ArrayList<>();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(expression);
        while (matcher.find()){
            String key = matcher.group(1);
            System.out.println(key);
            if (properties.containsKey(key)){            	
            	expression = expression.replace("${" + key + "}", substituteVariablesWithValues((String)properties.get(key), properties));
            }else{
            	unFoundVariableNames.add(key);
            }
        }
        if (unFoundVariableNames.size() > 0 )
        	throw new IllegalStateException("Variables are not not defined in the properties file : " + unFoundVariableNames.toString());
        
        return expression;
    }
	
	
	/**
	 * This method is to validate the Standardization Rule; if that is one of the default values.
	 * @param givenDefaultValueRule
	 * @return
	 */
	public static boolean isOneOfDefaultValueRules(String givenDefaultValueRule){
		
		if (StringUtils.isBlank(givenDefaultValueRule)) return true;
		
		if (! StringUtils.isBlank(givenDefaultValueRule) && 
				! givenDefaultValueRule.trim().startsWith(DefaultValuesEnum.valuesStartWith())){
			return true;
		}
				
		for (DefaultValuesEnum defaultValue : DefaultValuesEnum.values()){			
			if (givenDefaultValueRule.equalsIgnoreCase(defaultValue.getName()))
				return true;
		}
		return false;
	}
		
}
