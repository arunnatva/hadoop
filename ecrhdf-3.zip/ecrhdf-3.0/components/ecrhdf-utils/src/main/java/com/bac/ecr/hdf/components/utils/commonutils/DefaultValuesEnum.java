package com.bac.ecr.hdf.components.utils.commonutils;


public enum DefaultValuesEnum {

		DEFAULT_TO_SPACE("DEFAULT_TO_SPACE","' '"),
		DEFAULT_TO_ZERO("DEFAULT_TO_ZERO","0"),
		DEFAULT_TO_NULL("DEFAULT_TO_NULL","null");
		
		private final String name;
		private final String value;
		
		private DefaultValuesEnum(String aName, String aValue){
			name = aName;
			value = aValue;
		}

		public String getName() {
			return name;
		}

		public String getValue() {
			return value;
		}
		
		public static DefaultValuesEnum getColumnValueDefault(String aName){
			for (DefaultValuesEnum defaultValue : DefaultValuesEnum.values() ){
				if (defaultValue.getName().equalsIgnoreCase(aName))
					return defaultValue;
			}
			return null;
		}
		
		public static String valuesStartWith(){
			return "DEFAULT_TO_";
		}
		
		
	
	
}
