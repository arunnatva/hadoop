package com.bac.ecr.hdf.components.utils.commonutils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Properties;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.InvalidPathException;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

import com.bac.ecr.hdf.components.utils.commonbeans.Constants;



/**
 * @author ZKA6LJW (Rajesh Chamarthi)
 *
 */

public class HdfsUtils {

	final static Logger logger = Logger.getLogger(HdfsUtils.class);
	
	/**
	 * readHdfsFile reads a file from hdfs and returns the output as a string for JSON files 
	 * @param fs
	 * @param path
	 */
	public static String readHdfsFile(FileSystem fs, Path path) throws InvalidPathException,IOException {		
		BufferedReader br = null;
		String line = null;
		StringBuffer sb = new StringBuffer();
		try {
			if (fs.exists(path)) {
				if (fs.isFile(path)) {
					br = new BufferedReader(new InputStreamReader(fs.open(path)));
					while ((line=br.readLine()) != null ) {
						sb.append(line.trim());
					}
				} else {
					throw new InvalidPathException(path.toString(), " is a directory. Please provide full path");
				}
			} else {
				throw new InvalidPathException(path.toString(), " Invalid file path");
			}

		} catch(Exception  e) {
			throw e;
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch(Exception e) {
					throw e;
				}
			}
		}
		
		return sb.toString();
		
	}

	/**
	 * deleteDirFromHdfs deletes a file or directory from hdfs
	 * @param fs
	 * @param path
	 */
	public static boolean deleteDirFromHdfs(FileSystem fs, Path path) throws InvalidPathException,IOException {
		try {
						
			if (fs.exists(path)) {
				if (fs.isDirectory(path)) {				
					fs.delete(path, true);							
				} else
					throw new InvalidPathException(path.toString(), " is not a directory");
			}			 
		} catch(InvalidPathException | IOException  e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return true;
	}
	
	/**
	 * archiveFile copies a file or files in a directory from source hdfs path to target hdfs path
	 * @param fs
	 * @param srcLocation
	 * @param targetLocation
	 * @param conf
	 * @param deleteSource
	 * @return void
	 * 
	 */
	public static void archiveFile(FileSystem fs, String srcLocation, String  targetLocation, Configuration conf, boolean deleteSource) throws IOException {
		
		String[] dateTime =  CommonUtils.getDateTimeAsString(Constants.DATE_TIME_FORMAT).split(":");
		
		try {
			
			if (fs.isFile(new Path(srcLocation.trim()))) {
				String[] dirAndFile = getDirAndFile(srcLocation);
				String targetDir = getTimestampAppendedString(targetLocation, dirAndFile[1], dateTime);
				FileUtil.copy(fs, new Path(srcLocation.trim()), fs, new Path(targetDir.trim()), deleteSource, conf);
			} else if (fs.isDirectory(new Path(srcLocation.trim()))) {
				FileStatus[] fileStatus = fs.listStatus(new Path(srcLocation.trim()));
				for (FileStatus flSts: fileStatus) {
					if (flSts.isFile()) {
						String fileName = getFileNameFromPath(flSts.getPath().toString());
						String targetDir = getTimestampAppendedString(targetLocation, fileName, dateTime);
						FileUtil.copy(fs, new Path(srcLocation.trim()), fs, new Path(targetDir.trim()), deleteSource, conf);
					}
				}				
			}						
		} catch(IOException ie) {
			ie.printStackTrace();
			throw ie;
		}
	}
	
	/**
	 * getFileNameFromPath takes path as input and returns the file name
	 * @param filePath
	 * @return String
	 */
	public static String getFileNameFromPath(String filePath) {
		String[] dirAndFile = getDirAndFile(filePath);
		return dirAndFile[1];
	}
	
	/**
	 * getDirAndFile takes path as input and returns directory path and file name as an array
	 * @param filePath
	 * @return String[]
	 */
	public static String[] getDirAndFile(String filePath) {
		String[] dirAndFile = new String[2];
		dirAndFile[0] = filePath.substring(0, (filePath.lastIndexOf("/") + 1));
		dirAndFile[1] = filePath.substring(filePath.lastIndexOf("/") + 1);
		return dirAndFile;
	}
	
	/**
	 * getTimestampAppendedString takes file name from source and append the target path with date 
	 * time and file 
	 * @param targetDir
	 * @param fileName
	 * @param dateTime
	 * @return String
	 */
	public static String getTimestampAppendedString(String targetDir, String fileName, String[] dateTime) {
		StringBuilder sb = new StringBuilder();
		if (targetDir.endsWith("/")) {
			sb.append(targetDir.trim()).append(dateTime[0]).append("/").append(dateTime[1]).append("/").append(fileName.trim());			
		} else {
			sb.append(targetDir.trim()).append("/").append(dateTime[0]).append("/").append(dateTime[1]).append("/").append(fileName.trim());			
		}
		return sb.toString();
	}
	
	/**
	 * readProperties method loads the given property file
	 * @param fs
	 * @param path
	 * @return Properties
	 * @throws IOException 
	 */
	
	public static Properties readProperties(FileSystem fs,Path path) throws IOException {
        Properties properties = new Properties();
		FSDataInputStream inStream;
		try {
			inStream = fs.open(path);
			properties.load(inStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw e;
			
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
			throw e;
		}
		return properties;
	}
}
