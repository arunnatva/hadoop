package com.bac.ecr.hdf.components.utils.commonutils;

import java.io.EOFException;
import java.io.IOException;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;


public class HeaderTrailerOperationsUtil {

	final static Logger logger = Logger.getLogger(HeaderTrailerOperationsUtil.class);
    private final static int MAX_BUFFER=1000;
	
	
    
    
    /**
	 * extractHeader extracts the header string from RDD.
	 * @param inputData
	 * @param config
	 * @return String
	 */
	public static String extractHeader(JavaRDD<String> inputData,RawConfiguration config) {
		String header="";
		header = inputData.first();
		return header;
	}
	
	
	/**
	 * Extract trailer record from the input file by seeking to the last record of the file and ready each byte backwards until the \n character is encountered.
	 * Then convert the byte array to string and reverse the string.
	 * @param fs
	 * @param path
	 * @param maxRecordLength
	 * @return String
	 * @throws IOException
	 */
	public static String extractTrailerRecord(FileSystem fs, Path path) throws IOException {
		
		boolean newLineFound = false;
		int idx=0;
		byte[] byteBuffer = new byte[MAX_BUFFER];
		String stringValueOfBytes=null;
		FileStatus fstatus = fs.getFileStatus(path);
		long length = fstatus.getLen();
		long pos = length - 1;
		FSDataInputStream fdis = fs.open(path);
		fdis.seek(pos);
		byte fileByte;
		while (!newLineFound) {
			try {
				fileByte = fdis.readByte();
				fdis.seek(pos--);
				if ('\n' == (char)fileByte) {
					logger.info("new line character found");
					newLineFound = (idx > 0) ? true : false;
				} else if (' ' == (char)fileByte) {
					logger.info("space char found "+(char)fileByte);
					if(idx > 0) {
						byteBuffer[idx] = fileByte;
						idx++;
					} 
				} else {
					byteBuffer[idx] = fileByte;
					idx++;
				}

			}
			catch(EOFException eof) {
				logger.info("reached end of file");
			}
		}
		stringValueOfBytes = new String(byteBuffer,"UTF-8").trim();
		String trailerRecord = new StringBuilder().append(stringValueOfBytes).reverse().toString();
		logger.info("trailer rec : "+ trailerRecord+" trailer length:"+trailerRecord.length());
		return trailerRecord;
	}
	
	
	/**
	 * Remove Header and trailer records from an RDD and generate a new RDD
	 * @param config
	 * @param header
	 * @param trailer
	 * @return new RDD
	 */
	public static Function<String, Boolean> removeHDRTRL(RawConfiguration config, String header, String trailer) {
		 
		 Function<String, Boolean> removeHeaderAndTrailer = new Function<String, Boolean>() {
			 
			@Override
			public Boolean call(String dataFileRow) {
				Boolean isData;
				String trimmedRecord = dataFileRow.trim();
				if (trimmedRecord.equals(header) || trimmedRecord.equals(trailer) ) {
					isData = false;
				} else {
					isData = true;
				}
				return isData;		
			}
		};
		return removeHeaderAndTrailer;
	}
	
	
	
}
