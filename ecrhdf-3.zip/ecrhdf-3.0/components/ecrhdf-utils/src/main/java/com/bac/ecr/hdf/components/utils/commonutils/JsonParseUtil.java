package com.bac.ecr.hdf.components.utils.commonutils;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonParseUtil {

	
	/**
	 * parseJSON method parses JSON file to Java object.
	 * @param json
	 * @param jsonObj
	 * @return Object
	 * @throws Exception
	 */
	public  static Object parseJSON(String json, Object jsonObj) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		Object obj = null;
		try {
			obj = mapper.readValue(json, jsonObj.getClass());
		} catch (Exception e) {
			throw e;
		}
		
		return obj;
	}
	
}
