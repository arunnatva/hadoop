package com.bac.ecr.hdf.components.utils.commonutils;

import org.apache.log4j.Logger;

/**
 * SchemaComparisionUtil class is to add methods related to Table schema comparisons
 */

public class SchemaComparisonUtil {
	

	final static Logger logger = Logger.getLogger(SchemaComparisonUtil.class);
	
	

}
