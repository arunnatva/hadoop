package com.bac.ecr.hdf.components.utils.commonutils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.parquet.io.api.Binary;
import org.apache.spark.Accumulator;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.execution.QueryExecutionException;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.functions;

import parquet.io.ParquetEncodingException;
import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;
import com.bac.ecr.hdf.components.utils.commonbeans.SchemaMapping;



public class SchemaOperationsUtil {


	final static Logger logger = Logger.getLogger(SchemaOperationsUtil.class);


	/**
	 * convertSourceToDataFrame method applies schema to JavaRDD and converts it to Dataframe.
	 * @param sourceRDD    
	 * @param rawTableSchema
	 * @param config  			DataSourcing Configuration JSON file
	 * @param hiveContext
	 * @return DataFrame
	 */	
	public static DataFrame convertSourceToDataFrame(JavaRDD<String> sourceRDD, 
												StructType rawTableSchema,
												Broadcast<String[]> structFields,
												RawConfiguration config, 
												HiveContext hiveContext,
												Accumulator[] accumulatorArr) {
		
		JavaRDD<Row> rowRdd = sourceRDD
				.map(line -> line.split(config.getSrcFeedDelimiter(),-1))
				.map(row -> RowFactory.create(
						SchemaOperationsUtil.createSourceMappingRowObject(row, structFields, config, accumulatorArr)));
		rowRdd.toDebugString();
		return hiveContext.createDataFrame(rowRdd, rawTableSchema);
	}
	
	
	/**
	 * 
	 * @Description: This method accepts Hive Database Name, table name, Hive Context as arguments and returns a Schema instance
	 * @parameters : hive database name : String, hive table name : String, hive context : HiveContext
	 * @return : hive table schema : StructType
	 * @throws :QueryExecutionException, AnalysisException
	 */
	public static StructType getSchemaFromHive(String dbName, String hiveTable, HiveContext hiveContext) throws QueryExecutionException, AnalysisException{
		StructType targetSchema = null;
		StringBuilder dbSb = new StringBuilder();
		StringBuilder querySb = new StringBuilder();
		DataFrame targetDf = null;
		try{
			dbSb.append("USE ").append(dbName.trim());
			hiveContext.sql(dbSb.toString());

			querySb.append("SELECT * FROM ").append(hiveTable.trim()).append(" LIMIT 1");
			targetDf = hiveContext.sql(querySb.toString());
			targetSchema = targetDf.schema();

		}catch(Exception qe){
			logger.error(qe.getMessage());
			throw qe;
		}

		return targetSchema;

	}
	
	/**
	 * 
	 * @Description: This method accepts Hive DatabaseName.tablename, Hive Context as arguments and returns a Schema instance
	 * @parameters : hive database name : String, hive table name : String, hive context : HiveContext
	 * @return : hive table schema : StructType
	 * @throws :QueryExecutionException, AnalysisException
	 */
	public static StructType getSchemaFromHive(String hiveTable, HiveContext hiveContext) throws QueryExecutionException, AnalysisException{
		StructType targetSchema = null;
		try{
			 targetSchema = hiveContext.table(hiveTable).schema();
		}catch(Exception qe){
			logger.error(qe.getMessage());
			throw qe;
		}
		return targetSchema;

	}


	/**
	 * 
	 * @Description:This method returns a schema for an RDD from the Schema Mapping Object List.
	 * @parameters : jsonMapping : List<SchemaMapping>
	 * @return Schema for RDD : StructType
	 * @throws : None
	 */
	public static StructType getSchemaFromJsonMapping(List<SchemaMapping> jsonMapping) {
		StructType rddSchema = null;
		StringBuilder schemaStringSb = new StringBuilder();
		String columnName, columnType;
		//sorting the list of mappings based on the ordinal
		Collections.sort(jsonMapping,new Comparator<SchemaMapping>() {
			public int compare(SchemaMapping m1, SchemaMapping m2) {
				return m1.getOrdinal() - m2.getOrdinal();
			}
		});
		//traverse through the list and create a string that denotes the schema such as below.
		// "column1:datatyp1,column2:dataType2,column3:dataType3,column4:dataType1"
		
		List<StructField> fields = new ArrayList<StructField>();
		String[] precisionArr = null;
		for (SchemaMapping mapping: jsonMapping) {			
			columnName=mapping.getColumnName().trim();
			columnType=mapping.getColumnType().trim();
			if (-1 != columnType.trim().indexOf("(") ) {			
				precisionArr =  CommonUtils.getDecimalTypeAndScale(columnType.trim());
				columnType = precisionArr[0];
			}
			if(StringUtils.equalsIgnoreCase(columnType,"string")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.StringType, true));
			} else if(StringUtils.equalsIgnoreCase(columnType,"char") || StringUtils.equalsIgnoreCase(columnType,"varchar")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.StringType, true));
			} else if(StringUtils.equalsIgnoreCase(columnType,"int")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.IntegerType, true));
			} else if (StringUtils.equalsIgnoreCase(columnType,"short") || StringUtils.equalsIgnoreCase(columnType,"smallint")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.ShortType, true));
			} else if(StringUtils.equalsIgnoreCase(columnType,"byte") || StringUtils.equalsIgnoreCase(columnType,"tinyint")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.ByteType, true));
			}  else if(StringUtils.equalsIgnoreCase(columnType,"long") || StringUtils.containsIgnoreCase(columnType,"bigint")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.LongType, true));
			}  else if(StringUtils.equalsIgnoreCase(columnType,"decimal")) {
				if (null == precisionArr ||  (null != precisionArr && "999".equals(precisionArr[1]))) {
					fields.add(DataTypes.createStructField(columnName, DataTypes.createDecimalType(), true));
				} else {
					fields.add(DataTypes.createStructField(columnName, DataTypes.createDecimalType(Integer.parseInt(precisionArr[1]), Integer.parseInt(precisionArr[2])), true));
				}				
			}  else if(StringUtils.equalsIgnoreCase(columnType,"double")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.DoubleType, true));
			}   else if(StringUtils.equalsIgnoreCase(columnType,"float")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.FloatType, true));
			}   else if(StringUtils.equalsIgnoreCase(columnType,"date")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.DateType, true));
			}   else if(StringUtils.equalsIgnoreCase(columnType,"timestamp")) {
				fields.add(DataTypes.createStructField(columnName, DataTypes.TimestampType, true));
			}  
		}
		rddSchema = DataTypes.createStructType(fields);
		return rddSchema;
	}


	/**
	 * 
	 * @Description: This method checks each field in an input row against the data types mentioned in the schema, and
	 *               builds an array of objects after converting each string into corresponding data type.
	 * @parameters : row : Stirng[], schema: StructType
	 * @return : Array of Objects that are converted to data types according to schema
	 * @throws : None
	 */
	public static Object[] createSourceMappingRowObject(String[] rowColumns, 
														Broadcast<String[]> structFields, 
														RawConfiguration config,
														Accumulator[] accumulatorArr) throws Exception  {
		String[] structField =  structFields.value();
		Object[] fieldObjects = new Object[rowColumns.length];		
		if (rowColumns.length == structField.length) {
			for ( int i =0 ; i < structField.length;i++) {				
				String dataType = structField[i];
				String columnVal = rowColumns[i];
				String[] precisionArr = null;
				if (-1 != dataType.trim().indexOf("(") ) {			
					precisionArr =  CommonUtils.getDecimalTypeAndScale(dataType.trim());
					dataType = precisionArr[0];
				}
				try {
					switch (dataType.trim()) {
						case "StringType":
							fieldObjects[i] = columnVal;					
							break;
						case "IntegerType":
							fieldObjects[i] = Integer.parseInt(columnVal);                       
							break;
						case "LongType":
							fieldObjects[i] = Long.parseLong(columnVal);                          
							break;
						case "FloatType":
							fieldObjects[i] = Float.parseFloat(columnVal);                             
							break;
						case "DoubleType":
							fieldObjects[i] = Double.parseDouble(columnVal);                            
							break;
						case "ByteType":
							fieldObjects[i] = Byte.parseByte(columnVal);                        
							break;	
						case "DecimalType":
							if (null != precisionArr && precisionArr.length == 3 ) {
								fieldObjects[i] = new BigDecimal(columnVal).setScale(Integer.parseInt(precisionArr[2]));							
							} else {
								fieldObjects[i] = new BigDecimal(columnVal);							
							}                            
							break;
						case "BooleanType":	              
							if(!columnVal.toLowerCase().trim().equals("false") && !columnVal.toLowerCase().trim().equals("true"))
								fieldObjects[i] = null;
							else
								fieldObjects[i] = Boolean.parseBoolean(columnVal);						                       		                        
							break;
						case "ShortType":
							fieldObjects[i] = Short.parseShort(columnVal);                         
							break;
						case "TimestampType":
							fieldObjects[i] = Timestamp.valueOf(columnVal);                           
							break;
						case "BinaryType":
							fieldObjects[i] = Binary.fromString(columnVal);                            
							break;      
						default:
							throw new RuntimeException("Unsupported data type '" + dataType + "' for value '" + columnVal + "'.");
						}
				} catch(Exception e) {
					fieldObjects[i] = null;
					accumulatorArr[i].add(1);
				}
			}	
		} else {
			String exceptionMessage = String.format("Number of columns are not matching between source file record columns and mapping schema columns for source. "
					+ "Source file record columns %1$d. Schema mapping columns that are specified inSourceFile as true is %2$d", fieldObjects.length , structField.length);
			logger.error(exceptionMessage );
			logger.error(String.join(config.getSrcFeedDelimiter(),rowColumns));			
			throw new Exception(exceptionMessage);
		}				
		return fieldObjects;
	}


	/**
	 * 
	 * @Description:converts a given string into a object of a different a datatype passed as argument. The object is added to a list of objects
	 * @parameters : dataType:String, ColumnValue:String, fieldObjects:List<Object>
	 * @return : void
	 * @throws : None
	 */
	public static void getColumnDataTypeMapping(String dataType, String columnVal, List<Object> fieldObjects) {
		
		String[] precisionArr = null;
		if (-1 != dataType.trim().indexOf("(") ) {			
			precisionArr =  CommonUtils.getDecimalTypeAndScale(dataType.trim());
			dataType = precisionArr[0];
		} 
		switch (dataType.trim()) {
		case "StringType":
			fieldObjects.add(columnVal);
			break;
		case "IntegerType":
			try {
				fieldObjects.add(Integer.parseInt(columnVal));
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                        
			break;
		case "LongType":
			try {
				fieldObjects.add(Long.parseLong(columnVal));
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                          
			break;
		case "FloatType":
			try {
				fieldObjects.add(Float.parseFloat(columnVal));
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                             
			break;
		case "DoubleType":
			try {
				fieldObjects.add(Double.parseDouble(columnVal));
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                            
			break;
		case "ByteType":
			try {
				fieldObjects.add(Byte.parseByte(columnVal));
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                           
			break;

		case "DecimalType":
			try {
				if (null != precisionArr && precisionArr.length == 3 ) {
					fieldObjects.add(new BigDecimal(columnVal).setScale(Integer.parseInt(precisionArr[2])));
				} else {
					fieldObjects.add(new BigDecimal(columnVal));
				}				                        		
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                            
			break;
		case "BooleanType":	              
			if(!columnVal.toLowerCase().trim().equals("false") && !columnVal.toLowerCase().trim().equals("true"))
				fieldObjects.add(null);
			else
				fieldObjects.add(Boolean.parseBoolean(columnVal));                       		                         
			break;
		case "ShortType":
			try {
				fieldObjects.add(Short.parseShort(columnVal));                      		
			} catch (NumberFormatException ne) {
				fieldObjects.add(null);
			}                          
			break;
		case "TimestampType":
			try {
				fieldObjects.add(Timestamp.valueOf(columnVal));                     		
			} catch (IllegalArgumentException ie) {
				fieldObjects.add(null);
			}                           
			break;
		case "BinaryType":
			try {
				fieldObjects.add(Binary.fromString(columnVal));                     		
			} catch (ParquetEncodingException pe) {
				fieldObjects.add(null);
			}                            
			break;      
		default:
			throw new RuntimeException("Unsupported data type '" + dataType + "' for value '" + columnVal + "'.");
		}
	}
	
	
	
	
	/**
	 * getColumnDataTypeVal  method returns object after casting the string value to corresponding dataType.
	 * @param dataType
	 * @param columnVal
	 * @return Object
	 * @throws NumberFormatException
	 * @throws IllegalArgumentException
	 * @throws ParquetEncodingException
	 */
	public static Object getColumnDataTypeVal(String dataType, String columnVal)
			throws NumberFormatException, IllegalArgumentException,
			ParquetEncodingException {
		Object val = new Object();
		switch (dataType.trim()) {
		case "StringType":
			val = columnVal;
			break;
		case "IntegerType":
			val = Integer.parseInt(columnVal);
			break;
		case "LongType":
			val = Long.parseLong(columnVal);
			break;
		case "FloatType":
			val = Float.parseFloat(columnVal);
			break;
		case "DoubleType":
			val = Double.parseDouble(columnVal);
			break;
		case "ByteType":
			val = Byte.parseByte(columnVal);
			break;
		case "DecimalType":
			val = new BigDecimal(columnVal);
			break;
		case "BooleanType":
			val = Boolean.parseBoolean(columnVal);
			break;
		case "ShortType":
			val = Short.parseShort(columnVal);
			break;
		case "TimestampType":
			val = Timestamp.valueOf(columnVal);
			break;
		case "BinaryType":
			val = Binary.fromString(columnVal);
			break;
		default:
			throw new RuntimeException("Unsupported data type '" + dataType
					+ "' for value '" + columnVal + "'.");

		}
		return val;
	}

	
	/**
	 * 
	 * @Description: This method sorts Schema Mapping Objects per ordinal, filters the columns that are present in source file, 
	 *               and builds a schema that perfectly matches with the source file. 
	 * @parameters : rawTableSchema : StructType, schemaMappingList: List<SchemaMapping>
	 * @return : sourceFile Schema: StructType
	 * @throws : None
	 */
	public static StructType getSrcFileSchemaMapping(StructType rawTableSchema,List<SchemaMapping> schemaMappingList) {
		StructType srcFileStructType = null;
		List<StructField> fields = new ArrayList<StructField>();
		Collections.sort(schemaMappingList,new Comparator<SchemaMapping>() {
			public int compare(SchemaMapping m1, SchemaMapping m2) {
				return m1.getOrdinal() - m2.getOrdinal();
			}
		});	
		schemaMappingList.forEach(mapping -> { 
			if(mapping.isInSourceFile()) {
				fields.add(rawTableSchema.apply(mapping.getColumnName().toLowerCase().trim()));
			}
		});
		srcFileStructType = DataTypes.createStructType(fields);
		return srcFileStructType;
	}
	
	/**
	 * writeDFToNoPartitionTable method inserts the data frame to hive table with out partitions.
	 * @param InputDF
	 * @param hiveContext
	 * @param trgTable
	 * @param trgSchema
	 */
	public static void writeDFToNoPartitionTable(DataFrame InputDF, HiveContext hiveContext , String trgTable, StructType trgSchema) throws Exception {
		try {
			StringBuilder hiveQuerySB = new StringBuilder();
			hiveContext.registerDataFrameAsTable(InputDF, "trg_tbl");
			hiveQuerySB.append("insert overwrite table " + trgTable +" select ").append(String.join(",", trgSchema.fieldNames())).append(" from trg_tbl");
			logger.info("****************Insert SQL query: " + hiveQuerySB.toString());
			hiveContext.sql(hiveQuerySB.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			throw e;
		}
	}
	
    /**
    * createDataFrameFromTable method takes databaseName.tableName  and filterCondition to select the data from table
    * and returns DataFrame.
    * @param tableName
    * @param filterCondition
    * @param hiveCtx
    * @return DataFrame
    */
    public static DataFrame createDataFrameFromTable(String tableName, String filterCondition,HiveContext hiveContext) throws Exception {
          DataFrame inputFeedDF = null;
          StringBuilder sb = new StringBuilder();
          if (StringUtils.isNotEmpty(tableName)) {
                 sb.append("select * from " + tableName);                    
          }
          if (StringUtils.isNotEmpty(filterCondition)) {
                 sb.append(" where " + filterCondition);
          }
          String sql = sb.toString();
          logger.info("*********** Input feed Sql Query: " + sql);
          if (StringUtils.isNotEmpty(sql)) {
                 inputFeedDF = hiveContext.sql(sql);
          } else {
                 throw new Exception("Table Name should not be null or empty");
          }
          
          return inputFeedDF;        
    }

    
	/**
	 * addColumnToDF method add extra column to the existing DF with dynamic values.
	 * @param dataFrame
	 * @param colName
	 * @param value
	 * @param tableSchema
	 * @return DataFrame
	 */
	public static DataFrame addColumnToDF(DataFrame dataFrame, String colName, String value, StructType tableSchema) {
		DataFrame finalDF =  dataFrame;
		String dataType = tableSchema.apply(colName).dataType().toString();
		finalDF = finalDF.withColumn(colName, functions.lit(SchemaOperationsUtil.getColumnDataTypeVal(dataType,value)));
		return finalDF;
	}
    
	
	/**
	 * getColsNotInSrcLst method compares src and target schema and retuns column not present src schema.
	 * getStaticPartitionsLst
	 * @param targetTblSchema
	 * @param srcSchema
	 * @return
	 */
	public static List<String> getColsNotInSrcLst(StructType targetTblSchema, StructType srcSchema) {
		List<String> colsNotInSrcLst = new ArrayList<String>();
		List<String> trgtColumnNames = Arrays.asList(targetTblSchema.fieldNames());
		List<String> srcColumnNames = Arrays.asList(srcSchema.fieldNames());
		for (int i = 0; i < trgtColumnNames.size(); i++) {
			if (!srcColumnNames.contains(trgtColumnNames.get(i))) {
				colsNotInSrcLst.add(trgtColumnNames.get(i));
			}
		}		
		return colsNotInSrcLst;
	}
	
	/**
	 * getNonPartitionColsLst method returns columns that are not partitioned. 
	 * @param targetTblSchema
	 * @param srcSchema
	 * @return
	 */
	public static List<String> getNonPartitionColsLst(StructType targetTblSchema, List<String> partitionsLst) {
		List<String> NonPatitionColsLst = new ArrayList<String>();
		String[] trgtColumnNames = targetTblSchema.fieldNames();		
		for (int i = 0; i < trgtColumnNames.length; i++) {
			if (!partitionsLst.contains(trgtColumnNames[i])) {
				NonPatitionColsLst.add(trgtColumnNames[i]);
			}
		}		
		return NonPatitionColsLst;
	}
	
	/**
	 * writeDFToPartitionedTable method writes the data frame to hive table with partitions.
	 * @param partitoned_column
	 * @param trgSchema
	 * @param finalInputDF
	 * @param hiveContext
	 * @param trgTable
	 */
	public static void writeDFToPartitionedTable(String[] partitoned_column, String[] trgSchema,DataFrame finalInputDF, HiveContext hiveContext , String trgTable) {
		try {
			StringBuilder hiveQuerySB = new StringBuilder();
			hiveContext.registerDataFrameAsTable(finalInputDF, "trg_tbl");
			hiveQuerySB.append("insert overwrite table " + trgTable +" partition(")
								.append(String.join(",", partitoned_column)).append(") select ")
								.append(String.join(",", trgSchema)).append(",")
								.append(String.join(",", partitoned_column)).append(" from trg_tbl");
			logger.info("********* Inser Query : " + hiveQuerySB.toString());
			hiveContext.sql(hiveQuerySB.toString());			
		} catch (Exception e) {
			// TODO Auto-generated catch block			
			throw e;
		}
	}
}