package com.bac.ecr.hdf.components.utils.commonutils;


import org.apache.commons.lang3.Validate;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;

public class ValidationUtil {

	/**
	 * validateRawConfig method validate configuration JSON.
	 * @param config
	 */
	public static void validateRawConfig(RawConfiguration config) {
	
		
		Validate.notNull(config.getSrcFeedLocation(),"Source Feed location cannot be null");
		Validate.notNull(config.getSrcFeedType(),"Source Feed Type cannot be null");
		Validate.notNull(config.getSrcFileFormat(),"Source File format cannot be null");
		if (config.getSrcFileFormat().equalsIgnoreCase("delimited")) {
			Validate.notNull(config.getSrcFeedDelimiter(),"Source Feed Delimiter cannot be null");
		}		
		Validate.notNull(config.isHasHeader(),"hasHeader flag cannot be null");
		Validate.notNull(config.isHasTrailer(),"hasTrailer flag cannot be null");
		Validate.notNull(config.getTgtFeedLocation(),"Target Feed Location cant be null");
	}
	
}