package com.bac.ecr.hdf.components.utils.commonutils;



import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;

import com.bac.ecr.hdf.components.utils.commonbeans.RawConfiguration;

public class TestCommonUtils {

	@Test
	public void testGetVariableArgsToString(){
		StringBuffer value = new StringBuffer("A").append("\n").append("B").append("\n");
		String test = CommonUtils.getVariableArgsToString("A","B");
		Assert.assertEquals(value.toString(), test);
	}
	
	@Test(expected=IllegalStateException.class)
	public void testSubstitue() throws Exception {
		//Method to test the substitue method
		String testString = "respective vale ${alpide_staging_dataBase}";
		
		Properties props = new Properties();
		props.put("alpide_staging_dataBase", "ale_alpide_staging_dev2");
		
		Assert.assertEquals("respective vale ale_alpide_staging_dev2", 
				CommonUtils.substituteVariablesWithValues(testString, props));
		System.out.println(CommonUtils.substituteVariablesWithValues(testString, props));
		//Test if there are 2 values in the same line
		props.put("alpide_raw_db", "ale_alpide_raw_dev2");
		String testString2 = "respective vale ${alpide_staging_dataBase} and the raw db ${alpide_raw_db}";
		
		//Testing for scenarios if the variable is not available in the properties file
		Assert.assertEquals("respective vale ale_alpide_staging_dev2 and the raw db ale_alpide_raw_dev2", 
				CommonUtils.substituteVariablesWithValues(testString2, props));
		System.out.println(CommonUtils.substituteVariablesWithValues(testString2, props));
		String testString3 = "respective vale ${alpide_staging_dataBase} and the raw db ${alpide_raw_db}";
		Assert.assertEquals("respective vale ale_alpide_staging_dev2 and the raw db ale_alpide_raw_dev2", 
				CommonUtils.substituteVariablesWithValues(testString3, props));
		System.out.println(CommonUtils.substituteVariablesWithValues(testString3, props));
		//Test for recursive replacements
		props.put("alpide_raw_db", "ale_alpide_raw_dev2");
		props.put("nameNode", "hdfs://nameservice1");
		props.put("retail_root", "/haas/ale/ale_dev1/");
		props.put("retail_db_root", "/haas/ale/db/ale_dev1/");
		props.put("db_datafiles_base_dir", "${retail_db_root}datafiles/");
		props.put("hv_alpide_db_datafiles", "${db_datafiles_base_dir}${hv_alpide_db}/");
		props.put("hv_alpide_db", "ale_alpide_dev1");
		
		
		//Load a real Json file with multiple variable and test with a real properties file.
		String testString4 = "respective vale ${hv_alpide_db_datafiles} and the raw db ${alpide_raw_db}";
		Assert.assertEquals("respective vale /haas/ale/db/ale_dev1/datafiles/ale_alpide_dev1/ and the raw db ale_alpide_raw_dev2", 
						CommonUtils.substituteVariablesWithValues(testString4, props));
		//If there is not expression just return the value as is
		Assert.assertEquals("Test Value",CommonUtils.substituteVariablesWithValues("Test Value", props));	
		
		//Test with a Json file string
		//String properties = FileUtils.readFileToString(new File("src/test/resources/test_parameter_substitution/alpide_oozie_dev1.properties"));
		String configJson = FileUtils.readFileToString(new File("src/test/resources/test_parameter_substitution/config_with_variables.json"));
		
		InputStream is = FileUtils.openInputStream(new File("src/test/resources/test_parameter_substitution/alpide_oozie_dev1.properties"));
		//System.out.println(properties);
		Properties propsDev1 = new Properties();
		propsDev1.load(is); 		
		Assert.assertEquals(propsDev1.values().size(), 292);
		String configJsonParameterized = CommonUtils.substituteVariablesWithValues(configJson, propsDev1);
		

		
		//Make sure the configuration can be built from the parameterized json
		RawConfiguration rawConfig = (RawConfiguration) JsonParseUtil.parseJSON(configJsonParameterized, new RawConfiguration());
		Assert.assertNotNull("Raw config should not be null.",rawConfig);
		Assert.assertEquals("/haas/ale/db/ale_dev1//datafiles/ale_homeloans_dev1//data-sourcing", rawConfig.getSrcFeedLocation());
		//Test for recursive substitution
		System.out.println(rawConfig.getTgtFeedLocation());
		Assert.assertEquals("hdfs://nameService1//haas/ale/db/ale_dev1//ecr_core/ecr_core_guart/", rawConfig.getTgtFeedLocation());
		//tgtFeedLocation

		String propertiesAsString = FileUtils.readFileToString(new File("src/test/resources/test_parameter_substitution/alpide_oozie_dev1.properties"));
		Properties propsFromString = new Properties();
		propsFromString.load(new StringReader(propertiesAsString));
		Assert.assertEquals(propsFromString.values().size(), 292);
		String configJsonParameterizedfromString = CommonUtils.substituteVariablesWithValues(configJson, propsFromString);

		
		RawConfiguration rawConfigString = (RawConfiguration) JsonParseUtil.parseJSON(configJsonParameterizedfromString, new RawConfiguration());
		Assert.assertNotNull("Raw config should not be null.",rawConfigString);
		Assert.assertEquals("/haas/ale/db/ale_dev1//datafiles/ale_homeloans_dev1//data-sourcing", rawConfigString.getSrcFeedLocation());
		//Test for recursive substitution
		Assert.assertEquals("hdfs://nameService1//haas/ale/db/ale_dev1//ecr_core/ecr_core_guart/", rawConfigString.getTgtFeedLocation());
		System.out.println(rawConfigString.getTgtFeedLocation());
		//If there are 2 properties which one will be referred?
		Assert.assertEquals("table_name_second", rawConfigString.getSrcFeedName());
		
		
		Assert.assertEquals("Test Value",CommonUtils.substituteVariablesWithValues("Test Value ${not_available}", props));	
	}
	
	//Test providing a sample values
	//Test providing a where clause value
	@Test(expected=Exception.class)
	public void testGetInputArgsMap() throws Exception{
		
		String configJson = "configJson=configjson.json";
		String mappingJson = "mappingJson=mappingjson.json";
		String envProperties = "envProperties=envProperties.properties";
		String whereClauseArgs = "whereClauseArgs=acc_appsys_id='303'";
		String[] goodValues = {configJson,mappingJson,envProperties,whereClauseArgs};
		Map<String,String> op = CommonUtils.getInputArgsMap(goodValues);
		Assert.assertNotNull(op);
		Assert.assertEquals(op.get("configJson"),"configjson.json");
		Assert.assertEquals(op.get("mappingJson"),"mappingjson.json");
		Assert.assertEquals(op.get("envProperties"),"envProperties.properties");
		Assert.assertEquals(op.get("whereClauseArgs"),"acc_appsys_id='303'");
		
		//Make sure one of the requered parameters are null
		String[] missingConfigJson = {mappingJson,envProperties,whereClauseArgs};
		Map<String,String> opMissingConfigJson = CommonUtils.getInputArgsMap(missingConfigJson);
		Assert.assertNotNull(op);
		Assert.assertEquals(op.get("mappingJson"),"mappingjson.json");
		Assert.assertEquals(op.get("envProperties"),"envProperties.properties");
		Assert.assertEquals(op.get("whereClauseArgs"),"acc_appsys_id='303'");
		
		//Expecting exception
		String configJsonErrVal = "configjson.json";
		String[] configJsonErr = {configJsonErrVal,mappingJson,envProperties,whereClauseArgs};
		try{
			Map<String,String> opMissingConfigJsonErr = CommonUtils.getInputArgsMap(configJsonErr);
			System.out.println("Ging to gail");
			Assert.fail();
		}catch(Exception e){
			System.out.println("From exception");
			Assert.assertEquals("Usage: Please pass arguments as key=value format for : configjson.json", e.getMessage());
		}
	}
	
	
	@Test
	public void testaIsOneOfDefaultValueRules(){
		//Test Null
		//Empty value
		//Test incorrect value
		//test incorrect DEFAULT _TO Value
		//Test hive UDF
		//Test correct value
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules(null));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules(""));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules(" "));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules("lpad(col,21,0)"));
		Assert.assertEquals(false, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_SPACES"));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_SPACE"));
		Assert.assertEquals(false, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_ZEROES"));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_ZERO"));
		Assert.assertEquals(true, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_NULL"));
		Assert.assertEquals(false, CommonUtils.isOneOfDefaultValueRules("DEFAULT_TO_NULLS"));
	}
	
}
