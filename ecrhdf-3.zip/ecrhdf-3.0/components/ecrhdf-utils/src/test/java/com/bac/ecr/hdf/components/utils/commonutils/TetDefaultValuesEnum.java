package com.bac.ecr.hdf.components.utils.commonutils;

import org.junit.Assert;
import org.junit.Test;

public class TetDefaultValuesEnum {

	@Test
	public void testSTDColumnValueDefaults(){
		
		//Make sure the correct Default value is returned.
		Assert.assertEquals(DefaultValuesEnum.DEFAULT_TO_SPACE, 
				DefaultValuesEnum.getColumnValueDefault("DEFAULT_TO_SPACE"));
		
		Assert.assertEquals(DefaultValuesEnum.DEFAULT_TO_ZERO, 
				DefaultValuesEnum.getColumnValueDefault("DEFAULT_TO_ZERO"));

		Assert.assertEquals(DefaultValuesEnum.DEFAULT_TO_NULL, 
				DefaultValuesEnum.getColumnValueDefault("DEFAULT_TO_NULL"));

		
		Assert.assertEquals(null, 
				DefaultValuesEnum.getColumnValueDefault("DEFAULT_TO_ZES"));

		
	}
	
}
