/**
 *
============================== CHANGE LOG ===========================================================================================
DATE              WHO                  STORY#          DESCRIPTION OF CHANGE
----------  -------------------------  -------------  -------------------------------------------------------------------------------
2015-05-19  		ZK8M1AO           B-31396       Initial Version
======================================================================================================================================

 */

package com.bac.ecr.hdf.frameworks.logging;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.HADOOPLOGTYPE;

/**
 * Abstract Logger class to abstract out all the common functionalities of all the Logger
 * @author ZK8M1AO
 *
 */

public abstract class AbstractHadoopLogger implements HadoopLogger {
	

	private static final long serialVersionUID = -3501079186390214995L;

	private static final Logger log4jLogger = Logger.getLogger(AbstractHadoopLogger.class);
		
	private String name;
	private String stage;
	private String product;
	private boolean initialized;
	private Path dataFile;
	private String schemaPath;
	private String baseLogPath;
	private String application;
	private String controlPoint;
	private HADOOPLOGTYPE logLevel = HADOOPLOGTYPE.INFO;
	private Configuration conf;
	
	

	AbstractHadoopLogger(String aBaseLogPath,
						String anApplication,
						String aName, 
						String aProduct, 
						String aStage, 
						String aLogSchemaPath,
						String aLogLevel,
						String aControlPoint,
						Configuration aConf) throws IOException {
		name = aName;
		stage = aStage;
		product = aProduct;	
		schemaPath = aLogSchemaPath;
		baseLogPath = aBaseLogPath;
		application = anApplication;
		conf = aConf;
		dataFile = getUniquePath();
		controlPoint = aControlPoint;
		logLevel = HADOOPLOGTYPE.getLogLevelFromStringValue(aLogLevel, logLevel);
		log4jLogger.info(dataFile.getName());
		log4jLogger.info("Configuration obtained:" + aConf );
	}
	
	protected abstract void initialize() throws IOException;
	protected abstract String getLogFileExtension();
	protected abstract void buildDatumAndLog(String application,
											String product, 
											HADOOPLOGTYPE messageType, 
											String stage, 
											String subStage,
											String fileTableName,
											String sourceName,
											String controlPoint,
											String message);
	public abstract void close()  throws Exception;
	
	 Random rand = new Random();
	
	 public static int randInt(int min, int max) {

		    // NOTE: Usually this should be a field rather than a method
		    // variable so that it is not re-seeded every call.
		    Random rand = new Random();

		    // nextInt is normally exclusive of the top value,
		    // so add 1 to make it inclusive
		    int randomNum = rand.nextInt((max - min) + 1) + min;

		    return randomNum;
		}
	
	protected Path getUniquePath() throws IOException {
		StringBuilder parentFolder = new StringBuilder();
		parentFolder.append(getBaseLogPath())									
					.append("/layer=")
					.append(getStage())
					.append("/")
					.append("currdate=")
					.append(new SimpleDateFormat("yyyyMMdd").format(new Date()));
		
		String fileName = getName().replace(" ", "_");
		fileName = fileName + "_" + new Date().getTime()  + getLogFileExtension();
		
		Path avroPath = new Path(parentFolder.toString(), fileName);
		log4jLogger.info("AvroPath:" + avroPath);
		avroPath.getFileSystem(getConfig()).mkdirs(new Path(parentFolder.toString()));
		/*while(avroPath.getFileSystem(conf).exists(avroPath)){
			fileCounter++ ;
			fileName = name + "_" + fileCounter + AVRO_EXTN;
			avroPath = new Path(parent, fileName);
		}*/		
		return avroPath;		
	}
	
	/**
	 * Log method to Log the messages. Does lazy initialization for initializing the Log file.
	 * 
	 */
	
	@Override
	public void log(HADOOPLOGTYPE messageType, String subStage, String sourceName, String message) {
		log(messageType, subStage, sourceName, "", message);
		
	}
	

	@Override
	public void log(HADOOPLOGTYPE messageType, String subStage, 
					String sourceName, String tableNameorFileName, 
					String message) {
		//Lazy initialization to create the files only if there are any logs coming in.		
		if (! isInitialized()){
			try{				
				initialize();				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		if (messageType.getLevel() >= getLogLevel().getLevel() ){
			buildDatumAndLog(
							getApplication(),
							getProduct(),
							messageType,
							getStage(),
							subStage,
							tableNameorFileName,
							getName(),
							getControlPoint(),
							message);
		}
		
	}
	
	@Override
	public void debug(String subStage,String message) {
		log(HADOOPLOGTYPE.DEBUG,subStage,getName(),message);
	}
	
	@Override
	public void debug(String subStage, String tableNameorFileName, String message) {
		log(HADOOPLOGTYPE.DEBUG,subStage,getName(),tableNameorFileName,message);
	}
	

	@Override
	public void info(String subStage, String message){		
		log(HADOOPLOGTYPE.INFO,subStage,getName(),message);
	}
	
	@Override
	public void info(String subStage, String tableNameorFileName, String message){		
		log(HADOOPLOGTYPE.INFO,subStage,getName(),tableNameorFileName,message);
	}
	

	@Override
	public void warn(String subStage,String message){
		log(HADOOPLOGTYPE.WARN,subStage,getName(),message);
	}
	
	@Override
	public void warn(String subStage, String tableNameorFileName, String message){
		log(HADOOPLOGTYPE.WARN,subStage,getName(),tableNameorFileName,message);
	}
	
	
	@Override
	public void warn(String subStage,Throwable throwable){		
		log(HADOOPLOGTYPE.WARN,subStage,getName(), convertThrowableToString(throwable));
	}
	
	@Override
	public void warn(String subStage,String tableNameorFileName, Throwable throwable){		
		log(HADOOPLOGTYPE.WARN,subStage,getName(),tableNameorFileName, convertThrowableToString(throwable));
	}
	
	
	@Override
	public void exception(String subStage, String message, Throwable throwable){
		log(HADOOPLOGTYPE.EXCEPTION, subStage, "" ,message + convertThrowableToString(throwable));
	}
	
	@Override
	public void exception(String subStage, String tableNameorFileName, String message, Throwable throwable){
		log(HADOOPLOGTYPE.EXCEPTION, subStage, tableNameorFileName ,message + convertThrowableToString(throwable));
	}
	
	
	@Override
	public void exception(String subStage,String message)  {
		log(HADOOPLOGTYPE.EXCEPTION,subStage,getName(),message);
	}
	
	@Override
	public void exception(String subStage, String tableNameorFileName, String message)  {
		log(HADOOPLOGTYPE.EXCEPTION,subStage,getName(),tableNameorFileName,message);
	}
	
	@Override
	public void abend(String subStage, String message){
		log(HADOOPLOGTYPE.ABEND,subStage,getName(),message);
		System.exit(1);
	}
	
	@Override
	public void abend(String subStage, String tableNameorFileName, String message){
		log(HADOOPLOGTYPE.ABEND,subStage,getName(),tableNameorFileName,message);
		System.exit(1);
	}
	
	@Override
	public void event(String subStage, String tableNameorFileName, String message){
		log(HADOOPLOGTYPE.EVENT,subStage,getName(),tableNameorFileName,message);
	}
	

	public int getDefaultLogLevel() {return HADOOPLOGTYPE.INFO.getLevel();}
	public void setLogLevel(HADOOPLOGTYPE logLevel) {this.logLevel = logLevel;}
	public HADOOPLOGTYPE getLogLevel() {return logLevel;}
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public Path getFileName(){return dataFile;}
	public String getSchemaPath(){return schemaPath;}
	protected boolean isInitialized(){return initialized;}
	protected void markInitialized(){initialized = true;}
	protected synchronized void unInitialize(){initialized = false;}
	protected String getBaseLogPath(){return baseLogPath;}
	protected String getApplication(){return application;}
	protected String getProduct(){return product;}
	protected String getStage(){return stage;}
	protected String getControlPoint(){return controlPoint;}
	protected Configuration getConfig(){return conf;}
	
	
	
	@Override
	public boolean equals(Object obj){
		if (obj == null) return false;
		if (!(obj instanceof HDFSAvroLogger)) return false;
		if (obj == this) return true;
		AbstractHadoopLogger toCompare = (AbstractHadoopLogger) obj;
		
		return new EqualsBuilder()
					.append(this.getName(), toCompare.getName())
					.append(this.getProduct(), toCompare.getProduct())
					.append(this.getStage(), toCompare.getStage())
					.isEquals();		
	}
	
	@Override
	public int hashCode(){
		return new HashCodeBuilder()
						.append(getName())
						.append(getProduct())
						.append(getStage())
						.hashCode();		
	}
	
	/**
	 * Method to convert an Exception into a String format and to enable logging the same into the logger. 
	 * @param t
	 * @return
	 */
	protected String convertThrowableToString(Throwable thrown){
		if (thrown == null) return "";
		StringWriter stringWriter = new StringWriter();
		PrintWriter printWriter = new PrintWriter(stringWriter);
		thrown.printStackTrace(printWriter);
		printWriter.close();
		return stringWriter.toString();
	}


	
	
}
