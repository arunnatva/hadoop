/**
 *
============================== CHANGE LOG ===========================================================================================
DATE              WHO                  STORY#                      DESCRIPTION OF CHANGE
----------  -------------------------  -------------  -------------------------------------------------------------------------------
2015-05-19  	ZK8M1AO           		B-31396       				Initial Version
======================================================================================================================================

 */
package com.bac.ecr.hdf.frameworks.logging;

import org.apache.hadoop.fs.Path;

/**
 * This is a Dummy Logger that will only provide implementations for methods of HadoopLogger interface.
 * If there are any exceptions in obtaining the AlpideHadoopLogger then DummyHadoopLogger will be 
 * provided by the HadoopLogFactory. 
 * @author ZK8M1AO
 *
 */

public class DummyHadoopLogger implements HadoopLogger {

	private static final long serialVersionUID = 2618272581849172882L;

	@Override
	public void exception(String subStage,String message){}

	@Override
	public void debug(String subStage,String message){}

	@Override
	public void info(String subStage,String message){}

	@Override
	public void warn(String subStage,String message){}

	@Override
	public void log(HADOOPLOGTYPE messageType, String subStage,String sourceName, String message) {}

	
	@Override
	public Path getFileName() {
		throw new IllegalArgumentException("This is a Dummy implementation. The method is not supported.");
	}

	@Override
	public void warn(String subStage, Throwable message) {}

	@Override
	public String getName() {
		return "DummyLogger";
	}

	@Override
	public void exception(String subStage, String tableNameorFileName, String message) {}

	@Override
	public void debug(String subStage, String tableNameorFileName, String message) {}

	@Override
	public void info(String subStage, String tableNameorFileName, String message) {}

	@Override
	public void warn(String subStage, String tableNameorFileName, String message) {}

	@Override
	public void warn(String subStage, String tableNameorFileName, Throwable message) {}

	@Override
	public void exception(String subStage, String tableNameorFileName, Throwable message) {}

	@Override
	public void log(HADOOPLOGTYPE messageType, String subStage,
			String sourceName, String message, String tablenameorFileName) {
	}

	@Override
	public void abend(String subStage, String message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void abend(String subStage, String tableNameorFileName,String message) {
	}
	
	@Override
	public void event(String subStage, String tableNameorFileName,String message) {
		
	}

	@Override
	public void exception(String subStage, String tableNameorFileName,
			String message, Throwable throwable) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() throws Exception {}



}
