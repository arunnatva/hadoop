package com.bac.ecr.hdf.frameworks.logging;

public class HadoopLoggerHiveExceptionUDF extends HadoopLoggerHiveUDF {
	
	public String evaluate(String inputs[]) throws Exception {			
		return super.evaluate(HadoopLoggerHiveUDF.insertLogLevel(inputs, "EXCEPTION"));			
	}	
}
