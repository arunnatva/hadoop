package com.bac.ecr.hdf.frameworks.logging;

public class HadoopLoggerHiveInfoUDF extends HadoopLoggerHiveUDF {

	public String evaluate(String inputs[]) throws Exception {
		System.out.println("Evaluating in HadoopLoggerHiveInfoUDF");
		System.out.println("Input Size:" + inputs.length);
		return super.evaluate(HadoopLoggerHiveUDF.insertLogLevel(inputs, "INFO"));			
	}		
	
	public static void main(String[] str) throws Exception {
		
		HadoopLoggerHiveInfoUDF udf = new HadoopLoggerHiveInfoUDF();
		String[] strA = {"Class Name","Prod Name","DS","Substage", "Log Message"};
		udf.evaluate(strA);
	}
	
}
