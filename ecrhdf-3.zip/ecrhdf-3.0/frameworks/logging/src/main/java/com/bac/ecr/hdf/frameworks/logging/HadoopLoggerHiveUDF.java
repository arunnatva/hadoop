package com.bac.ecr.hdf.frameworks.logging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.hadoop.hive.ql.exec.UDF;
//import org.apache.hadoop.hive.ql.exec.UDFContext
import org.apache.hadoop.mapred.JobConf;
import org.apache.log4j.Logger;

import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.HADOOPLOGTYPE;

public class HadoopLoggerHiveUDF extends UDF {

	protected static final Logger log = Logger.getLogger(HadoopLoggerHiveUDF.class);
	public static List<LogMessage> processedMessages = new ArrayList<LogMessage>();
	
	protected String productName = "";
	protected String productType = "";
	protected String ddiLayer = "";
	protected String scriptName = "";
	protected String loggingType = "";
	protected String subStage = "";
	protected String tableNameOrFileName = "";
	protected String message = "";
	protected static HadoopLogger logger = null;
	
	
	public String evaluate(Object inputs[]) throws Exception {
		
		try{
			scriptName = (String) inputs[0];
			productType = (String) inputs[1];
			ddiLayer = (String) inputs[2];
			loggingType = (String) inputs[3];
			subStage = (String) inputs[4];
			message = (String) inputs[5];
			log("message:" + message);
			
			//Check for any Column values provided to be logged. Obtain all the values and log those along with the message.
			if (inputs.length == 7){
				log("Processing columns values");
					int i=6;
					//Probably a better way is to have expressions so that message can accomodate the values
					tableNameOrFileName = (String) inputs[i-1];
					message = (String) inputs[i];
			} else if (inputs.length == 8) {
					int i=7;
					tableNameOrFileName = (String) inputs[i-2];
					message = (String) inputs[i-1] +" "+inputs[i];
			}
			
			log("message:" + message);
			
		}catch(Error e){
			e.printStackTrace();
			throw e;
		}
		productName = productType;		
		log("productName:" + productName);
		try {			
			System.out.println("Total Values in Processed Message: " + processedMessages.size());
			LogMessage messageObj = new LogMessage(HADOOPLOGTYPE.INFO,					
										subStage, 
										scriptName, 
										tableNameOrFileName, 
										message);
			if (! processedMessages.contains(messageObj)){
				logger =  HadoopLogFactory.getInstance(scriptName, productName , HadoopLogger.DDI_LAYER.getDDILayer(ddiLayer), new JobConf());
				logger.log(HADOOPLOGTYPE.getLogLevelFromStringValue(loggingType,HADOOPLOGTYPE.INFO),					
							subStage, 
							scriptName, 
							tableNameOrFileName, 
							message);
				processedMessages.add(messageObj);
			}
				
		} catch( Exception e ) {			
			log.error(" Error in UDF HiveLoggingTest...:" + e.getMessage());
			throw e;
		} finally {
		if (logger != null) {
			logger.close();
		} 
		}
		return "LOGGED MESSAGE";	
		
    }

	
	public static Object[] insertLogLevel(String inputs[], String logLevel){		
		ArrayList<String> inputList = new ArrayList<String>(Arrays.asList(inputs));
		inputList.add(3, logLevel);		
		return inputList.toArray();
	}
	
	private static void log(String message){
		System.out.println(message);
	}
	    
}
