package com.bac.ecr.hdf.frameworks.logging;

public class HadoopLoggerHiveWarnUDF extends HadoopLoggerHiveUDF {

	public String evaluate(String inputs[]) throws Exception {			
		return super.evaluate(HadoopLoggerHiveUDF.insertLogLevel(inputs, "WARN"));			
	}		
	
}
