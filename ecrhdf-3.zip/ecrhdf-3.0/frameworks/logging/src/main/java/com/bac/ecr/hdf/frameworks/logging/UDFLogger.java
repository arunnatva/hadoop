package com.bac.ecr.hdf.frameworks.logging;

import java.io.IOException;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.util.UDFContext;

import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.DDI_LAYER;
import com.bac.ecr.hdf.frameworks.logging.HadoopLogger.HADOOPLOGTYPE;

public class UDFLogger extends EvalFunc<DataBag> {

	//UDF_LOGGER('339Transformation','retail_other','INFO','DI','BALANCE','/hdev1/er/etl/retail/retail_other','DI Check for retail Other 339 ');
	
	@Override
	public DataBag exec(Tuple input) throws IOException {
		
	    if (input == null || input.size() == 0) return null;
	    
		
		String product =  (String)input.get(0);
		String messageType =  (String)input.get(1);
		String ddiStage =  (String)input.get(2);
		String subStage =  (String)input.get(3);
		String sourceName =  (String)input.get(4);
		String tableOrFileName =  (String)input.get(5);
		String message =  (String)input.get(6);
		Long aggregateValue = (Long) input.get(7);
		
		message = message + "Aggregated Value: " + aggregateValue;  
		//System.out.println("Message: " + message + "Aggregate:" + aggregateValue);
		try(
				HadoopLogger logger = HadoopLogFactory.getInstance(sourceName, product, DDI_LAYER.getDDILayer(ddiStage),UDFContext.getUDFContext().getJobConf() );
			){
			//System.out.println("tableOrFileName:" + tableOrFileName);
			logger.log(HADOOPLOGTYPE.getLogLevelFromStringValue(messageType, HADOOPLOGTYPE.INFO), subStage, sourceName, tableOrFileName, message );
			  
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
}
