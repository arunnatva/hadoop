#!/bin/sh
#**************************************************************************
# Script Name: hadoopLogger_deploy.sh
# Description: This shell script will create following tables required for
#			   Hadoop Logging Framework
#				1. Hadoop Logger Hive Table
#				2. Dummy Table and Insert statements
#				3. Reporting table and Insert statements
#Parameters  : Scripts accepts a configuration file with following details
#				1. Hadoop Logger Database
#				2. Hadoop Logger Table Name
#				3 Hadoop Logger Reporting Table Name	
#**************************************************************************

env=$1
echo "env is $1"

#Read Parameters
export databaseName=`cat hadoopLoggerParameters.txt | grep "databaseName" | cut -d"=" -f2`
export hadoopLoggerTblName=`cat hadoopLoggerParameters.txt | grep "hadoopLoggerTblName" | cut -d"=" -f2`
export hadoopLoggerRptTblName=`cat hadoopLoggerParameters.txt | grep "hadoopLoggerRptTblName" | cut -d"=" -f2`
export hadoopLoggerDummyTblName=`cat hadoopLoggerParameters.txt | grep "hadoopLoggerDummyTblName" | cut -d"=" -f2`
export haoopLoggerHdfsPath=`cat hadoopLoggerParameters.txt | grep "haoopLoggerHdfsPath" | cut -d"=" -f2`
export hadoopLoggerRptHdfsPath=`cat hadoopLoggerParameters.txt | grep "hadoopLoggerRptHdfsPath" | cut -d"=" -f2`
export haoopLoggerDummyPath=`cat hadoopLoggerParameters.txt | grep "haoopLoggerDummyPath" | cut -d"=" -f2`
export haoopLoggerHdfsSchemaPath=`cat hadoopLoggerParameters.txt | grep "haoopLoggerHdfsSchemaPath" | cut -d"=" -f2`
export pigMacroPath=`cat hadoopLoggerParameters.txt | grep "pigMacroPath" | cut -d"=" -f2`
export hdfsLibPath=`cat hadoopLoggerParameters.txt | grep "hdfsLibPath" | cut -d"=" -f2`
export hdfs_dir=hdfs://nameservice1/

rm hadooplog4j.properties
cat hadooplog4j_${env}.properties >> hadooplog4j.properties

#copy Schema File
hadoop fs -mkdir -p ${haoopLoggerHdfsSchemaPath}/
hadoop fs -mkdir -p ${haoopLoggerDummyPath}/
hadoop fs -mkdir -p ${hdfsLibPath}
hadoop fs -chmod 770 ${haoopLoggerHdfsPath}/*
hadoop fs -rm ${haoopLoggerHdfsSchemaPath}/hadooplog4j.avsc
hadoop fs -rm ${hdfsLibPath}/hadooplog4j.properties
hadoop fs -rm ${hdfsLibPath}/HADOOP_LOGGER-*-SNAPSHOT.jar
hadoop fs -rm ${pigMacroPath}/pig-logger-macro.pig
hadoop fs -rm ${haoopLoggerDummyPath}/hadoop_logger_dummy.txt
hadoop fs -put hadooplog4j.avsc ${haoopLoggerHdfsSchemaPath}/hadooplog4j.avsc
hadoop fs -put hadooplog4j.properties ${hdfsLibPath}/hadooplog4j.properties
hadoop fs -put hadoop_logger_dummy.txt ${haoopLoggerDummyPath}/
hadoop fs -put ../../HADOOP_LOGGER-*-SNAPSHOT.jar ${hdfsLibPath}/

#Create Hadoop Logger Table
hive -f scripts/create_hadoop_logger.hive --hiveconf schema=${databaseName} --hiveconf tblname=${hadoopLoggerTblName} --hiveconf hdfs_path=${haoopLoggerHdfsPath} --hiveconf nameNode=${hdfs_dir} --hiveconf haoopLoggerHdfsSchemaPath=${haoopLoggerHdfsSchemaPath}

#create Hadoop Logger Reporting table
hive -f scripts/create_hadoop_logger_rpt.hive --hiveconf schema=${databaseName} --hiveconf tblname=${hadoopLoggerRptTblName} --hiveconf hdfs_path=${hadoopLoggerRptHdfsPath} --hiveconf nameNode=${hdfs_dir}

#Create Hadoop Logger Dummy Table and Insert Dummy Record
hive -f scripts/create_hadoop_logger_dummy.hive --hiveconf schema=${databaseName} --hiveconf tblname=${hadoopLoggerDummyTblName} --hiveconf hdfs_path=${haoopLoggerDummyPath} --hiveconf nameNode=${hdfs_dir}

#Place Pig Macro in hadoop path
hadoop fs -put scripts/pig-logger-macro.pig ${pigMacroPath}