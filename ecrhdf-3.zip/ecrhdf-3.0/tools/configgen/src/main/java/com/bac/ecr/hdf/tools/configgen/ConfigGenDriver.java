package com.bac.ecr.hdf.tools.configgen;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;

import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;
import com.bac.ecr.hdf.tools.configgen.beans.DataMappingList;
import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;
import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.ExcelDocs;
import com.bac.ecr.hdf.tools.configgen.util.CommonUtils;
import com.bac.ecr.hdf.tools.configgen.util.GenerateHiveDdlUtil;
import com.bac.ecr.hdf.tools.configgen.util.GenerateJsonFileUtil;
import com.bac.ecr.hdf.tools.configgen.util.GenerateWorkBooksUtil;
import com.bac.ecr.hdf.tools.configgen.util.ValidationUtil;

/**
 * This class is the driver for Code Generation functionality. 
 * @author ZKZB9LR
 *
 */
public class ConfigGenDriver {
	private final static Logger logger = Logger.getLogger(ConfigGenDriver.class);
	
	public static void main(String[] args) {
		
		String CONFIG_JSON_FILENAME_FORMAT = "%s_config.json";
		String DATAMAPPING_JSON_FILENAME_FORMAT = "%s_dataMapping.json";
		String HIVE_DDL_FILENAME_FORMAT = "%s_hiveDDL.hql";		
		
		File outfileObj = null;		
		
		try {
			init(args);

			String mappingDocFilePath = args[0];
			Workbook mappingWb = GenerateWorkBooksUtil
					.getWorkbook(mappingDocFilePath);

			DataSourcingConfiguration sourceConfig = CommonUtils
					.getConfigObjectFromExcel(mappingWb);
			ValidationUtil.validateConfig(sourceConfig);

			Map<String, Object> dataMapObjMap = CommonUtils
					.getDataMappingInfoFromExcel(mappingWb);

			DataMappingList dataMapObj = (DataMappingList) dataMapObjMap
					.get("dataMappingObject");
			String[] columnCheckConfigInfo = (String[]) dataMapObjMap
					.get("columnCheckStr");
			List<DataMapping> dmList = dataMapObj.getColumnMapping();
			ValidationUtil.validateFields(dmList);

			// Hive DDL creation
			GenerateHiveDdlUtil hiveDdlUtil = new GenerateHiveDdlUtil();
			Map<String, String> hiveDdlInfoMap = hiveDdlUtil.getHiveDdlInfo(
					dmList, sourceConfig);

			String hiveDdl = hiveDdlInfoMap.get("hiveDdl");
			String hasTablePartitions = hiveDdlInfoMap
					.get("hasTablePartitions");
			String tgtPartitionColumns = hiveDdlInfoMap
					.get("tgtPartitionColumns");

			outfileObj = new File(String.format(HIVE_DDL_FILENAME_FORMAT,
					sourceConfig.getTgtHiveTableName()));

			CommonUtils.writeToFile(hiveDdl, outfileObj);

			// Mapping JSON creation
			outfileObj = new File(String.format(
					DATAMAPPING_JSON_FILENAME_FORMAT,
					sourceConfig.getTgtHiveTableName()));

			GenerateJsonFileUtil.writeObjectToFile(dataMapObj, outfileObj);

			// Config JSON creation
			sourceConfig.setColumnCheckConfig(columnCheckConfigInfo);
			sourceConfig
					.setHasTablePartitions("Y".equals(hasTablePartitions) ? true
							: false);
			sourceConfig.setTgtPartitionColumns(tgtPartitionColumns);

			outfileObj = new File(String.format(CONFIG_JSON_FILENAME_FORMAT,
					sourceConfig.getTgtHiveTableName()));

			GenerateJsonFileUtil.writeObjectToFile(sourceConfig, outfileObj);

		} catch (Exception e) {
			logger.error(ExceptionUtils.getStackTrace(e));
		} 

		close();

	}

	public static void init(String[] args) throws Exception {

		logger.info("Starting: ConfigGen Driver beginning");
		if (args.length != 1) {
			throw new Exception(
					"Usage: Insufficient arguments. Please pass the mapping document file path as an argument");
		}
	}

	public static void close() {
		logger.info("Exiting: ConfigGen Driver completed execution");
	}

}
