package com.bac.ecr.hdf.tools.configgen.beans;

import org.apache.commons.lang3.StringUtils;

public class ConfigGenConstants {

	public enum InputDocs {
		
		DATAMAPPING("DataMapping"), CONFIGURATION("Config"), SQOOP("sqoop-properties");
		
		private final String inputDoc;

	    private InputDocs(String inputDoc) {
	        this.inputDoc = inputDoc;
	    }
	    
	    public String value() {
	    	return inputDoc;
	    }
	    
	}
	
	public enum Functions {
		GETDDL("getDDL"), GETCONFIG("getConfig"), GETMAPPING("getMapping");
		
		private final String functionType;

	    private Functions(String functionType) {
	        this.functionType = functionType;
	    }
	    
	    public String value() {
	    	return functionType;
	    }

	}

	public enum ExcelDocs {
		
		CONFIG_XLS("ConfigXLSPath"), MAPPING_XLS("MappingXLSPath");
		
		private final String excelPath;

	    private ExcelDocs(String excelPath) {
	        this.excelPath = excelPath;
	    }
	    
	    public String value() {
	    	return excelPath;
	    }

	}
	
	public enum ExcelTypes {
		
		XLS_EXTN("xls"), XLSX_EXTN("xlsx");
		
		private final String excelType;

	    private ExcelTypes(String excelType) {
	        this.excelType = excelType;
	    }
	    
	    public String value() {
	    	return excelType;
	    }

	}
	
	public enum HiveDataType {
		
		TINYINT("tinyint"),SMALLINT("smallint"),INT("int"),BIGINT("bigint"),FLOAT("float"),
		DOUBLE("double"),DECIMAL("decimal"),STRING("string"),VARCHAR("varchar"),CHAR("char"),
		DATE("date"),TIMESTAMP("timestamp");
		
		private final String hiveType;
		
		private HiveDataType(String hiveType) {
			this.hiveType = hiveType;
		}
		
		public String value() {
			return hiveType;
		}
		
		public static boolean isValidHiveType(String dataType) {
			
			StringBuilder varcharRegex = new StringBuilder("(?i)");
			varcharRegex.append(VARCHAR.value()).append(
					"[ \t]*\\([ \t]*\\d+[ \t]*\\)");

			StringBuilder charRegex = new StringBuilder("(?i)");
			charRegex.append(CHAR.value()).append(
					"[ \t]*\\([ \t]*\\d+[ \t]*\\)");

			StringBuilder decimalRegex = new StringBuilder("(?i)");
			decimalRegex.append(DECIMAL.value()).append(
					"[ \t]*\\([ \t]*\\d+[ \t]*,[ \t]*\\d+[ \t]*\\)");

			if (TINYINT.value().equalsIgnoreCase(dataType.trim())
					|| SMALLINT.value().equalsIgnoreCase(dataType.trim())
					|| INT.value().equalsIgnoreCase(dataType.trim())
					|| BIGINT.value().equalsIgnoreCase(dataType.trim())
					|| FLOAT.value().equalsIgnoreCase(dataType.trim())
					|| DOUBLE.value().equalsIgnoreCase(dataType.trim())
					|| STRING.value().equalsIgnoreCase(dataType.trim())
					|| DATE.value().equalsIgnoreCase(dataType.trim())
					|| TIMESTAMP.value().equalsIgnoreCase(dataType.trim())
					|| dataType.matches(varcharRegex.toString())
					|| dataType.matches(charRegex.toString())
					|| dataType.matches(decimalRegex.toString())) {
				return true;
			} else {
				return false;
			}
	  }
	}
	
	public enum FeedPlatforms {
		
		HIVE("hive"), NETEZZA("netezza"),TERADATA("teradata"),MSSQL("mssql"),ORACLE("oracle"),DB2("db2"),HDFS("hdfs");
		
		private final String platform;

	    private FeedPlatforms(String platform) {
	        this.platform = platform;
	    }
	  
	    public String value() {
	    	return platform;
	    }
	    
	    public static boolean isValidPlatform(String feedPlatform) {
			boolean result = false;
			for (FeedPlatforms fp : FeedPlatforms.values()) {
				if (feedPlatform.equals(fp.value())) {
					result = true;
				}
			}
	    	return result;	
	    }
	    
	    public static String listAll() {
	    
	    	StringBuilder all = new StringBuilder();
	    	for (FeedPlatforms fp : FeedPlatforms.values()){
	    		all.append(fp.value())
	    		   .append(",");
	    	}
	    	return all.toString();
	    }

	}
	
}
