package com.bac.ecr.hdf.tools.configgen.beans;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

public class DataMapping {

	private String columnName;
	private String columnType;
	private String isPartitioned;
	private int partitionOrder;
	private boolean isInSourceFile;
	
	private int ordinal;

	public DataMapping() {
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	public String getIsPartitioned() {
		return isPartitioned;
	}

	public void setIsPartitioned(String isPartitioned) {
		this.isPartitioned = isPartitioned;
	}

	public int getPartitionOrder() {
		return partitionOrder;
	}

	public void setPartitionOrder(int partitionOrder) {

		this.partitionOrder = partitionOrder;
	}

	public boolean isInSourceFile() {
		return isInSourceFile;
	}

	public void setInSourceFile(boolean isInSourceFile) {
		this.isInSourceFile = isInSourceFile;
	}


	public int getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public static DataMapping createInstance(Row row) {
		DataMapping dataMapping = new DataMapping();

		if (row.getCell(0) != null) {
			dataMapping.columnName = row.getCell(0).toString().trim();
		}
		if (row.getCell(1) != null) {
			dataMapping.columnType = row.getCell(1).toString().trim();
		}

		
		if (row.getCell(2) != null) {
			String isPartitionedCellValue = row.getCell(2).toString()
					.toUpperCase();

			dataMapping.isPartitioned = isPartitionedCellValue;
		} else {
			dataMapping.isPartitioned = "N";
		}

		if (row.getCell(3) != null) {
			String partitionOrderCellValue = new DataFormatter()
					.formatCellValue(row.getCell(3)).trim();
			dataMapping.partitionOrder = Integer
					.parseInt(partitionOrderCellValue.isEmpty() ? "0"
							: partitionOrderCellValue);
		}
		if (row.getCell(4) != null) {
			if (row.getCell(4).toString().equalsIgnoreCase("N")) {
				dataMapping.isInSourceFile = false;
			} else {
				dataMapping.isInSourceFile = true;
			}

		} else {
			dataMapping.isInSourceFile = true;
		}

		if (row.getCell(0) != null) {
			dataMapping.ordinal = (int) row.getCell(0).getRowIndex();
		}
		return dataMapping;
	}

}
