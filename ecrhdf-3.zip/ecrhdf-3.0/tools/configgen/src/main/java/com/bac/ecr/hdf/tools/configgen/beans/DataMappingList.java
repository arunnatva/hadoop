package com.bac.ecr.hdf.tools.configgen.beans;

import java.util.List;

import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;

/**
 * This class holds the List of DataMappings   
 * @author ZKU2KWB
 *
 */

public class DataMappingList {

		private List<DataMapping> columnMapping;
		
		public List<DataMapping> getColumnMapping() {
			return columnMapping;
		}

		public void setColumnMapping(List<DataMapping> columnMapping) {
			this.columnMapping = columnMapping;
		}
	
}
