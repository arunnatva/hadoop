package com.bac.ecr.hdf.tools.configgen.beans;


import java.io.Serializable;

/**
 * @author ZKZB9LR
 *
 */
public class DataSourcingConfiguration implements Serializable {
	
	private String srcFeedLocation;
	private String srcDataBaseName;
	private String srcFeedType;
	private String srcFileFormat;
	private String srcFeedDelimiter;
	private String headerDelimiter;
	private String trailerDelimiter;
	private String srcFeedName;
	private String srcFeedPlatform;
	private String tgtFeedPlatform;
	private boolean hasHeader;
	private boolean hasTrailer;
	private String tgtFeedLocation;
	private String tgtHiveDatabaseName;
	private String tgtHiveTableName;
	private boolean hasTablePartitions;
	private String tgtPartitionColumns;
	private boolean validateHeader;
	private boolean validateTrailer;
	private int headerDateIndex;
	private String[] trailerCheckConfig;
	private boolean validateColumnChecks;
	private String[] columnCheckConfig;
	private boolean trailerCountHasHdrTrlr;
	private boolean archiveFile;
	private String archiveDirLocation;
	private String dbConnectString;
	private String dbUser;
	private String credPath;
	private String passwordAliasName;
		
	
	public String getSrcFeedLocation() {
		return srcFeedLocation;
	}
	public void setSrcFeedLocation(String srcFeedLocation) {
		this.srcFeedLocation = srcFeedLocation;
	}
	public String getSrcFeedType() {
		return srcFeedType;
	}
	public void setSrcFeedType(String srcFeedType) {
		this.srcFeedType = srcFeedType;
	}
	public String getSrcFileFormat() {
		return srcFileFormat;
	}
	public void setSrcFileFormat(String srcFileFormat) {
		this.srcFileFormat = srcFileFormat;
	}
	public String getSrcFeedDelimiter() {
		return srcFeedDelimiter;
	}
	public void setSrcFeedDelimiter(String srcFeedDelimiter) {
		this.srcFeedDelimiter = srcFeedDelimiter;
	}
	public String getSrcFeedName() {
		return srcFeedName;
	}
	public void setSrcFeedName(String srcFeedName) {
		this.srcFeedName = srcFeedName;
	}
	public String getSrcFeedPlatform() {
		return srcFeedPlatform;
	}
	public void setSrcFeedPlatform(String srcFeedPlatform) {
		this.srcFeedPlatform = srcFeedPlatform;
	}
	public String getTgtFeedPlatform() {
		return tgtFeedPlatform;
	}
	public void setTgtFeedPlatform(String tgtFeedPlatform) {
		this.tgtFeedPlatform = tgtFeedPlatform;
	}
	public boolean isHasHeader() {
		return hasHeader;
	}
	public void setHasHeader(boolean hasHeader) {
		this.hasHeader = hasHeader;
	}
	public boolean isHasTrailer() {
		return hasTrailer;
	}
	public void setHasTrailer(boolean hasTrailer) {
		this.hasTrailer = hasTrailer;
	}
	public String getTgtFeedLocation() {
		return tgtFeedLocation;
	}
	public void setTgtFeedLocation(String tgtFeedLocation) {
		this.tgtFeedLocation = tgtFeedLocation;
	}
	public String getTgtHiveDatabaseName() {
		return tgtHiveDatabaseName;
	}
	public void setTgtHiveDatabaseName(String tgtHiveDatabaseName) {
		this.tgtHiveDatabaseName = tgtHiveDatabaseName;
	}
	public String getTgtHiveTableName() {
		return tgtHiveTableName;
	}
	public void setTgtHiveTableName(String tgtHiveTableName) {
		this.tgtHiveTableName = tgtHiveTableName;
	}
	public boolean isHasTablePartitions() {
		return hasTablePartitions;
	}
	public void setHasTablePartitions(boolean hasTablePartitions) {
		this.hasTablePartitions = hasTablePartitions;
	}
	public String getTgtPartitionColumns() {
		return tgtPartitionColumns;
	}
	public void setTgtPartitionColumns(String tgtPartitionColumns) {
		this.tgtPartitionColumns = tgtPartitionColumns;
	}
	public boolean isValidateHeader() {
		return validateHeader;
	}
	public void setValidateHeader(boolean validateHeader) {
		this.validateHeader = validateHeader;
	}
	public boolean isValidateTrailer() {
		return validateTrailer;
	}
	public void setValidateTrailer(boolean validateTrailer) {
		this.validateTrailer = validateTrailer;
	}
	public int getHeaderDateIndex() {
		return headerDateIndex;
	}
	public void setHeaderDateIndex(int headerDateIndex) {
		this.headerDateIndex = headerDateIndex;
	}
	public String[] getTrailerCheckConfig() {
		return trailerCheckConfig;
	}
	public void setTrailerCheckConfig(String[] trailerCheckConfig) {
		this.trailerCheckConfig = trailerCheckConfig;
	}
	public String[] getColumnCheckConfig() {
		return columnCheckConfig;
	}
	public void setColumnCheckConfig(String[] columnCheckConfig) {
		this.columnCheckConfig = columnCheckConfig;
	}
	public boolean isTrailerCountHasHdrTrlr() {
		return trailerCountHasHdrTrlr;
	}
	public void setTrailerCountHasHdrTrlr(boolean trailerCountHasHdrTrlr) {
		this.trailerCountHasHdrTrlr = trailerCountHasHdrTrlr;
	}
	public String getArchiveDirLocation() {
		return archiveDirLocation;
	}
	public void setArchiveDirLocation(String archiveDirLocation) {
		this.archiveDirLocation = archiveDirLocation;
	}
	public boolean isArchiveFile() {
		return archiveFile;
	}
	public void setArchiveFile(boolean archiveFile) {
		this.archiveFile = archiveFile;
	}
	public boolean isValidateColumnChecks() {
		return validateColumnChecks;
	}
	public void setValidateColumnChecks(boolean validateColumnChecks) {
		this.validateColumnChecks = validateColumnChecks;
	}
	public String getSrcDataBaseName() {
		return srcDataBaseName;
	}
	public void setSrcDataBaseName(String srcDataBaseName) {
		this.srcDataBaseName = srcDataBaseName;
	}
	public String getDbConnectString() {
		return dbConnectString;
	}
	public void setDbConnectString(String dbConnectString) {
		this.dbConnectString = dbConnectString;
	}
	public String getDbUser() {
		return dbUser;
	}
	public void setDbUser(String dbUser) {
		this.dbUser = dbUser;
	}
	public String getCredPath() {
		return credPath;
	}
	public void setCredPath(String credPath) {
		this.credPath = credPath;
	}
	public String getPasswordAliasName() {
		return passwordAliasName;
	}
	public void setPasswordAliasName(String passwordAliasName) {
		this.passwordAliasName = passwordAliasName;
	}
	public String getHeaderDelimiter() {
		return headerDelimiter;
	}
	public void setHeaderDelimiter(String headerDelimiter) {
		this.headerDelimiter = headerDelimiter;
	}
	public String getTrailerDelimiter() {
		return trailerDelimiter;
	}
	public void setTrailerDelimiter(String trailerDelimiter) {
		this.trailerDelimiter = trailerDelimiter;
	}
	
}
