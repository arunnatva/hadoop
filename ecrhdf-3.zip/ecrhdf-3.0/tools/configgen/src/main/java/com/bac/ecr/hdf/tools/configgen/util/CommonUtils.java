package com.bac.ecr.hdf.tools.configgen.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Validate;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;
import com.bac.ecr.hdf.tools.configgen.beans.DataMappingList;
import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;
import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.InputDocs;



public class CommonUtils {

	public static final Integer WORKBOOK_CONFIG_SHEET_NUMBER = 0;
	public static final String WORKBOOK_CONFIG_SQOOP_SHEET_NUMBER = "sqoop-properties";
	public static final Integer WORKBOOK_DATAMAPPING_SHEET_NUMBER = 0;
	public static final Integer FROM_ROWNUMBER = 1;
	public static final Integer CONFIG_FIELD_COLNUMBER = 0;
	public static final Integer CONFIG_VALUE_COLNUMBER = 1;
	

	/**
	 * Returns DataSourcingConfiguration Object from the Excel Workbook. Reflection API is used in order to populate the object
	 * @param configWb
	 * @return
	 * @throws Exception 
	 * @throws IOException 
	 */
	public static DataSourcingConfiguration getConfigObjectFromExcel (Workbook configWb) throws IOException, Exception {
		
		String CONFIG_FIELD_VALUE_BLANK_ERRMSG = "\"%s\" configuration field value should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG = "\"%s\" configuration field value is not a valid one, only numbers greater than zero are allowed";
		
//		Sheet firstSheet = configWb.getSheetAt(WORKBOOK_CONFIG_SHEET_NUMBER);
		Sheet firstSheet = configWb.getSheet(InputDocs.CONFIGURATION.value());
		

		Class DataSourcingConfigurationClass = Class.forName("com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration");
		DataSourcingConfiguration dataSourcingConfig = (DataSourcingConfiguration) DataSourcingConfigurationClass.newInstance();

		for (Method method : DataSourcingConfigurationClass.getDeclaredMethods()) {
			String methodName = method.getName();
			Class[] methodParamTypes = null;
			String methodFirstParamType = null, configField = null, configValue = null;

			if (!methodName.matches("^set.+")) {
				continue;
			}

			methodParamTypes = method.getParameterTypes();
			methodFirstParamType = methodParamTypes[0].getName();
									
			Iterator<Row> iterator = firstSheet.iterator();
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				if (nextRow.getRowNum() >= FROM_ROWNUMBER) {
					Iterator<Cell> cellIterator = nextRow.cellIterator();

					while (cellIterator.hasNext()) {
						Cell nextCell = cellIterator.next();
						int columnIndex = nextCell.getColumnIndex();

						if (columnIndex == CONFIG_FIELD_COLNUMBER) {
							configField = GenerateWorkBooksUtil.getCellValue(nextCell).toString();
						} else if (columnIndex == CONFIG_VALUE_COLNUMBER) {
							configValue = GenerateWorkBooksUtil.getCellValue(nextCell).toString();
						}
					}

					if (getPropertyName(methodName).equals(configField)) {
						
						if ("java.lang.String".equals(methodFirstParamType)) {
							method.invoke(dataSourcingConfig, configValue);
						} else if ("int".equals(methodFirstParamType)) {
							
							Validate.notBlank(configValue, String.format(
									CONFIG_FIELD_VALUE_BLANK_ERRMSG,
									configField));
							Validate.isTrue(isNumeric(configValue), String
									.format(CONFIG_FIELD_VALUE_INVALID_ERRMSG,
											configField));
							double doubleVal = Double.parseDouble(configValue);
							int intVal = (int) doubleVal;
							Validate.isTrue(intVal > 0, String.format(
									CONFIG_FIELD_VALUE_INVALID_ERRMSG,
									configField));
							
							method.invoke(dataSourcingConfig, intVal);
						} else if ("boolean".equals(methodFirstParamType)) {
							boolean boolConfigValue = "Y".equalsIgnoreCase(configValue) ? true : false;
							method.invoke(dataSourcingConfig, boolConfigValue);
						} else if ("[Ljava.lang.String;".equals(methodFirstParamType)) {
							System.out.println("string array : " + configValue+" name "+method.getName());
							// The following statement removes all the
							// whitespace characters from the
							// trailerCheckConfig/columnCheckConfig config field
							// values while populating the
							// DataSourcingConfiguration bean object and changes
							// the case of the alphabets to upper.
							String modifiedConfigValue = configValue
									.replaceAll("\\s", "").toUpperCase();
							String[] stringArrayConfigValue = modifiedConfigValue
									.split(Pattern.quote("|"), -1);
							Object stringArrayObj = (Object) stringArrayConfigValue;
							method.invoke(dataSourcingConfig, stringArrayObj);
						}
					}
				}
			}

		}
		
		return (DataSourcingConfiguration) dataSourcingConfig;
	}

	/**
	 * Checks whether the given String is numeric or not
	 * 
	 * @param str
	 * @return
	 */
	private static boolean isNumeric(String str) {
		try {
			double d = Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	
	/**
	 * Retrieves the member name from the class
	 * @param recordTypeName
	 * @return
	 */
	private static String getPropertyName(String recordTypeName) {
		StringBuffer sb = new StringBuffer();
		Matcher matcher = Pattern.compile("set([a-z])([a-z]*)",
				Pattern.CASE_INSENSITIVE).matcher(recordTypeName);
		while (matcher.find()) {
			matcher.appendReplacement(sb, matcher.group(1).toLowerCase()
					+ matcher.group(2));
		}
		return matcher.appendTail(sb).toString();
	}
	
	public static String[] populateColumnCheckConfigArray(
			String columnCheckValue, String columnName, int rowNo) {

		String CONFIG_FIELD_VALUE_BLANK_ERRMSG2 = "Row no: \"%d\" - \"%s\" DataMapping column value, individual element should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG2 = "Row no: \"%d\" - \"%s\" DataMapping column value, individual element is not a valid one, valid values are %s";

		// The following statement removes all the whitespace characters
		// from the columnChecks cell value and changes the case of the
		// alphabets to upper.
		String modColChecksCellValue = columnCheckValue.replaceAll("\\s", "")
				.toUpperCase();

		String[] columnChecksStrArray = modColChecksCellValue.split(
				Pattern.quote(","), -1);

		for (String columnCheck : columnChecksStrArray) {
			Validate.notBlank(columnCheck, String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG2, rowNo, "columnChecks"));
			Validate.matchesPattern(columnCheck, "NULL|DUP", String.format(
					CONFIG_FIELD_VALUE_INVALID_ERRMSG2, rowNo, "columnChecks",
					"DUP, NULL"));
		}

		List<String> columnCheckResultArray = new ArrayList<String>();

		for (int rowCounter = 0; rowCounter < columnChecksStrArray.length; rowCounter++) {
			String result = columnChecksStrArray[rowCounter] + "," + columnName;
			columnCheckResultArray.add(result);
		}

		return (String[]) columnCheckResultArray.toArray(new String[0]);
	}
	

	/**
	 * This method returns a DataMappingList object created from the DataMapping
	 * excel workbook.
	 * 
	 * @param dataMappingWb
	 * @return
	 * @throws IOException
	 */
	public static Map<String, Object> getDataMappingInfoFromExcel (
			Workbook dataMappingWb) throws IOException, Exception {

		Sheet dataMappingSheet = dataMappingWb.getSheet(InputDocs.DATAMAPPING.value());
		List<DataMapping> dataMappingList = new ArrayList<DataMapping>();
		Iterator<Row> iterator = dataMappingSheet.iterator();

		if (iterator.hasNext()) {
			Row HeaderRow = iterator.next();
			ValidationUtil.validateMapDocHeaderRow(HeaderRow);
		}
		
		// The following while construct creates a DataMapping object for each
		// row in the DataMapping excel document and adds the same to an
		// ArrayList of DataMappings.
		String [] ColumnCheckConfigArray =null;
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			dataMappingList.add(DataMapping.createInstance(nextRow));

			if ( nextRow.getCell(5) != null && ! nextRow.getCell(5).toString().trim().isEmpty() ) {
				String colChecksCellValue = GenerateWorkBooksUtil.getCellValue(
						nextRow.getCell(5)).toString();
				
				ColumnCheckConfigArray = ArrayUtils.addAll(
						ColumnCheckConfigArray,
						populateColumnCheckConfigArray(colChecksCellValue,
								nextRow.getCell(0).toString(),
								nextRow.getCell(5).getRowIndex() + 1));
			}

		}
		
		DataMappingList mapdoc = new DataMappingList();
		mapdoc.setColumnMapping(dataMappingList);
		
		Map<String, Object> retMapObject = new HashMap<String, Object>();
		
		retMapObject.put("columnCheckStr", ColumnCheckConfigArray);
		retMapObject.put("dataMappingObject", mapdoc);
		
		
		return retMapObject;
	}	
	
	/**
	 * This method returns a Map<String,String> object from the Sqoop
	 * @param dataMappingWb
	 * @return
	 * @throws IOException
	 */
	public static Map<String,String> getSqoopPropertiesInfoFromExcel (
			Workbook configBook) throws IOException, Exception {
		
		Map<String,String> sqoopPropertiesMap = new HashMap<String,String>();
//		Sheet sqoopPropertiesSheet = configBook
//				.getSheet(WORKBOOK_CONFIG_SQOOP_SHEET_NUMBER);
		Sheet sqoopPropertiesSheet = configBook.getSheet(InputDocs.SQOOP.value());		
		
		if (sqoopPropertiesSheet == null) return null;

		Iterator<Row> iterator = sqoopPropertiesSheet.iterator();

		Row HeaderRow  = iterator.next(); 
		//TODO:We might need to validate the header row.
		
		// Populating the Schema into DataMappingList Object
		while (iterator.hasNext()) {
			String name = "";
			String value = "";
			Row nextRow = iterator.next();
			
			if(nextRow.getCell(0) != null){ 				
				 name = nextRow.getCell(0).toString().trim();
			}
			
			if(nextRow.getCell(1) != null){ 				
				 value = nextRow.getCell(1).toString().trim();
			}
			
			if (name != null && !name.isEmpty())
				sqoopPropertiesMap.put(name, value);			
		}
	
		return sqoopPropertiesMap;
	}
	
	/**
	 * This method writes hive ddl string into a flat file
	 * @param hiveDdl
	 * @param outFileObj
	 */
	public static void writeToFile(String hiveDdl,File outFileObj) {
		
		try {
			FileUtils.writeStringToFile(outFileObj,hiveDdl);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	
}
