package com.bac.ecr.hdf.tools.configgen.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;
import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;
import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.InputDocs;

public class GenerateHiveDdlUtil {

	public GenerateHiveDdlUtil() {
	}

	private static final String LINE_SEPARATOR = "\r\n";

	public List<DataMapping> getRowsFromWorkbook(Workbook dataMappingWb) throws Exception {

		List<DataMapping> rowList = new ArrayList<DataMapping>();
		Sheet sheet = dataMappingWb.getSheet(InputDocs.DATAMAPPING.value());
		Iterator<Row> rowIterator = sheet.iterator();

		if (rowIterator.hasNext()) {
			Row HeaderRow = rowIterator.next();
			ValidationUtil.validateMapDocHeaderRow(HeaderRow);
		}

		// The following while construct creates a DataMapping object for each
		// data row in the DataMapping excel sheet and adds the same to an
		// ArrayList of DataMappings.
		while (rowIterator.hasNext()) {
			rowList.add(DataMapping.createInstance(rowIterator.next()));
		}

		return rowList;
	}

	/**
	 * This method returns a map consisting of hive DDL and table partition
	 * information.
	 * 
	 * @param rowList
	 * @param config
	 * @return a map object
	 */
	public Map<String, String> getHiveDdlInfo(List<DataMapping> rowList,
			DataSourcingConfiguration config) {

		Map<String, String> hiveDdlInfoMap = new HashMap<String, String>();
		StringBuilder hiveDdlSb = new StringBuilder();

		TreeMap<Integer, String> partCols = new TreeMap<Integer, String>();
		boolean isVerExists = false;
		String verColValue = null;
		hiveDdlSb.append("CREATE EXTERNAL TABLE IF NOT EXISTS ")
				.append(config.getTgtHiveDatabaseName()).append(".")
				.append(config.getTgtHiveTableName()).append(LINE_SEPARATOR)
				.append(" ( ");
		for (int idx = 0; idx < rowList.size(); idx++) {
			if (rowList.get(idx).getIsPartitioned()!=null && rowList.get(idx).getIsPartitioned().equalsIgnoreCase("Y")) {
				if (rowList.get(idx).getPartitionOrder() == 0) {
					partCols.put(1, rowList.get(idx).getColumnName() + " "
							+ rowList.get(idx).getColumnType());
				} else {
					
					partCols.put(rowList.get(idx).getPartitionOrder(), rowList
							.get(idx).getColumnName()
							+ " "
							+ rowList.get(idx).getColumnType());
				}

			} else if (rowList.get(idx).getIsPartitioned()!=null && rowList.get(idx).getIsPartitioned()
					.equalsIgnoreCase("V")) {
				isVerExists = true;
				verColValue = rowList.get(idx).getColumnName() + " "
						+ rowList.get(idx).getColumnType();
			} else {

				hiveDdlSb.append(rowList.get(idx).getColumnName())

				.append(" ").append(rowList.get(idx).getColumnType());
				hiveDdlSb.append(",").append(LINE_SEPARATOR);
			}
		}
		
		// Removing the last occurrence of comma(,) character from the StringBuilder.
		int ind = hiveDdlSb.lastIndexOf(",");
		hiveDdlSb.replace(ind, ind+1, "");
		
		if (isVerExists) {
			partCols.put(partCols.size() + 1, verColValue);
		}
		hiveDdlSb.append(" ) ").append(LINE_SEPARATOR);
		if (partCols.size() > 0) {
			hiveDdlSb.append(getPartitionString(partCols, true));
		}
		hiveDdlSb.append(LINE_SEPARATOR).append("STORED AS PARQUET LOCATION '")
				.append(config.getTgtFeedLocation()).append("'");

		System.out.println("Hive DDL is : "+hiveDdlSb.toString());
		
		hiveDdlInfoMap.put("hiveDdl", hiveDdlSb.toString());
		hiveDdlInfoMap.put("hasTablePartitions", partCols.size() > 0 ? "Y"
				: "N");
		hiveDdlInfoMap.put("tgtPartitionColumns",
				partCols.size() > 0 ? getPartitionString(partCols, false) : "");
		
		return hiveDdlInfoMap;
	}

	/**
	 * This method returns the constructed Hive DDL PARTITIONED BY clause string
	 * by taking the column names from the provided map if isWithPartitionClause
	 * parameter value is true otherwise it returns a string with the column
	 * names in the map concatenated by comma character.
	 * 
	 * @param TargetMap
	 * @param isWithPartitionClause
	 * @return
	 */
	public String getPartitionString(TreeMap<Integer, String> TargetMap,
			boolean isWithPartitionClause) {
		StringBuilder partitionSb = new StringBuilder();

		if (isWithPartitionClause) {
			partitionSb.append("PARTITIONED BY").append(LINE_SEPARATOR)
					.append(" ( ");
		}

		for (Map.Entry<Integer, String> result : TargetMap.entrySet()) {
			if (isWithPartitionClause) {
				partitionSb.append(result.getValue()).append(",");
			} else {
				partitionSb.append(result.getValue().split(" ")[0]).append(",");
			}
		}

		if (isWithPartitionClause) {
			return partitionSb.toString().substring(0,
					partitionSb.lastIndexOf(","))
					+ " ) ";
		}
		return partitionSb.toString()
				.substring(0, partitionSb.lastIndexOf(","));
	}
}