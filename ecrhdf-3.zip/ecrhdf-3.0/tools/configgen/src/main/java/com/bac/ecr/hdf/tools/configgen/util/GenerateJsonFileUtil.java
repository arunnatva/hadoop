package com.bac.ecr.hdf.tools.configgen.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GenerateJsonFileUtil {

	/**
	 * This method can be used to serialize any Java object as JSON output,
	 * written to File provided.
	 * 
	 * @param obj
	 * @param resultFile
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */
	static public void writeObjectToFile(Object obj, File resultFile)
			throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
		System.out.println("json : "+ StringEscapeUtils.unescapeJava(jsonInString));
		CommonUtils.writeToFile(StringEscapeUtils.unescapeJava(jsonInString), resultFile);
	
	}

}
