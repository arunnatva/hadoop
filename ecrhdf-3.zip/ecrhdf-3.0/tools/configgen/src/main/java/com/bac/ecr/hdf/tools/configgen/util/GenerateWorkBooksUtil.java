package com.bac.ecr.hdf.tools.configgen.util;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.ExcelTypes;

public class GenerateWorkBooksUtil {

	/**
	 * This method reads a MICROSOFT EXCEL file and returns a WorkBook instance
	 * @param inputStream
	 * @param excelFilePath
	 * @return WorkBook
	 * @throws IOException
	 */
	public static Workbook getWorkbook(String excelFilePath) throws IOException {
		Workbook workbook = null;
		
		if (excelFilePath.endsWith(ExcelTypes.XLSX_EXTN.value())) {
			workbook = new XSSFWorkbook(new FileInputStream(excelFilePath));
		} else if (excelFilePath.endsWith(ExcelTypes.XLS_EXTN.value())) {
			workbook = new HSSFWorkbook(new FileInputStream(excelFilePath));
		} else {
			throw new IllegalArgumentException("The specified file is not Excel file");
		}

		return workbook;
	}

	
	/**
	 * This method returns an Object from an XLS cell based on the cell type
	 * @param cell
	 * @return Object
	 */
	public static Object getCellValue(Cell cell) {
		
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue().trim();			
		case Cell.CELL_TYPE_BOOLEAN:
			return cell.getBooleanCellValue();
		case Cell.CELL_TYPE_NUMERIC:
			return cell.getNumericCellValue();
		default:
			return new String("");
		}
		
	}

	
}
