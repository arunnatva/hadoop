package com.bac.ecr.hdf.tools.configgen.util;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang3.Validate;
import org.apache.poi.ss.usermodel.Row;

import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.FeedPlatforms;
import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.HiveDataType;
import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;
import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;


public class ValidationUtil {

	/**
	 * This method validates the properties of DataSourcingConfiguration object
	 * created from the config excel document.
	 * 
	 * @param config
	 */
	public static void validateConfig(DataSourcingConfiguration config) {

		String CONFIG_FIELD_VALUE_BLANK_ERRMSG = "\"%s\" configuration field value should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG = "\"%s\" configuration field value is not a valid one, valid values are %s";
		String CONFIG_FIELD_VALUE_BLANK_ERRMSG2 = "\"%s\" configuration field value, individual element should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG2 = "\"%s\" configuration field value, individual element format is invalid";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG3 = "\"archiveDirLocation\" configuration field value is mandatory only when the user has chosen to archive the source file";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG4 = "\"trailerCheckConfig\" configuration field value is mandatory only when the user has chosen that the source file has trailer and to validate it";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG5 = "\"trailerCountHasHdrTrlr\" configuration field value can be chosen as 'y' only if the source file has header and trailer records";

		Validate.notBlank(config.getSrcFeedLocation(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedLocation"));

		Validate.notBlank(config.getSrcFeedType(),
				String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedType"));
		Validate.validState(
				((config.getSrcFeedType().equalsIgnoreCase("file") || config
						.getSrcFeedType().equalsIgnoreCase("database")) ? true
						: false), CONFIG_FIELD_VALUE_INVALID_ERRMSG,
				"srcFeedType", "file, database");

		Validate.notBlank(config.getSrcFileFormat(),
				String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFileFormat"));
		Validate.validState(
				((config.getSrcFileFormat().equalsIgnoreCase("delimited") || config
						.getSrcFileFormat().equalsIgnoreCase("fixedwidth")) ? true
						: false), CONFIG_FIELD_VALUE_INVALID_ERRMSG,
				"srcFileFormat", "delimited, fixedwidth");

		if (config.getSrcFileFormat().equalsIgnoreCase("delimited")) {
			Validate.notBlank(config.getSrcFeedDelimiter(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedDelimiter"));
		}

		Validate.notBlank(config.getSrcFeedName(),
				String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedName"));

		Validate.notBlank(config.getSrcFeedPlatform(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedPlatform"));
		
		Validate.validState(FeedPlatforms.isValidPlatform(config.getSrcFeedPlatform()),
				CONFIG_FIELD_VALUE_INVALID_ERRMSG, 
				"srcFeedPlatform",
				FeedPlatforms.listAll());
		
		Validate.notBlank(config.getTgtFeedPlatform(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtFeedPlatform"));
		
		Validate.validState(FeedPlatforms.isValidPlatform(config.getTgtFeedPlatform()),
				CONFIG_FIELD_VALUE_INVALID_ERRMSG, 
				"tgtFeedPlatform",
				FeedPlatforms.listAll());
		
		Validate.notBlank(config.getTgtFeedLocation(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtFeedLocation"));
		Validate.notBlank(config.getTgtHiveDatabaseName(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtHiveDatabaseName"));
		Validate.notBlank(config.getTgtHiveTableName(), String.format(
				CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtHiveTableName"));

		if (config.isHasTablePartitions()) {
			Validate.notBlank(config.getTgtPartitionColumns(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtPartitionColumns"));
		}

		if (config.isArchiveFile()) {
			Validate.notBlank(config.getArchiveDirLocation(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "archiveDirLocation"));
		} else {
			Validate.validState(config.getArchiveDirLocation().isEmpty(),
					CONFIG_FIELD_VALUE_INVALID_ERRMSG3);
		}
		
		if (config.isHasHeader() && config.isValidateHeader()) {
			Validate.validState(
					((config.getHeaderDateIndex() > 0) ? true : false),
					"\"headerDateIndex\" configuration field value should not be blank. Possible values starts from one");
		}

		if (config.isHasTrailer() && config.isValidateTrailer()) {
			for (String trailerCheckConfig : config.getTrailerCheckConfig()) {
				Validate.notBlank(trailerCheckConfig, String.format(
						CONFIG_FIELD_VALUE_BLANK_ERRMSG2, "trailerCheckConfig"));
				Validate.matchesPattern(trailerCheckConfig,
						"(?i)(COUNT,\\d+)|(SUM,\\d+,\\d+)", String.format(
								CONFIG_FIELD_VALUE_INVALID_ERRMSG2,
								"trailerCheckConfig"));
			}
		} else if (!config.isHasTrailer() && !config.isValidateTrailer()) {
			Validate.validState("".equals(config.getTrailerCheckConfig()[0]),
					CONFIG_FIELD_VALUE_INVALID_ERRMSG4);
		}
		
		if (!config.isHasHeader() && !config.isHasTrailer()) {
			Validate.validState(!config.isTrailerCountHasHdrTrlr(),
					CONFIG_FIELD_VALUE_INVALID_ERRMSG5);
		}
		
		if (config.getSrcFeedType().equalsIgnoreCase("database")) {
			Validate.notBlank(config.getSrcDataBaseName(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcDataBaseName"));
			Validate.notBlank(config.getDbConnectString(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "dbConnectString"));
			Validate.notBlank(config.getDbUser(),
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "dbUser"));
			Validate.notBlank(config.getCredPath(),
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "credPath"));
			Validate.notBlank(config.getPasswordAliasName(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "passwordAliasName"));
			//Validate.notBlank(config.getFilterCond(), String.format(
			//		CONFIG_FIELD_VALUE_BLANK_ERRMSG, "filterCond"));
		}
		
	}
	
	// Mapping Doc Sheet Header validations. Defect D-17459

	public static void validateMapDocHeaderRow(Row HeaderRow) throws Exception {

		String columnName = (HeaderRow.getCell(0) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(0))
						.toString());
		String columnType = (HeaderRow.getCell(1) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(1))
						.toString());
		String isPartitioned = (HeaderRow.getCell(2) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(2))
						.toString());
		String partitionOrder = (HeaderRow.getCell(3) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(3))
						.toString());
		String isInSourceFile = (HeaderRow.getCell(4) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(4))
						.toString());
		String columnChecks = (HeaderRow.getCell(5) == null) ? ""
				: (GenerateWorkBooksUtil.getCellValue(HeaderRow.getCell(5))
						.toString());

		if (!(

		"columnName".equals(columnName) && "columnType".equals(columnType)
				&& "isPartitioned".equals(isPartitioned)
				&& "partitionOrder".equals(partitionOrder)
				&& "isInSourceFile".equals(isInSourceFile) && "columnChecks"
					.equals(columnChecks))) {
			throw new Exception(
					"Invalid DataMapping Document Headers. Expected : columnName   columnType   isPartitioned   partitionOrder   isInSourceFile   columnChecks");
		}
	}

	/**
	 * This method validates the properties of DataMapping objects created from
	 * the DataMapping excel workbook.
	 * 
	 * @param dmList
	 */
	public static void validateFields(List<DataMapping> dmList) {

		String MAP_FIELD_VALUE_BLANK_ERRMSG = "Row no: \"%d\" - \"%s\"  field value should not be blank.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG = "Row no: \"%d\" - \"%s\" field value contains invalid characters.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG2 = "Row no: \"%d\" - \"%s\" field value should not be negative if provided.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG3 = "Row no: \"%d\" - Only for partitioned columns, isInSourceFile field value can be chosen as 'N'.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG4 = "partitionOrder field values are mandatory and should start from one for partitioned columns.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG5 = "partitionOrder field values are applicable only for partitioned columns and should not be present for non-partitioned columns.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG6 = "All the columns cannot be set as partitioned.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG7 = "Row no: \"%d\" - Date datatype is not supported in Parquet file format.";
		String MAP_FIELD_VALUE_DATATYPE_MISMATCH_ERRMSG = "Row no: \"%d\" - \"%s\" field value not matching with any of the Hive's data types.";
		String MAP_FIELD_VALUE_DUPLICATE_ERRMSG = "\"%s\" field should not contain duplicate values.";
		String MAP_FIELD_VALUE_DUPLICATE_ERRMSG2 = "columnName field should not contain duplicate values irrespective of case.";
		String MAP_FIELD_VALUE_RANDOM_ERRMSG = "\"%s\" field values should be in a sequence starting from one.";

		Integer rowNum = 1;
		TreeMap<Integer, String> treeMapObj = new TreeMap<Integer, String>();
		ArrayList<String> columnNameList = new ArrayList<String>();
		int actPartitionOrderValsTotal = 0;
		int numOfPartitionedColumns = 0;
		boolean isPartitionOrderEmpty = false;
		for (DataMapping dataMapEachRow : dmList) {
			rowNum++;

			Validate.notBlank(dataMapEachRow.getColumnName(), String.format(
					MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum, "columnName"));
			Validate.matchesPattern(dataMapEachRow.getColumnName(),
					"[a-zA-Z0-9_]+", String.format(
							MAP_FIELD_VALUE_INVALID_ERRMSG, rowNum,
							"columnName"));
			
			Validate.validState(!columnNameList.contains(dataMapEachRow
					.getColumnName().toUpperCase()),
					MAP_FIELD_VALUE_DUPLICATE_ERRMSG2);
			columnNameList.add(dataMapEachRow.getColumnName().toUpperCase());

			Validate.notBlank(dataMapEachRow.getColumnType(), String.format(
					MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum, "columnType"));
			Validate.matchesPattern(dataMapEachRow.getColumnType(),
					"[a-zA-Z0-9,() ]+", String.format(
							MAP_FIELD_VALUE_INVALID_ERRMSG, rowNum,
							"columnType"));
			Validate.validState(HiveDataType.isValidHiveType(dataMapEachRow
					.getColumnType()), String.format(
					MAP_FIELD_VALUE_DATATYPE_MISMATCH_ERRMSG, rowNum,
					"columnType"));
			
			Validate.isTrue(
					!HiveDataType.DATE.value().equalsIgnoreCase(
							dataMapEachRow.getColumnType()),
					String.format(MAP_FIELD_VALUE_INVALID_ERRMSG7, rowNum));

			int partitionOrder = dataMapEachRow.getPartitionOrder();
			if (partitionOrder != 0) {

				Validate.validState((partitionOrder > 0 ? true : false), String
						.format(MAP_FIELD_VALUE_INVALID_ERRMSG2, rowNum,
								"partitionOrder"));

				Validate.validState(
						!"N".equals(dataMapEachRow.getIsPartitioned()),
						MAP_FIELD_VALUE_INVALID_ERRMSG5);
				
				Validate.validState(!treeMapObj.containsKey(partitionOrder),
						String.format(MAP_FIELD_VALUE_DUPLICATE_ERRMSG,
								"partitionOrder"));
				treeMapObj.put(partitionOrder, dataMapEachRow.getColumnName());
				
				actPartitionOrderValsTotal += partitionOrder;
			}
			
			Validate.isTrue(!(!dataMapEachRow.isInSourceFile() && "N"
					.equals(dataMapEachRow.getIsPartitioned())), String.format(
					MAP_FIELD_VALUE_INVALID_ERRMSG3, rowNum));

			if (!"N".equals(dataMapEachRow.getIsPartitioned())) {
				numOfPartitionedColumns++;
				if (!isPartitionOrderEmpty) {
					isPartitionOrderEmpty = (partitionOrder == 0) ? true
							: false;
				}
			}
			
		}
		
		Validate.isTrue(numOfPartitionedColumns != dmList.size(),
				MAP_FIELD_VALUE_INVALID_ERRMSG6);
		
		Validate.isTrue(
				!(numOfPartitionedColumns > 0 && isPartitionOrderEmpty),
				MAP_FIELD_VALUE_INVALID_ERRMSG4);
		
		if (!treeMapObj.isEmpty()) {
			int maxPartitionOrder = treeMapObj.lastKey();
			int expPartitionOrderValsTotal = maxPartitionOrder
					* (maxPartitionOrder + 1) / 2;

			Validate.validState(
					actPartitionOrderValsTotal == expPartitionOrderValsTotal,
					String.format(MAP_FIELD_VALUE_RANDOM_ERRMSG,
							"partitionOrder"));
		}
		
	}
	
}