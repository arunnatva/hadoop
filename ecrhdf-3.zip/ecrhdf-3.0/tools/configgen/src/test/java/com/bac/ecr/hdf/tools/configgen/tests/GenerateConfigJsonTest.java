package com.bac.ecr.hdf.tools.configgen.tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;
import com.bac.ecr.hdf.tools.configgen.util.CommonUtils;
import com.bac.ecr.hdf.tools.configgen.util.GenerateJsonFileUtil;
import com.bac.ecr.hdf.tools.configgen.util.GenerateWorkBooksUtil;

public class GenerateConfigJsonTest {

	@Test(enabled=true)
	public void getJsonConfig() throws IOException, Exception {
		
		Workbook wb = GenerateWorkBooksUtil.getWorkbook("src/test/resources/Configuration.xls");
		DataSourcingConfiguration config = CommonUtils.getConfigObjectFromExcel(wb);
		System.out.println("delimiter : "+config.getSrcFeedDelimiter());
		GenerateJsonFileUtil.writeObjectToFile(config, new File("workspace/codegen/src/test/resources/mapping_out.json"));	
		Assert.assertEquals(StringEscapeUtils.unescapeJava(config.getSrcFeedDelimiter()), "\u0001");
		Assert.assertEquals(config.getTgtFeedLocation(), "hdfs://nameservice1/haas/and/db/andes_dev2/datafiles/andes_staging_dev2/ecr_core/ecr_core_guart");
		Assert.assertEquals(config.isHasHeader(), true);
		System.out.println("trailer config : "+config.getTrailerCheckConfig().toString());
		Assert.assertEquals(config.getTrailerCheckConfig().length, 2);
		Assert.assertEquals(config.getTrailerCheckConfig()[1],"SUM,4,3");
		Assert.assertEquals(config.getColumnCheckConfig().length, 3);
		Assert.assertEquals(config.getColumnCheckConfig()[2], "NULL,04");
		
		
		
	}
	
}
