package com.bac.ecr.hdf.tools.configgen.tests;

import org.apache.poi.ss.usermodel.Workbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.tools.configgen.beans.DataSourcingConfiguration;
import com.bac.ecr.hdf.tools.configgen.util.CommonUtils;
import com.bac.ecr.hdf.tools.configgen.util.GenerateWorkBooksUtil;

public class GenerateConfigObjectTest {

	@Test(enabled = false)
	public void getConfigWorkbook() {
		Workbook configWb;

		String CONFIG_FIELD_VALUE_BLANK_ERRMSG = "\"%s\" configuration field value should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG = "\"%s\" configuration field value is not a valid one, valid values are %s";
		String CONFIG_FIELD_VALUE_BLANK_ERRMSG2 = "\"%s\" configuration field value, individual element should not be blank";
		String CONFIG_FIELD_VALUE_INVALID_ERRMSG2 = "\"%s\" configuration field value, individual element format is invalid";

		try {

			configWb = GenerateWorkBooksUtil
					.getWorkbook("src/test/resources/MappingDocumentV1.xls");
			DataSourcingConfiguration sourceConfig = CommonUtils
					.getConfigObjectFromExcel(configWb);

			Assert.assertNotNull(sourceConfig.getSrcFeedLocation(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedLocation"));
			Assert.assertNotEquals(sourceConfig.getSrcFeedLocation(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"srcFeedLocation"));

			Assert.assertNotNull(sourceConfig.getSrcFeedType(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedType"));
			Assert.assertNotEquals(sourceConfig.getSrcFeedType(), "", String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedType"));
			Assert.assertTrue(
					((sourceConfig.getSrcFeedType().equalsIgnoreCase("file") || sourceConfig
							.getSrcFeedType().equalsIgnoreCase("database")) ? true
							: false), String.format(
							CONFIG_FIELD_VALUE_INVALID_ERRMSG, "srcFeedType",
							"file, database"));

			Assert.assertNotNull(sourceConfig.getSrcFileFormat(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFileFormat"));
			Assert.assertNotEquals(sourceConfig.getSrcFileFormat(), "", String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFileFormat"));
			Assert.assertTrue(((sourceConfig.getSrcFileFormat()
					.equalsIgnoreCase("delimited") || sourceConfig
					.getSrcFileFormat().equalsIgnoreCase("fixedwidth")) ? true
					: false), String.format(CONFIG_FIELD_VALUE_INVALID_ERRMSG,
					"srcFileFormat", "delimited, fixedwidth"));

			if (sourceConfig.getSrcFileFormat().equalsIgnoreCase("delimited")) {
				Assert.assertNotNull(sourceConfig.getSrcFeedDelimiter(), String
						.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
								"srcFeedDelimiter"));
				Assert.assertNotEquals(sourceConfig.getSrcFeedDelimiter(), "",
						String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
								"srcFeedDelimiter"));
			}

			Assert.assertNotNull(sourceConfig.getSrcFeedName(), String.format(
					CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedName"));
			Assert.assertNotEquals(sourceConfig.getSrcFeedName(), "", String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedName"));

			Assert.assertNotNull(sourceConfig.getSrcFeedPlatform(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "srcFeedPlatform"));
			Assert.assertNotEquals(sourceConfig.getSrcFeedPlatform(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"srcFeedPlatform"));
			Assert.assertTrue(
					((sourceConfig.getSrcFeedPlatform().equalsIgnoreCase(
							"oracle")
							|| sourceConfig.getSrcFeedPlatform()
									.equalsIgnoreCase("db2")
							|| sourceConfig.getSrcFeedPlatform()
									.equalsIgnoreCase("mssql")
							|| sourceConfig.getSrcFeedPlatform()
									.equalsIgnoreCase("teradata")
							|| sourceConfig.getSrcFeedPlatform()
									.equalsIgnoreCase("netezza") || sourceConfig
							.getSrcFeedPlatform().equalsIgnoreCase("hive")) ? true
							: false), String.format(
							CONFIG_FIELD_VALUE_INVALID_ERRMSG,
							"srcFeedPlatform",
							"oracle, db2, mssql, teradata, netezza, hive"));

			Assert.assertNotNull(sourceConfig.getTgtFeedPlatform(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtFeedPlatform"));
			Assert.assertNotEquals(sourceConfig.getTgtFeedPlatform(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtFeedPlatform"));
			Assert.assertTrue(
					((sourceConfig.getTgtFeedPlatform().equalsIgnoreCase(
							"oracle")
							|| sourceConfig.getTgtFeedPlatform()
									.equalsIgnoreCase("db2")
							|| sourceConfig.getTgtFeedPlatform()
									.equalsIgnoreCase("mssql")
							|| sourceConfig.getTgtFeedPlatform()
									.equalsIgnoreCase("teradata")
							|| sourceConfig.getTgtFeedPlatform()
									.equalsIgnoreCase("netezza") || sourceConfig
							.getTgtFeedPlatform().equalsIgnoreCase("hive")) ? true
							: false), String.format(
							CONFIG_FIELD_VALUE_INVALID_ERRMSG,
							"tgtFeedPlatform",
							"oracle, db2, mssql, teradata, netezza, hive"));

			Assert.assertNotNull(sourceConfig.getTgtFeedLocation(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG, "tgtFeedLocation"));
			Assert.assertNotEquals(sourceConfig.getTgtFeedLocation(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtFeedLocation"));

			Assert.assertNotNull(sourceConfig.getTgtHiveDatabaseName(), String
					.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtHiveDatabaseName"));
			Assert.assertNotEquals(sourceConfig.getTgtHiveDatabaseName(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtHiveDatabaseName"));

			Assert.assertNotNull(sourceConfig.getTgtHiveTableName(),
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtHiveTableName"));
			Assert.assertNotEquals(sourceConfig.getTgtHiveTableName(), "",
					String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
							"tgtHiveTableName"));

			if (sourceConfig.isHasTablePartitions()) {
				Assert.assertNotNull(sourceConfig.getTgtPartitionColumns(),
						String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
								"tgtPartitionColumns"));
				Assert.assertNotEquals(sourceConfig.getTgtPartitionColumns(),
						"", String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
								"tgtPartitionColumns"));
			}

			if (sourceConfig.isValidateHeader()) {
				Assert.assertTrue(
						((sourceConfig.getHeaderDateIndex() > 0) ? true
								: false),
						"\"headerDateIndex\" configuration field value should not be blank. Possible values starts from one");
			}

			if (sourceConfig.isHasTrailer() && sourceConfig.isValidateTrailer()) {
				Assert.assertNotNull(sourceConfig.getTrailerCheckConfig(),
						String.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG,
								"trailerCheckConfig"));
				if (sourceConfig.isHasTrailer()
						&& sourceConfig.isValidateTrailer()) {
					for (String trailerCheckConfig : sourceConfig
							.getTrailerCheckConfig()) {
						Assert.assertNotEquals(trailerCheckConfig, "", String
								.format(CONFIG_FIELD_VALUE_BLANK_ERRMSG2,
										"trailerCheckConfig"));
						Assert.assertTrue(trailerCheckConfig
								.matches("(?i)(COUNT,\\d+)|(SUM,\\d+,\\d+)"),
								String.format(
										CONFIG_FIELD_VALUE_INVALID_ERRMSG2,
										"trailerCheckConfig"));
					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
