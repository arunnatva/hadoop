package com.bac.ecr.hdf.tools.configgen.tests;

import org.testng.annotations.Test;

public class GenerateHiveDdlUtilTest {

	@Test(enabled=true)
	public void getHiveDdl() {
		
	}
	
}
