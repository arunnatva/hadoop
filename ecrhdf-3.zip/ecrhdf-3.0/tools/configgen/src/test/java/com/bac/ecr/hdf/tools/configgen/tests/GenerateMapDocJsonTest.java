package com.bac.ecr.hdf.tools.configgen.tests;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.testng.Assert;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.tools.configgen.beans.DataMapping;
import com.bac.ecr.hdf.tools.configgen.beans.DataMappingList;
import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.HiveDataType;
import com.bac.ecr.hdf.tools.configgen.util.CommonUtils;
import com.bac.ecr.hdf.tools.configgen.util.GenerateWorkBooksUtil;

public class GenerateMapDocJsonTest {

	@Test(enabled = false)
	public void getMapDocWorkbook() {
		Workbook mapDocWb;

		String MAP_FIELD_VALUE_BLANK_ERRMSG = "Row no: \"%d\" - \"%s\"  field value should not be blank.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG = "Row no: \"%d\" - \"%s\" field value contains invalid characters.";
		String MAP_FIELD_VALUE_INVALID_ERRMSG2 = "Row no: \"%d\" - \"%s\" field value should not be negative if provided.";
		String MAP_FIELD_VALUE_DATATYPE_MISMATCH_ERRMSG = "Row no: \"%d\" - \"%s\" field value not matching with any of the Hive's data types.";
		String MAP_FIELD_VALUE_DATE_DATATYPE_NOT_SUPPORTED_ERRMSG = "Row no: \"%d\" - Date datatype is not supported in Parquet file format.";
		String MAP_FIELD_VALUE_DUPLICATE_ERRMSG = "\"%s\" field should not contain duplicate values.";
		String MAP_FIELD_VALUE_RANDOM_ERRMSG = "\"%s\" field values should be in a sequence starting from one.";

		try {
			mapDocWb = GenerateWorkBooksUtil
					.getWorkbook("src/test/resources/MappingDocumentV1.5.xls");

			Map<String, Object> map = CommonUtils
					.getDataMappingInfoFromExcel(mapDocWb);
			DataMappingList mapDocList = (DataMappingList) map
					.get("dataMappingObject");
			List<DataMapping> dmList = mapDocList.getColumnMapping();

			Integer rowNum = 1;
			TreeMap<Integer, String> treeMapObj = new TreeMap<Integer, String>();
			int actPartitionOrderValsTotal = 0;

			for (DataMapping dataMapEachRow : dmList) {
				rowNum++;

				Assert.assertNotNull(dataMapEachRow.getColumnName(), String
						.format(MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum,
								"columnName"));
				Assert.assertNotEquals(dataMapEachRow.getColumnName(), "",
						String.format(MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum,
								"columnName"));
				Assert.assertTrue(
						dataMapEachRow.getColumnName().matches("[a-zA-Z0-9_]+"),
						String.format(MAP_FIELD_VALUE_INVALID_ERRMSG, rowNum,
								"columnName"));

				Assert.assertNotNull(dataMapEachRow.getColumnType(), String
						.format(MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum,
								"columnType"));
				Assert.assertNotEquals(dataMapEachRow.getColumnType(), "",
						String.format(MAP_FIELD_VALUE_BLANK_ERRMSG, rowNum,
								"columnType"));
				Assert.assertTrue(
						dataMapEachRow.getColumnType().matches("[a-zA-Z0-9,() ]+"),
						String.format(MAP_FIELD_VALUE_INVALID_ERRMSG, rowNum,
								"columnType"));
				
				Assert.assertTrue(HiveDataType.isValidHiveType(dataMapEachRow
						.getColumnType()), String.format(
						MAP_FIELD_VALUE_DATATYPE_MISMATCH_ERRMSG, rowNum,
						"columnType"));
				Assert.assertTrue(
						!HiveDataType.DATE.value().equalsIgnoreCase(
								dataMapEachRow.getColumnType()),
						String.format(
								MAP_FIELD_VALUE_DATE_DATATYPE_NOT_SUPPORTED_ERRMSG,
								rowNum));				

				int partitionOrder = dataMapEachRow.getPartitionOrder();
				if (partitionOrder != 0) {

					Assert.assertTrue((partitionOrder > 0 ? true : false),
							String.format(MAP_FIELD_VALUE_INVALID_ERRMSG2,
									rowNum, "partitionOrder"));
					Assert.assertTrue(!treeMapObj.containsKey(partitionOrder),
							String.format(MAP_FIELD_VALUE_DUPLICATE_ERRMSG,
									"partitionOrder"));
					treeMapObj.put(partitionOrder,
							dataMapEachRow.getColumnName());
					actPartitionOrderValsTotal += partitionOrder;

				}
			}

			if (!treeMapObj.isEmpty()) {
				int maxPartitionOrder = treeMapObj.lastKey();
				int expPartitionOrderValsTotal = maxPartitionOrder
						* (maxPartitionOrder + 1) / 2;

				Assert.assertTrue(
						actPartitionOrderValsTotal == expPartitionOrderValsTotal,
						String.format(MAP_FIELD_VALUE_RANDOM_ERRMSG,
								"partitionOrder"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
