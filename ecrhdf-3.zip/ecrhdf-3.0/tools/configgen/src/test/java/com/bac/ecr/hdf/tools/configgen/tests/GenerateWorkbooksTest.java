package com.bac.ecr.hdf.tools.configgen.tests;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.bac.ecr.hdf.tools.configgen.beans.ConfigGenConstants.InputDocs;
import com.bac.ecr.hdf.tools.configgen.util.GenerateHiveDdlUtil;
import com.bac.ecr.hdf.tools.configgen.util.GenerateWorkBooksUtil;

public class GenerateWorkbooksTest {

	private GenerateHiveDdlUtil hiveDdlUtil = new GenerateHiveDdlUtil();
	
	@Test(enabled=true)
	public void getConfigWorkbook() {
		Workbook wb = null,wb1 = null;
		try {
			 wb = GenerateWorkBooksUtil.getWorkbook("src/test/resources/Configuration.xls");
			 wb1 = GenerateWorkBooksUtil.getWorkbook("src/test/resources/DataMapping.xls");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sheet = wb.getSheet(InputDocs.CONFIGURATION.value()).getSheetName();
		Assert.assertEquals(sheet, InputDocs.CONFIGURATION.value());
		
		String sheet1 = wb1.getSheet(InputDocs.DATAMAPPING.value()).getSheetName();
		Assert.assertEquals(sheet1, InputDocs.DATAMAPPING.value());
		
	}
}
